import { useContext, useState } from 'react';
  import { AdminAuthContext } from '@/contexts/authContext';
  import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';

interface HeaderProps {
  toggleSidebar: () => void;
}

export default function Header({ toggleSidebar }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
const { logout } = useContext(AdminAuthContext);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  
  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm z-10">
      <div className="flex items-center justify-between h-16 px-4">
        {/* Left side */}
        <div className="flex items-center">
          <button
            onClick={toggleSidebar}
            className="p-2 mr-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700"
          >
            <i className="fa-solid fa-bars"></i>
          </button>

        </div>
        
        {/* Right side */}
        <div className="flex items-center space-x-4">
          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700"
            title={theme === 'light' ? '切换到深色模式' : '切换到浅色模式'}
          >
            {theme === 'light' ? (
              <i className="fa-solid fa-moon"></i>
            ) : (
              <i className="fa-solid fa-sun"></i>
            )}
          </button>
          
          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700 relative"
            >
              <i className="fa-solid fa-bell"></i>
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500"></span>
            </button>
            
            {notificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg dark:bg-gray-800 ring-1 ring-black ring-opacity-5 z-20">
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                  <h3 className="font-medium text-gray-900 dark:text-white">通知</h3>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  <div className="p-4 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <p className="text-sm text-gray-900 dark:text-white">服务器负载过高</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">5分钟前</p>
                  </div>
                  <div className="p-4 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <p className="text-sm text-gray-900 dark:text-white">新用户注册量激增</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">1小时前</p>
                  </div>
                </div>
                <div className="p-2 border-t border-gray-200 dark:border-gray-700">
                  <button className="w-full text-center text-sm text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300">
                    查看全部
                  </button>
                </div>
              </div>
            )}
          </div>
          
          {/* User menu */}
          <div className="relative">
            <div>
              <button className="flex items-center text-sm focus:outline-none">
                <img
                  className="h-8 w-8 rounded-full object-cover"
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Game%20Admin%20User%20Avatar&sign=af22fc4ff467463b7fd1ad290a75ada7"
                  alt="用户头像"
                />
                <span className="ml-2 hidden md:block text-sm font-medium text-gray-700 dark:text-gray-300">管理员</span>
                <i className="fa-solid fa-chevron-down ml-1 hidden md:block text-xs text-gray-500"></i>
              </button>
            </div>
          </div>
          
          {/* Logout button */}
          <button
            onClick={logout}
            className="p-2 rounded-md text-gray-500 hover:text-red-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-red-400 dark:hover:bg-gray-700"
            title="退出登录"
          >
            <i className="fa-solid fa-sign-out-alt"></i>
          </button>
        </div>
      </div>
    </header>
  );
}