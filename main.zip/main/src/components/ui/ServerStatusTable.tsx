import { serverStatus } from '@/mocks/dashboardData';
import { cn } from '@/lib/utils';

export default function ServerStatusTable() {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'online':
        return (
          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full dark:bg-green-900/50 dark:text-green-300">
            <i className="fa-solid fa-circle text-xs mr-1"></i>在线
          </span>
        );
      case 'degraded':
        return (
          <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full dark:bg-yellow-900/50 dark:text-yellow-300">
            <i className="fa-solid fa-exclamation-triangle text-xs mr-1"></i>性能下降
          </span>
        );
      case 'maintenance':
        return (
          <span className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full dark:bg-gray-700 dark:text-gray-300">
            <i className="fa-solid fa-wrench text-xs mr-1"></i>维护中
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full dark:bg-red-900/50 dark:text-red-300">
            <i className="fa-solid fa-times-circle text-xs mr-1"></i>离线
          </span>
        );
    }
  };
  
  const getLoadBarClass = (load: number) => {
    if (load < 50) return 'bg-green-500';
    if (load < 75) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-100 dark:border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">服务器状态</h3>
        <button className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300">
          查看详情
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700/50">
            <tr>
              <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                服务器
              </th>
              <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                状态
              </th>
              <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                负载
              </th>
              <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                在线用户
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {serverStatus.map((server) => (
              <tr key={server.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                <td className="px-3 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                  {server.name}
                </td>
                <td className="px-3 py-4 whitespace-nowrap">
                  {getStatusBadge(server.status)}
                </td>
                <td className="px-3 py-4 whitespace-nowrap">
                  <div className="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                    <div 
                      className={`h-2 rounded-full ${getLoadBarClass(server.load)}`} 
                      style={{ width: `${server.load}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{server.load}%</div>
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                  {server.users.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}