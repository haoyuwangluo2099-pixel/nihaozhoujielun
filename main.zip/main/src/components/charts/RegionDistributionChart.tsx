import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { useEffect, useState } from 'react';
import { ApiService } from '@/services/api';

// 定义颜色方案
const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#6b7280'];

export default function RegionDistributionChart() {
  const [regionData, setRegionData] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadRegionData = async () => {
      try {
        // 在实际项目中，这里应该调用获取地区分布数据的API
        // 为简化演示，我们使用模拟数据
        const data = await ApiService.getDashboardData();
        setRegionData(data.regionDistribution || [
          { name: '美国', value: 35 },
          { name: '欧洲', value: 28 },
          { name: '东南亚', value: 18 },
          { name: '日韩', value: 12 },
          { name: '其他', value: 7 },
        ]);
      } catch (error) {
        console.error('加载地区分布数据失败:', error);
        setRegionData([
          { name: '美国', value: 35 },
          { name: '欧洲', value: 28 },
          { name: '东南亚', value: 18 },
          { name: '日韩', value: 12 },
          { name: '其他', value: 7 },
        ]);
      } finally {
        setLoading(false);
      }
    };
    
    loadRegionData();
  }, []);
  
  if (loading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-100 dark:border-gray-700 h-full flex items-center justify-center">
        <div className="flex flex-col items-center">
          <i className="fa-solid fa-circle-notch fa-spin text-blue-600 text-xl mb-2"></i>
          <span className="text-sm text-gray-500 dark:text-gray-400">加载数据中...</span>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-100 dark:border-gray-700 h-full flex flex-col">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">用户地区分布</h3>
      
      <div className="flex-1 flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%" maxWidth={300} maxHeight={300}>
          <PieChart>
            <Pie
              data={regionData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              nameKey="name"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {regionData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip 
              formatter={(value) => [`${value}%`, '占比']}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Legend layout="vertical" verticalAlign="middle" align="right" />
          </PieChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-4 grid grid-cols-2 gap-2">
        {regionData.map((region, index) => (
          <div key={region.name} className="flex items-center">
            <div 
              className="w-3 h-3 rounded-full mr-2" 
              style={{ backgroundColor: COLORS[index % COLORS.length] }}
            ></div>
            <span className="text-sm text-gray-600 dark:text-gray-300">{region.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}