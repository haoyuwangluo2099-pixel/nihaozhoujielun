import { useState } from 'react';
import { toast } from 'sonner';

// Mock event data
const eventsData = [
  {
    id: 1,
    title: '夏日狂欢活动',
    description: '参与夏日主题活动，赢取限定皮肤和游戏道具',
    startDate: '2025-08-15',
    endDate: '2025-08-30',
    status: 'upcoming',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Summer%20Game%20Event%2C%20vibrant%20colors%2C%20beach%20theme&sign=9351aa922e37f738ef9f31598588fdf9',
    participants: 0,
    rewards: '限定皮肤、游戏币、稀有道具'
  },
  {
    id: 2,
    title: '周年庆典',
    description: '庆祝游戏上线一周年，登录即可领取丰厚奖励',
    startDate: '2025-07-20',
    endDate: '2025-08-05',
    status: 'active',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Game%20Anniversary%20Event%2C%20festive%20atmosphere%2C%20confetti&sign=04249382a5b8db64042d5013dc802c8d',
    participants: 125400,
    rewards: '周年限定称号、免费英雄、周年纪念皮肤'
  },
  {
    id: 3,
    title: '春季挑战赛',
    description: '参与PvP挑战赛，争夺排行榜奖励',
    startDate: '2025-06-10',
    endDate: '2025-06-25',
    status: 'ended',
    image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Spring%20Challenge%20Event%2C%20green%20theme%2C%20tournament&sign=bf9822a5267e57b9f6bc1bb69ef6d959',
    participants: 89600,
    rewards: '冠军奖杯、限定头像框、大量游戏币'
  }
];

export default function Events() {
  const [activeTab, setActiveTab] = useState('active');
  const [newEventOpen, setNewEventOpen] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    startDate: '',
    endDate: '',
    rewards: ''
  });
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewEvent(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle event creation
  const handleCreateEvent = () => {
    if (!newEvent.title || !newEvent.description || !newEvent.startDate || !newEvent.endDate) {
      toast.error('请填写所有必填字段');
      return;
    }
    
    toast.success('活动创建成功');
    setNewEventOpen(false);
    
    // Reset form
    setNewEvent({
      title: '',
      description: '',
      startDate: '',
      endDate: '',
      rewards: ''
    });
  };
  
  // Format status for display
  const formatStatus = (status) => {
    switch (status) {
      case 'active':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300">进行中</span>;
      case 'upcoming':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300">即将开始</span>;
      case 'ended':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">已结束</span>;
      default:
        return status;
    }
  };
  
  // Filter events by status
  const filteredEvents = eventsData.filter(event => {
    if (activeTab === 'active') return event.status === 'active';
    if (activeTab === 'upcoming') return event.status === 'upcoming';
    if (activeTab === 'ended') return event.status === 'ended';
    return true;
  });
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">活动管理</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            创建和管理游戏内活动，提升用户参与度
          </p>
        </div>
        
        <button 
          onClick={() => setNewEventOpen(true)}
          className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
        >
          <i className="fa-solid fa-plus mr-2"></i>
          创建活动
        </button>
      </div>
      
      {/* Events tabs */}
      <div>
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="-mb-px flex space-x-8">
            {[
              { id: 'active', name: '进行中' },
              { id: 'upcoming', name: '即将开始' },
              { id: 'ended', name: '已结束' },
              { id: 'all', name: '全部活动' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                {tab.name}
                {tab.id !== 'all' && (
                  <span className="ml-1 inline-flex items-center justify-center w-5 h-5 rounded-full bg-gray-100 text-gray-800 text-xs dark:bg-gray-700 dark:text-gray-300">
                    {eventsData.filter(event => event.status === tab.id).length}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
        
        {/* Events list */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.length > 0 ? (
            filteredEvents.map((event) => (
              <div key={event.id} className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden border border-gray-200 dark:border-gray-700">
                <div className="relative">
                  <img 
                    src={event.image} 
                    alt={event.title}
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    {formatStatus(event.status)}
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{event.title}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">{event.description}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">活动时间:</span>
                      <span className="text-gray-900 dark:text-white">{event.startDate} - {event.endDate}</span>
                    </div>
                    {event.participants > 0 && (
                      <div className="flex justify-between">
                        <span className="text-gray-500 dark:text-gray-400">参与人数:</span>
                        <span className="text-gray-900 dark:text-white">{event.participants.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">活动奖励:</span>
                      <span className="text-gray-900 dark:text-white text-xs line-clamp-1">{event.rewards}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex justify-end space-x-2">
                    <button className="px-3 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600">
                      <i className="fa-solid fa-eye mr-1"></i> 查看详情
                    </button>
                    <button className="px-3 py-1 text-xs font-medium rounded-md bg-blue-100 text-blue-800 hover:bg-blue-200 dark:bg-blue-900/50 dark:text-blue-300 dark:hover:bg-blue-800/50">
                      <i className="fa-solid fa-edit mr-1"></i> 编辑
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
              <div className="bg-gray-100 dark:bg-gray-700/50 p-4 rounded-full mb-4">
                <i className="fa-solid fa-calendar-alt text-gray-400 text-2xl"></i>
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">暂无活动</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md">
                当前没有符合条件的活动。点击"创建活动"按钮开始创建新的游戏活动。
              </p>
            </div>
          )}
        </div>
      </div>
      
      {/* New event modal */}
      {newEventOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">创建新活动</h2>
                <button 
                  onClick={() => setNewEventOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  活动标题 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={newEvent.title}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入活动标题"
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  活动描述 <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="description"
                  name="description"
                  rows={3}
                  value={newEvent.description}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入活动描述"
                ></textarea>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    开始日期 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="startDate"
                    name="startDate"
                    value={newEvent.startDate}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
                
                <div>
                  <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    结束日期 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="endDate"
                    name="endDate"
                    value={newEvent.endDate}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="rewards" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  活动奖励
                </label>
                <input
                  type="text"
                  id="rewards"
                  name="rewards"
                  value={newEvent.rewards}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入活动奖励，多个奖励用逗号分隔"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  活动图片
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center hover:border-blue-500 dark:hover:border-blue-400 transition-colors">
                  <i className="fa-solid fa-cloud-upload-alt text-gray-400 text-3xl mb-2"></i>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">拖放图片到此处或点击上传</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">支持 JPG, PNG 格式，建议尺寸 1200x600</p>
                  <input type="file" className="hidden" id="eventImage" accept="image/*" />
                  <label htmlFor="eventImage" className="mt-3 inline-block px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 cursor-pointer">
                    选择图片
                  </label>
                </div>
              </div>
            </div>
            
            <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex justify-end space-x-3">
              <button
                onClick={() => setNewEventOpen(false)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600"
              >
                取消
              </button>
              <button
                onClick={handleCreateEvent}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
              >
                创建活动
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}