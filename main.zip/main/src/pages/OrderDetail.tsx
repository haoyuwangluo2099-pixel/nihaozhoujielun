import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ApiService } from '@/services/api';
import { toast } from 'sonner';
import { formatCurrency } from '@/lib/utils';

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    if (!id) {
      toast.error('订单ID不存在');
      navigate('/orders');
      return;
    }
    
    const fetchOrderDetail = async () => {
      try {
        setLoading(true);
        const data = await ApiService.getOrderById(parseInt(id));
        setOrder(data);
      } catch (err) {
        console.error('Error fetching order details:', err);
        setError('获取订单详情失败，请重试');
        toast.error('获取订单详情失败');
      } finally {
        setLoading(false);
      }
    };
    
    fetchOrderDetail();
  }, [id, navigate]);
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <i className="fa-solid fa-spinner fa-spin text-2xl text-gray-400 mb-2"></i>
          <p className="text-gray-500 dark:text-gray-400">加载订单详情中...</p>
        </div>
      </div>
    );
  }
  
  if (error || !order) {
    return (
      <div className="text-center py-10">
        <i className="fa-solid fa-exclamation-triangle text-4xl text-yellow-500 mb-4"></i>
        <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">{error || '订单不存在'}</h3>
        <button 
          onClick={() => navigate('/orders')}
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <i className="fa-solid fa-arrow-left mr-2"></i>
          返回订单列表
        </button>
      </div>
    );
  }
  
  // 格式化日期时间
  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };
  
  // 格式化订单状态
  const formatStatus = (status: string) => {
    switch (status) {
      case 'completed':
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">已完成</span>;
      case 'pending':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium">待处理</span>;
      case 'refunded':
        return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">已退款</span>;
      case 'failed':
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">支付失败</span>;
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">{status}</span>;
    }
  };
  
  return (
    <div className="space-y-6">
      {/* 页面头部 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">订单详情 #{order.id}</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            创建时间: {formatDateTime(order.createdAt)}
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <button 
            onClick={() => navigate('/orders')}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
          >
            <i className="fa-solid fa-arrow-left mr-2"></i>
            返回订单列表
          </button>
          {order.status === 'pending' && (
            <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
              <i className="fa-solid fa-check mr-2"></i>
              标记为已完成
            </button>
          )}
        </div>
      </div>
      
      {/* 订单状态卡片 */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">订单状态</h2>
            <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
              最后更新: {formatDateTime(order.updatedAt)}
            </p>
          </div>
          <div className="mt-4 md:mt-0">
                      {formatStatus(order.status)}
                      <div className="flex items-center mt-1">
                        <span className="text-xs text-gray-500 dark:text-gray-400 mr-2">订单状态跟踪:</span>
                        <div className="flex space-x-1">
                          <div className={`w-2 h-2 rounded-full ${order.status === 'completed' || order.status === 'in_progress' || order.status === 'refunded' ? 'bg-blue-500' : 'bg-gray-300 dark:bg-gray-600'}`}></div>
                          <div className={`w-2 h-2 rounded-full ${order.status === 'completed' || order.status === 'in_progress' ? 'bg-blue-500' : 'bg-gray-300 dark:bg-gray-600'}`}></div><div className={`w-2 h-2 rounded-full ${order.status === 'completed' ? 'bg-blue-500' : 'bg-gray-300 dark:bg-gray-600'}`}></div>
                        </div>
                      </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* 订单信息 */}
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">订单信息</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">订单编号</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{order.transactionId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">创建时间</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{formatDateTime(order.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">支付方式</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {order.paymentMethod === 'credit_card' ? '信用卡' : 
                   order.paymentMethod === 'paypal' ? 'PayPal' : 
                   order.paymentMethod === 'mobile_payment' ? '移动支付' : order.paymentMethod}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">交易ID</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{order.transactionId}</span>
              </div>
            </div>
          </div>
          
          {/* 用户信息 */}
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">用户信息</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">用户名</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{order.user}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">用户ID</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">#{order.userId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">邮箱</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{order.userEmail || '未提供'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">注册日期</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{order.userRegisterDate || '未知'}</span>
              </div>
            </div>
          </div>
          
          {/* 支付信息 */}
          <div>
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">支付信息</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">商品金额</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{formatCurrency(order.amount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">税费</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{formatCurrency(order.tax)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600 dark:text-gray-300">折扣</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">-{formatCurrency(order.discount || 0)}</span>
              </div>
              <div className="flex justify-between pt-3 border-t border-gray-200 dark:border-gray-700">
                <span className="text-sm font-medium text-gray-900 dark:text-white">总计</span>
                <span className="text-sm font-bold text-gray-900 dark:text-white">{formatCurrency(order.total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* 退款警告信息 */}
      {order.refundWarning && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-400 p-4 mt-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <i className="fa-solid fa-exclamation-triangle text-yellow-500"></i>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-300">退款警告</h3>
              <div className="mt-2 text-sm text-yellow-700 dark:text-yellow-400">
                <p>该订单存在退款申请，请及时处理。</p>
                <p className="mt-1">退款原因: {order.refundWarning.reason}</p>
                <p className="mt-1">状态: {order.refundWarning.status === 'pending' ? '待处理' : order.refundWarning.status === 'investigating' ? '调查中' : '已解决'}</p>
              </div>
              <div className="mt-4">
                <button className="inline-flex items-center px-3 py-1 border border-transparent rounded-md shadow-sm text-xs font-medium text-white bg-yellow-600 hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">
                  <i className="fa-solid fa-clipboard-check mr-1"></i>
                  处理退款
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* 商品信息 */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden border border-gray-200 dark:border-gray-700">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">购买商品</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  商品
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  单价
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  数量
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  小计
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {order.items && order.items.map((item: any) => (
                <tr key={item.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center">
                        <i className="fa-solid fa-box text-gray-600 dark:text-gray-300"></i>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">{item.name}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">{item.sku || 'N/A'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {formatCurrency(item.price)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {item.quantity}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {formatCurrency(item.price * item.quantity)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* 配送信息 */}
      {order.shipping && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">配送信息</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">配送地址</h3>
              <div className="text-sm text-gray-900 dark:text-white">
                {order.shipping.address}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">配送状态</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-300">配送方式</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{order.shipping.method}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-300">配送时间</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {order.shipping.status === 'delivered' ? formatDateTime(order.shipping.deliveredAt) : 
                     order.shipping.status === 'shipped' ? formatDateTime(order.shipping.shippedAt) : '未发货'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-300">物流单号</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{order.shipping.trackingNumber || 'N/A'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* 订单备注 */}
      {order.notes && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">订单备注</h2>
          <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-md">
            <p className="text-sm text-gray-900 dark:text-white whitespace-pre-line">{order.notes}</p>
          </div>
        </div>
      )}
      
      {/* 操作日志 */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">订单操作日志</h2>
        <div className="space-y-4">
          {order.activityLog && order.activityLog.map((log: any, index: number) => (
            <div key={index} className="flex">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <i className="fa-solid fa-user text-blue-600 dark:text-blue-400 text-sm"></i>
                </div>
              </div>
              <div className="ml-4">
                <div className="flex items-center">
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{log.user}</span>
                  <span className="ml-2 text-xs text-gray-500 dark:text-gray-400">{formatDateTime(log.timestamp)}</span>
                </div>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">{log.action}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}