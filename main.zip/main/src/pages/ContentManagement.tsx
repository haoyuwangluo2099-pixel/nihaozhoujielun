import { useState } from 'react';
import { contentItems } from '@/mocks/dashboardData';
import { toast } from 'sonner';

// 内容类型标签
const ContentTypeTag = ({ type }: { type: string }) => {
  const types = {
    'announcement': { label: '公告', className: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300' },
    'image': { label: '图片', className: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
    'video': { label: '视频', className: 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300' },
    'news': { label: '新闻', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300' }
  };
  
  const typeInfo = types[type] || { label: type, className: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' };
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${typeInfo.className}`}>
      {typeInfo.label}
    </span>
  );
};

// 内容状态标签
const ContentStatusTag = ({ status }: { status: string }) => {
  const statuses = {
    'draft': { label: '草稿', className: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' },
    'published': { label: '已发布', className: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
    'scheduled': { label: '已排期', className: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300' },
    'archived': { label: '已归档', className: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' }
  };
  
  const statusInfo = statuses[status] || { label: status, className: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' };
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusInfo.className}`}>
      {statusInfo.label}
    </span>
  );
};

export default function ContentManagement() {
  const [contentList, setContentList] = useState(contentItems);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [newContentOpen, setNewContentOpen] = useState(false);
  
  // 筛选内容列表
  const filteredContent = contentList
    .filter(item => 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.type.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(item => activeTab === 'all' || item.status === activeTab);
  
  // 处理内容发布
  const handlePublish = (id) => {
    setContentList(contentList.map(item => 
      item.id === id ? { ...item, status: 'published', updatedAt: new Date().toISOString() } : item
    ));
    toast.success('内容已发布');
  };
  
  // 处理内容删除
  const handleDelete = (id) => {
    if (window.confirm('确定要删除此内容吗？')) {
      setContentList(contentList.filter(item => item.id !== id));
      toast.success('内容已删除');
    }
  };
  
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">内容管理</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            创建和管理游戏内公告、图片和视频等内容
          </p>
        </div>
        
        <button 
          onClick={() => setNewContentOpen(true)}
          className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
        >
          <i className="fa-solid fa-plus mr-2"></i>
          创建内容
        </button>
      </div>
      
      {/* 搜索和筛选 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative w-full md:w-auto">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <i className="fa-solid fa-search text-gray-400"></i>
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-300"
            placeholder="搜索内容..."
          />
        </div>
        
        <div className="border-b border-gray-200 dark:border-gray-700 w-full md:w-auto">
          <nav className="-mb-px flex space-x-8">
            {[
              { id: 'all', name: '全部内容' },
              { id: 'published', name: '已发布' },
              { id: 'draft', name: '草稿' },
              { id: 'scheduled', name: '已排期' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                {tab.name}
                {tab.id !== 'all' && (
                  <span className="ml-1 inline-flex items-center justify-center w-5 h-5 rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                    {contentList.filter(item => item.status === tab.id).length}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>
      
      {/* 内容列表 */}
      <div className="bg-white dark:bg-gray-800 shadow overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  标题
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  类型
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  状态
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  创建时间
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  作者
                </th>
                {activeTab === 'scheduled' && (
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    排期时间
                  </th>
                )}
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredContent.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">{item.title}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <ContentTypeTag type={item.type} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <ContentStatusTag status={item.status} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {item.createdAt}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {item.author}
                  </td>
                  {activeTab === 'scheduled' && (
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {item.scheduledTime}
                    </td>
                  )}
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button 
                      onClick={() => {}}
                      className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4"
                    >
                      <i className="fa-solid fa-edit"></i>
                    </button>
                    
                    {item.status !== 'published' && (
                      <button 
                        onClick={() => handlePublish(item.id)}
                        className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-4"
                      >
                        <i className="fa-solid fa-check"></i>
                      </button>
                    )}
                    
                    <button 
                      onClick={() => handleDelete(item.id)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                    >
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* 分页 */}
        <div className="bg-white dark:bg-gray-800 px-4 py-3 flex items-center justify-between border-t border-gray-200 dark:border-gray-700 sm:px-6">
          <div className="hidden sm:block">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              显示 <span className="font-medium">1</span> 到 <span className="font-medium">{filteredContent.length}</span> 条，共 <span className="font-medium">{contentList.length}</span> 条结果
            </p>
          </div>
          <div className="flex-1 flex justify-between sm:justify-end">
            <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600">
              <span className="sr-only">上一页</span>
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600">
              <span className="sr-only">下一页</span>
              <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* 新建内容模态框 */}
      {newContentOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">创建新内容</h2>
                <button 
                  onClick={() => setNewContentOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label htmlFor="contentTitle" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  标题 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="contentTitle"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入内容标题"
                />
              </div>
              
              <div>
                <label htmlFor="contentType" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  内容类型 <span className="text-red-500">*</span>
                </label>
                <select
                  id="contentType"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                >
                  <option value="">选择内容类型</option>
                  <option value="announcement">公告</option>
                  <option value="image">图片</option>
                  <option value="video">视频</option>
                  <option value="news">新闻</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="contentStatus" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  状态 <span className="text-red-500">*</span>
                </label>
                <select
                  id="contentStatus"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                >
                  <option value="draft">草稿</option>
                  <option value="published">立即发布</option>
                  <option value="scheduled">定时发布</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="scheduledDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  发布时间
                </label>
                <input
                  type="datetime-local"
                  id="scheduledDate"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  内容
                </label>
                <textarea
                  rows={6}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入内容详情..."
                ></textarea>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  内容图片
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center hover:border-blue-500 dark:hover:border-blue-400 transition-colors">
                  <i className="fa-solid fa-cloud-upload-alt text-gray-400 text-3xl mb-2"></i>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">拖放图片到此处或点击上传</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500">支持 JPG, PNG 格式，建议尺寸 1200x600</p>
                  <input type="file" className="hidden" id="contentImage" accept="image/*" />
                  <label htmlFor="contentImage" className="mt-3 inline-block px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 cursor-pointer">
                    选择图片
                  </label>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setNewContentOpen(false)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
              >
                取消
              </button>
              <button
                onClick={() => {
                  setNewContentOpen(false);
                  toast.success('内容创建成功');
                }}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
              >
                保存内容
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}