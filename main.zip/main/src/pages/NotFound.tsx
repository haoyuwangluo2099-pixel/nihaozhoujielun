import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-blue-100 dark:bg-blue-900/30 mb-6">
          <i className="fa-solid fa-exclamation-triangle text-4xl text-blue-600 dark:text-blue-400"></i>
        </div>
        <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">404</h1>
        <p className="text-xl text-gray-500 dark:text-gray-400 mb-8">页面未找到</p>
        <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
          抱歉，您请求的页面不存在或已被移动。请检查URL或返回主页。
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/"
            className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
          >
            返回主页
          </Link>
          <Link
            to="/settings"
            className="px-6 py-3 border border-gray-300 text-gray-700 bg-white rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-700"
          >
            联系支持
          </Link>
        </div>
      </div>
    </div>
  );
}