import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { toast } from 'sonner';
import { gameMetricsData, retentionData, ltvData, gamesData, serversData } from '@/mocks/dashboardData';
import KpiCard from '@/components/ui/KpiCard';
import GameMetricsTable from '@/components/ui/GameMetricsTable';

  // Mock game data
  const gameMetrics = {
    sessions: {
      value: 458900,
      change: 5.8,
      trend: 'up',
      icon: 'fa-clock'
    },
    avgSessionTime: {
      value: 18.5,
      change: 2.3,
      trend: 'up',
      icon: 'fa-hourglass-half',
      suffix: '分钟'
    },
    retentionRate: {
      value: 32.8,
      change: -1.2,
      trend: 'down',
      icon: 'fa-recycle',
      suffix: '%'
    },
    conversionRate: {
      value: 4.2,
      change: 0.5,
      trend: 'up',
      icon: 'fa-percentage',
      suffix: '%'
    }
  };

  // Game features usage data
  const featuresUsageData = [
    { name: 'PvP', usage: 78 },
    { name: '任务', usage: 65 },
    { name: '商城', usage: 42 },
    { name: '公会', usage: 38 },
    { name: '副本', usage: 52 },
    { name: '社交', usage: 28 },
  ];

  // State for data loading and error handling
export default function GameData() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState('30d');
  const [selectedGame, setSelectedGame] = useState('');
  const [selectedServer, setSelectedServer] = useState('');
  const [filteredServers, setFilteredServers] = useState([]);
  const [currentRetentionData, setCurrentRetentionData] = useState([]);
  const [currentLTVData, setCurrentLTVData] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');
  
  // Load game data with error handling
  const loadGameData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // In a real application, this would be an API call
      // For now, we'll simulate loading mock data
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // If we need to simulate an error:
      // throw new Error('获取游戏数据失败，请重试');
      
    } catch (err) {
      console.error('Error loading game data:', err);
      setError(err instanceof Error ? err.message : '加载游戏数据时发生错误');
      toast.error('无法加载游戏数据，请检查网络连接或稍后重试');
    } finally {
      setLoading(false);
    }
  };
  
  // Export data function
  const exportData = (data: any[]) => {
    try {
      // Convert data to CSV
      const headers = Object.keys(data[0] || {});
      const csvRows = [
        headers.join(','),
        ...data.map(row => headers.map(header => `"${row[header]}"`).join(','))
      ];
      
      const csvContent = csvRows.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `game_metrics_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success('数据导出成功');
    } catch (err) {
      console.error('Error exporting data:', err);
      toast.error('数据导出失败，请重试');
    }
  };
  
  // Load data on component mount
  useEffect(() => {
    loadGameData();
  }, []);
  
  // Filter servers based on selected game
  useEffect(() => {
    if (selectedGame) {
      const servers = serversData.filter(server => server.gameId === parseInt(selectedGame));
      setFilteredServers(servers);
      
      // Reset server selection if current server is not in filtered list
      if (selectedServer && !servers.some(s => s.id === parseInt(selectedServer))) {
        setSelectedServer('');
        setCurrentRetentionData([]);
        setCurrentLTVData([]);
      }
    } else {
      setFilteredServers([]);
      setSelectedServer('');
      setCurrentRetentionData([]);
      setCurrentLTVData([]);
    }
  }, [selectedGame]);
  
  // Update charts when server is selected
  useEffect(() => {
    if (selectedGame && selectedServer) {
      const gameId = parseInt(selectedGame);
      const serverId = parseInt(selectedServer);
      
      // Set retention data
      if (retentionData[gameId] && retentionData[gameId][serverId]) {
        setCurrentRetentionData(retentionData[gameId][serverId]);
      }
      
      // Set LTV data
      if (ltvData[gameId] && ltvData[gameId][serverId]) {
        setCurrentLTVData(ltvData[gameId][serverId]);
      }
    }
  }, [selectedGame, selectedServer]);
  
  // Handle game selection change
  const handleGameChange = (e) => {
    setSelectedGame(e.target.value);
  };
  
  // Handle server selection change
  const handleServerChange = (e) => {
    setSelectedServer(e.target.value);
  };
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">游戏数据分析</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            分析游戏玩法数据和用户行为指标
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
          {/* Game selection */}
          <div className="relative w-full sm:w-auto">
            <select
              value={selectedGame}
              onChange={handleGameChange}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="">选择游戏</option>
              {gamesData.map(game => (
                <option key={game.id} value={game.id}>{game.name}</option>
              ))}
            </select>
          </div>
          
          {/* Server selection */}
          <div className="relative w-full sm:w-auto">
            <select
              value={selectedServer}
              onChange={handleServerChange}
              disabled={!selectedGame}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white disabled:opacity-50"
            >
              <option value="">选择区服</option>
              {filteredServers.map(server => (
                <option key={server.id} value={server.id}>{server.name}</option>
              ))}
            </select>
          </div>
          
          <div className="relative w-full sm:w-auto">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="7d">过去7天</option>
              <option value="30d">过去30天</option>
              <option value="90d">过去90天</option>
              <option value="1y">过去一年</option>
              <option value="custom">自定义范围</option>
            </select>
          </div>
          
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
            <i className="fa-solid fa-download mr-2"></i>
            导出报告
          </button>
        </div>
      </div>
      
      {/* Data tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            数据概览
          </button>
          <button
            onClick={() => setActiveTab('detailed')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'detailed'
                ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            详细数据
          </button>
          <button
            onClick={() => setActiveTab('retention')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'retention'
                ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            留存分析
          </button>
          <button
            onClick={() => setActiveTab('ltv')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'ltv'
                ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            LTV分析
          </button>
        </nav>
      </div>
      
      {/* Overview Tab Content */}
      {activeTab === 'overview' && (
        <>
          {/* Game metrics cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: '日活跃用户', value: '12,500', change: '+8.2%', icon: 'fa-users' },
              { title: '日新增用户', value: '1,845', change: '+2.5%', icon: 'fa-user-plus' },
              { title: '日付费用户', value: '420', change: '-1.8%', icon: 'fa-wallet' },
              { title: '日收入', value: '¥8,450', change: '+5.3%', icon: 'fa-chart-line' },
              { title: '次日留存率', value: '42.8%', change: '+1.2%', icon: 'fa-recycle' },
              { title: '平均在线时长', value: '18.5分钟', change: '+0.5分钟', icon: 'fa-clock' },
              { title: '付费率', value: '3.4%', change: '+0.2%', icon: 'fa-percentage' },
              { title: 'ARPU', value: '¥6.76', change: '+3.5%', icon: 'fa-coins' }
            ].map((metric, index) => (
              <KpiCard 
                key={index}
                title={metric.title} 
                value={metric.value} 
                change={parseFloat(metric.change)} 
                trend={metric.change.startsWith('+') ? 'up' : 'down'} 
                icon={metric.icon}
              />
            ))}
          </div>
          
          {/* Charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">日活跃用户趋势</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={[
                    { date: '1日', dau: 11200 },
                    { date: '2日', dau: 10800 },
                    { date: '3日', dau: 11500 },
                    { date: '4日', dau: 12100 },
                    { date: '5日', dau: 12800 },
                    { date: '6日', dau: 13200 },
                    { date: '7日', dau: 12500 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="date" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Line type="monotone" dataKey="dau" name="日活跃用户" stroke="#3b82f6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">收入趋势</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={[
                    { date: '1日', revenue: 7200 },
                    { date: '2日', revenue: 6800 },
                    { date: '3日', revenue: 7500 },
                    { date: '4日', revenue: 8100 },
                    { date: '5日', revenue: 8800 },
                    { date: '6日', revenue: 9200 },
                    { date: '7日', revenue: 8450 }
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="date" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Bar dataKey="revenue" name="收入 (¥)" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          
          {/* Additional charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">用户留存率</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={[
                    { day: '1', retention: 100 },
                    { day: '3', retention: 65 },
                    { day: '7', retention: 42 },
                    { day: '14', retention: 32 },
                    { day: '30', retention: 25 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="day" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip 
                      formatter={(value) => [`${value}%`, '留存率']}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Line type="monotone" dataKey="retention" name="留存率" stroke="#8b5cf6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">用户付费分布</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: '未付费用户', value: 96.6 },
                        { name: '付费用户', value: 3.4 }
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill="#3b82f6" />
                      <Cell fill="#10b981" />
                    </Pie>  
                    <Tooltip 
                      formatter={(value) => [`${value}%`, '占比']}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </>
      )}
      
      {/* Detailed Data Tab Content */}
         {activeTab === 'detailed' && (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="text-center">
                    <i className="fa-solid fa-spinner fa-spin text-2xl text-gray-400 mb-2"></i>
                    <p className="text-gray-500 dark:text-gray-400">加载详细数据中...</p>
                  </div>
                </div>
              ) : error ? (
                <div className="flex flex-col items-center justify-center h-64 text-center p-6">
                  <div className="bg-red-100 dark:bg-red-900/30 p-4 rounded-full mb-4">
                    <i className="fa-solid fa-exclamation-triangle text-red-500 dark:text-red-400 text-2xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">数据加载失败</h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">{error}</p>
                  <button 
                    onClick={loadGameData}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    <i className="fa-solid fa-refresh mr-1"></i> 重试
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">详细数据</h3>
                    <div className="flex flex-wrap gap-2">
                      <div className="relative">
                        <select
                          className="block pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        >
                          <option value="all">所有游戏</option>
                          {gamesData.map(game => (
                            <option key={game.id} value={game.id}>{game.name}</option>
                          ))}
                        </select>
                      </div>
                      <button 
                        onClick={() => {
                          navigate('/game-data/detailed');
                        }}
                        className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
                      >
                      <i className="fa-solid fa-arrow-right mr-2"></i>
                      查看完整数据
                    </button>
                    </div>
                  </div>
                  {/* 显示部分数据作为预览 */}
                  {gameMetricsData.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead className="bg-gray-50 dark:bg-gray-700/50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">日期</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">游戏</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">登录</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">注册</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">充值金额</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">付费率</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                          {gameMetricsData.slice(0, 5).map((item, index) => (
                            <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{item.date}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{item.game}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{item.login}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{item.register}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{item.rechargeAmount}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{item.paymentRate}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-gray-500 dark:text-gray-400">暂无数据可显示</p>
                    </div>
                  )}
                </>
              )}
            </div>
        )}
      
      {/* Retention Tab Content */}
      {activeTab === 'retention' && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          {selectedGame && selectedServer ? (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={currentRetentionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="day" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    formatter={(value) => [`${value}%`, '留存率']}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="retention" 
                    name="留存率" 
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="text-center py-12">
              <i className="fa-solid fa-chart-line text-4xl text-gray-400 mb-4"></i>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">选择游戏和区服查看留存率数据</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">请从上方下拉菜单中选择特定的游戏和区服，以查看对应的留存率曲线</p>
            </div>
          )}
        </div>
      )}
      
      {/* LTV Tab Content */}
      {activeTab === 'ltv' && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          {selectedGame && selectedServer ? (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={currentLTVData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="month" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    formatter={(value) => [`¥${value}`, 'LTV']}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="ltv" 
                    name="LTV (¥)" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="text-center py-12">
              <i className="fa-solid fa-chart-line text-4xl text-gray-400 mb-4"></i>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">选择游戏和区服查看LTV数据</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">请从上方下拉菜单中选择特定的游戏和区服，以查看对应的LTV曲线</p>
            </div>
          )}
        </div>
      )}
      
      {/* 数据导出按钮 */}
      <div className="mt-6 flex justify-end">
        <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
          <i className="fa-solid fa-download mr-2"></i>
          导出数据
        </button>
      </div>
    </div>
  );
}