import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from 'recharts';
import KpiCard from '@/components/ui/KpiCard';

// Mock order data
const orderMetrics = {
  totalOrders: {
    value: 15842,
    change: 12.5,
    trend: 'up',
    icon: 'fa-shopping-cart'
  },
  revenue: {
    value: 485200,
    change: 15.7,
    trend: 'up',
    icon: 'fa-chart-line',
    prefix: '$'
  },
  avgOrderValue: {
    value: 30.63,
    change: 2.8,
    trend: 'up',
    icon: 'fa-tag',
    prefix: '$'
  },
  conversionRate: {
    value: 4.2,
    change: 0.5,
    trend: 'up',
    icon: 'fa-percentage',
    suffix: '%'
  }
};

// Order trend data
const orderTrendData = [
  { date: '1日', orders: 480, revenue: 14700 },
  { date: '2日', orders: 520, revenue: 16100 },
  { date: '3日', orders: 490, revenue: 15200 },
  { date: '4日', orders: 550, revenue: 17200 },
  { date: '5日', orders: 620, revenue: 19300 },
  { date: '6日', orders: 780, revenue: 24200 },
  { date: '7日', orders: 680, revenue: 21200 },
];

// Recent orders data
const recentOrders = [
  { id: 'ORD-9876', user: 'player123', date: '2025-08-12 14:32', amount: 49.99, status: 'completed', paymentMethod: '信用卡' },
  { id: 'ORD-9875', user: 'gamer456', date: '2025-08-12 13:45', amount: 29.99, status: 'completed', paymentMethod: 'PayPal' },
  { id: 'ORD-9874', user: 'proplayer789', date: '2025-08-12 11:20', amount: 79.99, status: 'pending', paymentMethod: '信用卡' },
  { id: 'ORD-9873', user: 'mobilegamer', date: '2025-08-12 10:05', amount: 19.99, status: 'completed', paymentMethod: '移动支付' },
  { id: 'ORD-9872', user: 'casualplayer', date: '2025-08-12 09:30', amount: 39.99, status: 'refunded', paymentMethod: '信用卡' },
];

export default function Orders() {
  const navigate = useNavigate();
  const [selectedRefundWarning, setSelectedRefundWarning] = useState<any>(null);
  const [dateRange, setDateRange] = useState('7d');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Format currency values
  const formatCurrency = (value) => {
    return '$' + value.toFixed(2);
  };
  
  // Format status for display
  const formatStatus = (status) => {
    switch (status) {
      case 'completed':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">已完成</span>;
      case 'pending':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">待处理</span>;
      case 'refunded':
        return <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">已退款</span>;
      default:
        return status;
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">订单管理</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            查看和管理游戏内订单和交易记录
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center space-x-3">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="24h">过去24小时</option>
              <option value="7d">过去7天</option>
              <option value="30d">过去30天</option>
              <option value="90d">过去90天</option>
              <option value="custom">自定义范围</option>
            </select>
          </div>
          
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
            <i className="fa-solid fa-download mr-2"></i>
            导出订单
          </button>
        </div>
      </div>
      
      {/* Order metrics cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(orderMetrics).map(([key, metric]) => (
          <KpiCard 
            key={key}
            title={key === 'totalOrders' ? '订单总数' : 
                  key === 'revenue' ? '订单收入' : 
                  key === 'avgOrderValue' ? '平均订单价值' : '转化率'} 
            value={metric.value} 
            change={metric.change} 
            trend={metric.trend} 
            icon={metric.icon}
            formatValue={(value) => (metric.prefix || '') + value + (metric.suffix || '')}
          />
        ))}
      </div>
      
      {/* Order search */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <i className="fa-solid fa-search text-gray-400"></i>
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-300"
          placeholder="搜索订单ID或用户名..."
        />
      </div>
      
      {/* Order trend chart */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">订单趋势</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={orderTrendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#9ca3af" />
              <YAxis yAxisId="left" stroke="#3b82f6" />
              <YAxis yAxisId="right" orientation="right" stroke="#10b981" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
                formatter={(value, name) => {
                  if (name === 'revenue') return [`$${value}`, '收入'];
                  return [value, '订单数'];
                }}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="orders" name="订单数" stroke="#3b82f6" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="revenue" name="收入" stroke="#10b981" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Recent orders table */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden border border-gray-200 dark:border-gray-700">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">最近订单</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray_300 uppercase tracking-wider">
                  订单ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  用户
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  日期
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  金额
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  支付方式
                </th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                   状态
                 </th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                   退款警告
                 </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {recentOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    {order.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {order.user}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {order.date}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {formatCurrency(order.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {order.paymentMethod}
                  </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {formatStatus(order.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {order.refundWarning && (
                        <div className="flex items-center text-yellow-500 cursor-pointer" onClick={() => setSelectedRefundWarning(order.refundWarning)}>
                          <i className="fa-solid fa-exclamation-triangle mr-1"></i>
                          <span className="text-xs">退款警告</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Link to={`/orders/${order.id}`} className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4">
                        <i className="fa-solid fa-eye"></i>
                      </Link>
                      {order.status === 'pending' && (
                         <button 
                           onClick={() => {}}
                           className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-4"
                        >
                          <i className="fa-solid fa-user-plus"></i>
                        </button>
                      )}
                      {(order.status === 'in_progress' || order.assignedTo === '当前用户') && (
                         <button 
                           onClick={() => {}}
                           className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-4"
                        >
                          <i className="fa-solid fa-check"></i>
                        </button>
                      )}
                      <button 
                        onClick={() => {}}
                        className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <i className="fa-solid fa-times"></i>
                      </button>
                    </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                       <button 
                         onClick={() => navigate(`/orders/${order.id}`)}
                         className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4">
                      <i className="fa-solid fa-eye"></i>
                    </button>
                    <button className="text-yellow-600 hover:text-yellow-900 dark:text-yellow-400 dark:hover:text-yellow-300 mr-4">
                      <i className="fa-solid fa-edit"></i>
                    </button>
                    <button className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300">
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex items-center justify-between border-t border-gray-200 dark:border-gray-700">
          <div className="hidden sm:block">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              显示 <span className="font-medium">1</span> 到 <span className="font-medium">5</span> 条，共 <span className="font-medium">15,842</span> 条结果
            </p>
          </div>
          <div className="flex-1 flex justify-between sm:justify-end">
            <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600">
              <span className="sr-only">上一页</span>
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600">
              <span className="sr-only">下一页</span>
              <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}