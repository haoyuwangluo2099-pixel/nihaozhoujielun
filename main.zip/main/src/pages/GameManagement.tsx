import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { ApiService } from '@/services/api';
import { DataService } from '@/services/db';

// 游戏类型定义
interface Game {
  id: number;
  name: string;
  description: string;
  price: number;
  genre: string;
  releaseDate: string;
  imageUrl: string;
  status: 'active' | 'inactive' | 'upcoming';
  players: number;
  revenue: number;
  rating: number;
}

// 初始游戏数据
const initialGameData: Game[] = [
  {
    id: 1,
    name: "星际冒险",
    description: "探索广阔的宇宙，与外星文明接触，展开一场史诗般的太空冒险。",
    price: 29.99,
    genre: "角色扮演",
    releaseDate: "2025-01-15",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Space%20Adventure%2C%20game%20cover&sign=bb36d3f95a731c90ac4970a879e7ead7",
    status: "active",
    players: 1250000,
    revenue: 3650000,
    rating: 4.8
  },
  {
    id: 2,
    name: "魔法王国",
    description: "成为一名强大的魔法师，学习各种咒语，拯救被黑暗势力笼罩的王国。",
    price: 39.99,
    genre: "奇幻",
    releaseDate: "2025-02-20",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Magic%20Kingdom%2C%20game%20cover&sign=27c798ebe2339c3dde97a4594b2a14f2",
    status: "active",
    players: 980000,
    revenue: 3920000,
    rating: 4.6
  },
  {
    id: 3,
    name: "赛车传奇",
    description: "体验极速赛车的快感，解锁各种超级跑车，成为赛道上的传奇。",
    price: 49.99,
    genre: "竞速",
    releaseDate: "2025-03-10",
    imageUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Racing%20Legend%2C%20game%20cover&sign=8f52a04c16a79eee2257042eeca1e728",
    status: "active",
    players: 750000,
    revenue: 3740000,
    rating: 4.5
  }
];

// 游戏收入趋势数据
const revenueTrendData = [
  { month: '1月', revenue: 280000 },
  { month: '2月', revenue: 310000 },
  { month: '3月', revenue: 345000 },
  { month: '4月', revenue: 380000 },
  { month: '5月', revenue: 420000 },
  { month: '6月', revenue: 450000 },
  { month: '7月', revenue: 485200 },
];

// 游戏玩家趋势数据
const playerTrendData = [
  { month: '1月', players: 85000 },
  { month: '2月', players: 92000 },
  { month: '3月', players: 98000 },
  { month: '4月', players: 105000 },
  { month: '5月', players: 112000 },
  { month: '6月', players: 118000 },
  { month: '7月', players: 125800 },
];

export default function GameManagement() {
  // 模拟API连接测试函数
  const testApiConnection = (platform: string) => {
    toast.success(`${platform.toUpperCase()} API连接测试成功`);
  };
  // 状态管理
  const [gameData, setGameData] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [newGameOpen, setNewGameOpen] = useState(false);
  const [currentGame, setCurrentGame] = useState<Partial<Game>>({});
  const [editMode, setEditMode] = useState(false);

  // 加载游戏数据
  useEffect(() => {
    const loadGameData = () => {
      try {
        setLoading(true);
        // 从本地存储获取游戏数据
        const savedGames = localStorage.getItem('games');
        if (savedGames) {
          setGameData(JSON.parse(savedGames));
        } else {
          // 使用初始数据并保存到本地存储
          setGameData(initialGameData);
          localStorage.setItem('games', JSON.stringify(initialGameData));
        }
      } catch (error) {
        console.error('Error loading game data:', error);
        setGameData(initialGameData);
      } finally {
        setLoading(false);
      }
    };

    loadGameData();
  }, []);

  // 处理表单输入变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCurrentGame(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // 保存游戏数据到本地存储
  const saveGameData = (games: Game[]) => {
    localStorage.setItem('games', JSON.stringify(games));
    setGameData(games);
  };

  // 处理添加/编辑游戏
  const handleSaveGame = () => {
    if (!currentGame.name || !currentGame.description || !currentGame.price || !currentGame.genre || !currentGame.releaseDate) {
      toast.error('请填写所有必填字段');
      return;
    }

    const updatedGame: Game = {
      id: editMode ? (currentGame.id as number) : Date.now(),
      name: currentGame.name as string,
      description: currentGame.description as string,
      price: parseFloat(currentGame.price as string),
      genre: currentGame.genre as string,
      releaseDate: currentGame.releaseDate as string,
      imageUrl: currentGame.imageUrl || `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=${currentGame.name}%2C%20game%20cover`,
      status: currentGame.status || 'active',
      players: currentGame.players || 0,
      revenue: currentGame.revenue || 0,
      rating: currentGame.rating || 0
    };

    let updatedGames: Game[];
    if (editMode) {
      updatedGames = gameData.map(game => 
        game.id === updatedGame.id ? updatedGame : game
      );
      toast.success('游戏信息已更新');
    } else {
      updatedGames = [...gameData, updatedGame];
      toast.success('新游戏已添加');
    }

    saveGameData(updatedGames);
    setNewGameOpen(false);
    setCurrentGame({});
    setEditMode(false);
  };

  // 处理编辑游戏
  const handleEditGame = (game: Game) => {
    setCurrentGame({...game});
    setEditMode(true);
    setNewGameOpen(true);
  };

  // 处理删除游戏
  const handleDeleteGame = (id: number) => {
    if (window.confirm('确定要删除这个游戏吗？')) {
      const updatedGames = gameData.filter(game => game.id !== id);
      saveGameData(updatedGames);
      toast.success('游戏已删除');
    }
  };

  // 处理取消
  const handleCancel = () => {
    setNewGameOpen(false);
    setCurrentGame({});
    setEditMode(false);
  };

  // 检查退款警告
  const checkRefundWarnings = async (platform: string) => {
    try {
      const result = await ApiService.checkRefundWarnings(platform);
      if (result.hasWarnings) {
        toast.warning(`发现${result.warnings.length}个${platform === 'ios' ? 'iOS' : 'Google'}退款警告`);
      } else {
        toast.success(`${platform === 'ios' ? 'iOS' : 'Google'}平台暂无退款警告`);
      }
    } catch (error) {
      toast.error('检查退款警告失败');
    }
  };

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">游戏管理</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            添加和管理游戏信息、配置游戏参数
          </p>
        </div>
        
        <button 
          onClick={() => {
            setNewGameOpen(true);
            setEditMode(false);
            setCurrentGame({ status: 'active' });
          }}
          className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
        >
          <i className="fa-solid fa-plus mr-2"></i>
          添加游戏
        </button>
      </div>
      
      {/* 游戏数据概览 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: '游戏总数', value: gameData.length, icon: 'fa-gamepad', color: 'text-blue-600' },
          { title: '总玩家数', value: gameData.reduce((sum, game) => sum + game.players, 0).toLocaleString(), icon: 'fa-users', color: 'text-green-600' },
          { title: '总收入', value: `¥${gameData.reduce((sum, game) => sum + game.revenue, 0).toLocaleString()}`, icon: 'fa-chart-line', color: 'text-purple-600' },
          { title: '平均评分', value: gameData.length > 0 ? (gameData.reduce((sum, game) => sum + game.rating, 0) / gameData.length).toFixed(1) : '0', icon: 'fa-star', color: 'text-yellow-600' }
        ].map((stat, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{stat.title}</h3>
              <i className={`fa-solid ${stat.icon} ${stat.color}`}></i>
            </div>
            <div className="mt-2">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* 趋势图表 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">收入趋势</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  formatter={(value) => [`¥${value}`, '收入']}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Bar dataKey="revenue" name="收入" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">玩家趋势</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={playerTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  formatter={(value) => [value.toLocaleString(), '玩家数']}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Line type="monotone" dataKey="players" name="玩家数" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* 游戏列表 */}
      <div className="bg-white dark:bg-gray-800 shadow overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">游戏列表</h3>
          <div className="flex items-center">
            <div className="relative mr-3">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <i className="fa-solid fa-search text-gray-400"></i>
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-300"
                placeholder="搜索游戏..."
              />
            </div>
            <select className="block pl-3 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-300">
              <option value="all">所有游戏</option>
              <option value="active">活跃游戏</option>
              <option value="inactive">非活跃游戏</option>
              <option value="upcoming">即将上线</option>
            </select>
          </div>
        </div>
        
        {loading ? (
          <div className="px-6 py-10 text-center">
            <i className="fa-solid fa-spinner fa-spin text-2xl text-gray-400 mb-2"></i>
            <p className="text-gray-500 dark:text-gray-400">加载中...</p>
          </div>
        ) : gameData.length === 0 ? (
          <div className="px-6 py-10 text-center">
            <i className="fa-solid fa-gamepad text-4xl text-gray-400 mb-2"></i>
            <p className="text-gray-500 dark:text-gray-400">暂无游戏数据</p>
            <button 
              onClick={() => {
                setNewGameOpen(true);
                setEditMode(false);
                setCurrentGame({ status: 'active' });
              }}
              className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <i className="fa-solid fa-plus mr-2"></i> 添加第一个游戏
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    游戏名称
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    类型
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    价格
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    玩家数
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    状态
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    评分
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    操作
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {gameData.map((game) => (
                  <tr key={game.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img
                            className="h-10 w-10 rounded-md object-cover"
                            src={game.imageUrl}
                            alt={game.name}
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">{game.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{game.releaseDate}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                        {game.genre}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {game.price > 0 ? `¥${game.price.toFixed(2)}` : '免费'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {game.players.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        game.status === 'active' 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' 
                          : game.status === 'inactive'
                            ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                            : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300'
                      }`}>
                        {game.status === 'active' ? '活跃' : game.status === 'inactive' ? '非活跃' : '即将上线'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <i className="fa-solid fa-star text-yellow-400 mr-1"></i>
                        <span className="text-sm text-gray-900 dark:text-white">{game.rating}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        onClick={() => handleEditGame(game)}
                        className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4"
                      >
                        <i className="fa-solid fa-edit"></i>
                      </button>
                      <button 
                        onClick={() => handleDeleteGame(game.id)}
                        className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {gameData.length > 0 && (
          <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex items-center justify-between border-t border-gray-200 dark:border-gray-700">
            <div className="hidden sm:block">
              <p className="text-sm text-gray-700 dark:text-gray-300">
                显示 <span className="font-medium">1</span> 到 <span className="font-medium">{gameData.length}</span> 条，共 <span className="font-medium">{gameData.length}</span> 条结果
              </p>
            </div>
            <div className="flex-1 flex justify-between sm:justify-end">
              <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                <span className="sr-only">上一页</span>
                <i className="fa-solid fa-chevron-left"></i>
              </button>
              <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                <span className="sr-only">下一页</span>
                <i className="fa-solid fa-chevron-right"></i>
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* 添加/编辑游戏模态框 */}
      {newGameOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">{editMode ? '编辑游戏' : '添加新游戏'}</h2>
                <button 
                  onClick={handleCancel}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    游戏名称 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={currentGame.name || ''}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入游戏名称"
                  />
                </div>
                
                <div>
                  <label htmlFor="genre" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    游戏类型 <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="genre"
                    name="genre"
                    value={currentGame.genre || ''}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  >
                    <option value="">选择游戏类型</option>
                    <option value="角色扮演">角色扮演</option>
                    <option value="动作">动作</option>
                    <option value="冒险">冒险</option>
                    <option value="策略">策略</option>
                    <option value="模拟">模拟</option>
                    <option value="竞速">竞速</option>
                    <option value="体育">体育</option>
                    <option value="射击">射击</option>
                    <option value="格斗">格斗</option>
                    <option value="益智">益智</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="price" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    价格 (¥) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    id="price"
                    name="price"
                    value={currentGame.price || ''}
                    onChange={handleInputChange}
                    step="0.01"
                    min="0"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入游戏价格"
                  />
                </div>
                
                <div>
                  <label htmlFor="releaseDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    发布日期 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    id="releaseDate"
                    name="releaseDate"
                    value={currentGame.releaseDate || ''}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
                
                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    游戏状态 <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="status"
                    name="status"
                    value={currentGame.status || ''}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  >
                    <option value="active">活跃</option>
                    <option value="inactive">非活跃</option>
                    <option value="upcoming">即将上线</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="rating" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    游戏评分
                  </label>
                  <input
                    type="number"
                    id="rating"
                    name="rating"
                    value={currentGame.rating || ''}
                    onChange={handleInputChange}
                    step="0.1"
                    min="0"
                    max="5"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入游戏评分 (0-5)"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  游戏描述 <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="description"
                  name="description"
                  rows={4}
                  value={currentGame.description || ''}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入游戏详细描述"
                ></textarea>
              </div>
              
              <div>
                <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  游戏封面图片 URL
                </label>
                <input
                  type="text"
                  id="imageUrl"
                  name="imageUrl"
                  value={currentGame.imageUrl || ''}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入游戏封面图片URL"
                />
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  留空将自动生成游戏封面图片
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="players" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    玩家数量
                  </label>
                  <input
                    type="number"
                    id="players"
                    name="players"
                    value={currentGame.players || ''}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入玩家数量"
                  />
                </div>
                
                <div>
                  <label htmlFor="revenue" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    游戏收入
                  </label>
                  <input
                    type="number"
                    id="revenue"
                    name="revenue"
                    value={currentGame.revenue || ''}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入游戏收入"
                  />
                </div>
              </div>
            </div>
            
            {/* API对接参数配置 */}
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">API对接参数</h3>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="apiKey" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      API密钥 <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="apiKey"
                      name="apiKey"
                      placeholder="输入游戏API密钥"
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  </div>
                  <div>
                    <label htmlFor="appId" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      应用ID <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="appId"
                      name="appId"
                      placeholder="输入应用ID"
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="serverUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    服务器URL <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="serverUrl"
                    name="serverUrl"
                    placeholder="输入游戏服务器URL"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="encryptionKey" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      加密密钥
                    </label>
                    <input
                      type="text"
                      id="encryptionKey"
                      name="encryptionKey"
                      placeholder="输入数据加密密钥"
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  </div>
                  <div>
                    <label htmlFor="timeout" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      超时设置 (秒)
                    </label>
                    <input
                      type="number"
                      id="timeout"
                      name="timeout"
                      defaultValue="30"
                      min="5"
                      max="300"
                      className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700 mt-4">
                    <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">iOS SDK配置</h3>
                    <div className="space-y-3">
                      <div>
                        <label htmlFor="iosSdkBundleId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                          Bundle ID <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="iosSdkBundleId"
                          placeholder="输入iOS应用Bundle ID"
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="iosSdkApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                          API 密钥 <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="iosSdkApiKey"
                          placeholder="输入iOS SDK API密钥"
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="iosSdkTeamId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                          团队ID <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="iosSdkTeamId"
                          placeholder="输入Apple开发团队ID"
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          required
                        />
                      </div>
                      <div className="pt-3 border-t border-gray-200 dark:border-gray-700 mt-3">
                        <h4 className="text-xs font-medium text-gray-900 dark:text-white mb-2">退款警告API</h4>
                        <div>
                          <label htmlFor="iosRefundApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                            退款API密钥
                          </label>
                          <input
                            type="text"
                            id="iosRefundApiKey"
                            placeholder="输入iOS退款API密钥"
                            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          />
                        </div>
                      </div>
                      <button 
                        onClick={() => testApiConnection('ios')}
                        className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300"
                      >
                        <i className="fa-solid fa-check mr-1"></i> 测试连接
                      </button>
                      <button 
                        onClick={() => checkRefundWarnings('ios')}
                        className="w-full py-2 px-3 bg-orange-100 text-orange-800 text-xs font-medium rounded-md hover:bg-orange-200 dark:bg-orange-900/30 dark:text-orange-300 mt-2"
                      >
                        <i className="fa-solid fa-exclamation-triangle mr-1"></i> 检查退款警告
                      </button>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700 mt-4">
                    <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Google SDK配置</h3>
                    <div className="space-y-3">
                      <div>
                        <label htmlFor="googleSdkPackageName" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                          包名 <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="googleSdkPackageName"
                          placeholder="输入Android应用包名"
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="googleSdkApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                          API 密钥 <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="googleSdkApiKey"
                          placeholder="输入Google SDK API密钥"
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          required
                        />
                      </div>
                      <div className="pt-3 border-t border-gray-200 dark:border-gray-700 mt-3">
                        <h4 className="text-xs font-medium text-gray-900 dark:text-white mb-2">退款警告API</h4>
                        <div>
                          <label htmlFor="googleRefundApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                            退款API密钥
                          </label>
                          <input
                            type="text"
                            id="googleRefundApiKey"
                            placeholder="输入Google退款API密钥"
                            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                          />
                        </div>
                        <div className="mt-2">
                          <label htmlFor="googleRefundNotificationUrl" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                            退款通知URL
                          </label>
                          <input
                            type="text"
                            id="googleRefundNotificationUrl"
                            placeholder="输入退款通知回调URL"
                            className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                            defaultValue="https://api.your-game-domain.com/webhook/google/refund"
                          />
                        </div>
                      </div>
                       <button 
                         onClick={() => checkRefundWarnings('android')}
                        onClick={() => testApiConnection('android')}
                        className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300"
                      >
                        <i className="fa-solid fa-check mr-1"></i> 测试连接
                       </button>
                       <button 
                         onClick={() => checkRefundWarnings('ios')}
                         className="w-full py-2 px-3 bg-orange-100 text-orange-800 text-xs font-medium rounded-md hover:bg-orange-200 dark:bg-orange-900/30 dark:text-orange-300 mt-2"
                       >
                         <i className="fa-solid fa-exclamation-triangle mr-1"></i> 检查iOS退款警告
                       </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={handleCancel}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
              >
                取消
              </button>
              <button
                onClick={handleSaveGame}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
              >
                {editMode ? '更新游戏' : '创建游戏'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}