import { useState } from 'react';
import { roles } from '@/mocks/dashboardData';
import { toast } from 'sonner';

// 权限标签
const PermissionTag = ({ permission }: { permission: string }) => {
  // 权限名称映射
  const permissionNames = {
    'user_management': '用户管理',
    'game_data': '游戏数据',
    'revenue_analysis': '收入分析',
    'server_management': '服务器管理',
    'event_management': '活动管理',
    'ad_monitoring': '广告监控',
    'order_management': '订单管理',
    'content_management': '内容管理',
    'support_tickets': '客服工单',
    'system_logs': '系统日志',
    'role_management': '角色管理',
    'settings': '系统设置'
  };
  
  return (
    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 mr-2 mb-2">
      {permissionNames[permission] || permission}
    </span>
  );
};

export default function Roles() {
  const [rolesList, setRolesList] = useState(roles);
  const [selectedRole, setSelectedRole] = useState(null);
  const [newRoleOpen, setNewRoleOpen] = useState(false);
  
  // 处理角色删除
  const handleDelete = (id) => {
    if (id === 1) {
      toast.error('超级管理员角色不能删除');
      return;
    }
    
    if (window.confirm('确定要删除此角色吗？')) {
      setRolesList(rolesList.filter(role => role.id !== id));
      toast.success('角色已删除');
    }
  };
  
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">角色与权限管理</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            创建和管理用户角色及权限分配
          </p>
        </div>
        
        <button 
          onClick={() => setNewRoleOpen(true)}
          className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
        >
          <i className="fa-solid fa-plus mr-2"></i>
          创建新角色
        </button>
      </div>
      
      {/* 角色列表 */}
      <div className="bg-white dark:bg-gray-800 shadow overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  角色名称
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  描述
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  用户数量
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  权限数量
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {rolesList.map((role) => (
                <tr key={role.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">{role.name}</div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 dark:text-white max-w-md">
                    {role.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                      {role.usersCount}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {role.permissions.length}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button 
                      onClick={() => setSelectedRole(role)}
                      className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4"
                    >
                      <i className="fa-solid fa-eye"></i>
                    </button>
                    <button 
                      onClick={() => {}}
                      className="text-yellow-600 hover:text-yellow-900 dark:text-yellow-400 dark:hover:text-yellow-300 mr-4"
                    >
                      <i className="fa-solid fa-edit"></i>
                    </button>
                    <button 
                      onClick={() => handleDelete(role.id)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                      disabled={role.id === 1}
                    >
                      <i className="fa-solid fa-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* 分页 */}
        <div className="bg-white dark:bg-gray-800 px-4 py-3 flex items-center justify-between border-t border-gray-200 dark:border-gray-700 sm:px-6">
          <div className="hidden sm:block">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              显示 <span className="font-medium">1</span> 到 <span className="font-medium">{rolesList.length}</span> 条，共 <span className="font-medium">{rolesList.length}</span> 条结果
            </p>
          </div>
          <div className="flex-1 flex justify-between sm:justify-end">
            <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
              <span className="sr-only">上一页</span>
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
              <span className="sr-only">下一页</span>
              <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* 角色详情模态框 */}
      {selectedRole && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">{selectedRole.name}</h2>
                <button 
                  onClick={() => setSelectedRole(null)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">角色描述</h3>
                <p className="text-sm text-gray-900 dark:text-white bg-gray-100 dark:bg-gray-700/50 p-3 rounded-lg">
                  {selectedRole.description}
                </p>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">权限列表</h3>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {selectedRole.permissions.length} 项权限
                  </span>
                </div>
                
                <div className="flex flex-wrap">
                  {selectedRole.permissions.length > 0 ? (
                    selectedRole.permissions.map((permission, index) => (
                      <PermissionTag key={index} permission={permission} />
                    ))
                  ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400">该角色没有分配任何权限</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">用户数量</h3>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{selectedRole.usersCount}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">分配了此角色的用户</p>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">创建日期</h3>
                  <p className="text-sm text-gray-900 dark:text-white">2025-01-15</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">最后修改: 2025-08-01</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setSelectedRole(null)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
              >
                关闭
              </button>
              <button
                onClick={() => {}}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
              >
                编辑角色
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* 创建角色模态框 */}
      {newRoleOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">创建新角色</h2>
                <button 
                  onClick={() => setNewRoleOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label htmlFor="roleName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  角色名称 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="roleName"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入角色名称"
                />
              </div>
              
              <div>
                <label htmlFor="roleDescription" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  角色描述
                </label>
                <textarea
                  id="roleDescription"
                  rows={3}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  placeholder="输入角色描述..."
                ></textarea>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-3">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    权限分配
                  </label>
                </div>
                
                <div className="space-y-3">
                  {[
                    { id: 'user_management', name: '用户管理', description: '管理用户账户和权限' },
                    { id: 'game_data', name: '游戏数据', description: '查看游戏数据分析' },
                    { id: 'revenue_analysis', name: '收入分析', description: '查看收入和财务数据' },
                    { id: 'server_management', name: '服务器管理', description: '管理游戏服务器' },
                    { id: 'event_management', name: '活动管理', description: '创建和管理游戏活动' },
                    { id: 'ad_monitoring', name: '广告监控', description: '监控广告投放效果' },
                    { id: 'order_management', name: '订单管理', description: '查看和管理订单' },
                    { id: 'content_management', name: '内容管理', description: '管理游戏内内容' },
                    { id: 'support_tickets', name: '客服工单', description: '处理用户支持请求' },
                    { id: 'system_logs', name: '系统日志', description: '查看系统操作日志' },
                    { id: 'role_management', name: '角色管理', description: '管理用户角色和权限' },
                    { id: 'settings', name: '系统设置', description: '修改系统设置' }
                  ].map((permission) => (
                    <div key={permission.id} className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id={`permission-${permission.id}`}
                          name={permission.id}
                          type="checkbox"
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:focus:ring-blue-400 dark:border-gray-600"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor={`permission-${permission.id}`} className="font-medium text-gray-900 dark:text-gray-300">
                          {permission.name}
                        </label>
                        <p className="text-gray-500 dark:text-gray-400">{permission.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setNewRoleOpen(false)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
              >
                取消
              </button>
              <button
                onClick={() => {
                  setNewRoleOpen(false);
                  toast.success('角色创建成功');
                }}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
              >
                创建角色
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}