import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { adPerformanceData, adChannelsData, gamesData } from '@/mocks/dashboardData';
import KpiCard from '@/components/ui/KpiCard';

// COLORS for charts
const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#6b7280'];

export default function AdMonitoring() {
  const [dateRange, setDateRange] = useState('30d');
  const [activeMetrics, setActiveMetrics] = useState({
    impressions: true,
    clicks: true,
    conversions: true
  });
  
  // Calculate key ad metrics
  const calculateAdMetrics = () => {  
    const latestData = adPerformanceData[adPerformanceData.length - 1];
    const previousData = adPerformanceData[adPerformanceData.length - 2];
    
    // Calculate changes
    const impressionsChange = previousData ? ((latestData.impressions - previousData.impressions) / previousData.impressions) * 100 : 0;
    const clicksChange = previousData ? ((latestData.clicks - previousData.clicks) / previousData.clicks) * 100 : 0;
    const conversionsChange = previousData ? ((latestData.conversions - previousData.conversions) / previousData.conversions) * 100 : 0;
    const ctrChange = previousData ? ((latestData.ctr - previousData.ctr) / previousData.ctr) * 100 : 0;
    const cpcChange = previousData ? ((latestData.cpc - previousData.cpc) / previousData.cpc) * 100 : 0;
    const costChange = previousData ? ((latestData.cost - previousData.cost) / previousData.cost) * 100 : 0;
    
    return {
      impressions: {
        value: latestData.impressions,
        change: impressionsChange.toFixed(1),
        trend: impressionsChange >= 0 ? 'up' : 'down',
        icon: 'fa-eye'
      },
      clicks: {
        value: latestData.clicks,
        change: clicksChange.toFixed(1),
        trend: clicksChange >= 0 ? 'up' : 'down',
        icon: 'fa-mouse-pointer'
      },
      ctr: {
        value: latestData.ctr,
        change: ctrChange.toFixed(1),
        trend: ctrChange >= 0 ? 'up' : 'down',
        icon: 'fa-percentage',
        suffix: '%'
      },
      conversions: {
        value: latestData.conversions,
        change: conversionsChange.toFixed(1),
        trend: conversionsChange >= 0 ? 'up' : 'down',
        icon: 'fa-exchange-alt'
      },
      cpc: {
        value: latestData.cpc,
        change: cpcChange.toFixed(1),
        trend: cpcChange <= 0 ? 'up' : 'down', // Lower CPC is better
        icon: 'fa-money-bill-wave',
        prefix: '$'
      },
      cost: {
        value: latestData.cost,
        change: costChange.toFixed(1),
        trend: costChange >= 0 ? 'up' : 'down',
        icon: 'fa-wallet',
        prefix: '$'
      }
    };
  };
  
  const adMetrics = calculateAdMetrics();
  
  // Format large numbers
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };
  
  return (
      <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">广告监控</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            监控和分析广告投放效果和关键指标
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex flex-wrap gap-3">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="today">今天</option>
              <option value="yesterday">昨天</option>
              <option value="7d">过去7天</option>
              <option value="30d">过去30天</option>
              <option value="90d">过去90天</option>
              <option value="custom">自定义范围</option>
            </select>
          </div>
          
          <div className="relative">
            <select
              className="block pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="all">所有渠道</option>
              <option value="google">Google Ads</option>
              <option value="facebook">Facebook</option>
              <option value="tiktok">TikTok</option>
              <option value="apple">Apple Search Ads</option>
              <option value="other">其他渠道</option>
            </select>
          </div>
          
          <div className="relative">
            <select
              className="block pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="all">所有游戏</option>
              {gamesData.map(game => (
                <option key={game.id} value={game.id}>{game.name}</option>
              ))}
            </select>
          </div>
          
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
            <i className="fa-solid fa-download mr-2"></i>
            导出报告
          </button>
        </div>
      </div>
      
      {/* Ad metrics cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.entries(adMetrics).map(([key, metric]) => (
          <KpiCard 
            key={key}
            title={key === 'impressions' ? '展示量' : 
                  key === 'clicks' ? '点击量' : 
                  key === 'ctr' ? '点击率' : 
                  key === 'conversions' ? '转化量' : 
                  key === 'cpc' ? '点击成本' : '广告支出'} 
            value={metric.value} 
            change={parseFloat(metric.change)} 
            trend={metric.trend} 
            icon={metric.icon}
            formatValue={(value) => (metric.prefix || '') + value + (metric.suffix || '')}
            formatValueLarge={formatNumber}
          />
        ))}
      </div>
      
      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">广告效果趋势</h3>
            <div className="flex space-x-2">
              {['impressions', 'clicks', 'conversions'].map((metric) => (
                <button
                  key={metric}
                  onClick={() => setActiveMetrics(prev => ({
                    ...prev,
                    [metric]: !prev[metric]
                  }))}
                  className={`px-3 py-1 text-xs font-medium rounded-full ${
                    activeMetrics[metric]
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300'
                      : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                  }`}
                >
                  {metric === 'impressions' ? '展示量' : 
                   metric === 'clicks' ? '点击量' : '转化量'}
                </button>
              ))}
            </div>
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={adPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Legend />
                
                {activeMetrics.impressions && (
                  <Line 
                    type="monotone" 
                    dataKey="impressions" 
                    name="展示量" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                )}
                
                {activeMetrics.clicks && (
                  <Line 
                    type="monotone" 
                    dataKey="clicks" 
                    name="点击量" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                )}
                
                {activeMetrics.conversions && (
                  <Line 
                    type="monotone" 
                    dataKey="conversions" 
                    name="转化量" 
                    stroke="#f59e0b" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">广告渠道分布</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={adChannelsData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="impressions"
                    nameKey="name"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {adChannelsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, '占比']}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            
            <div className="flex flex-col justify-between">
              <div>
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">渠道效果对比</h4>
                <div className="space-y-4">
                  {['clicks', 'conversions', 'cost'].map((metric) => (
                    <div key={metric}>
                      <h5 className="text-xs text-gray-500 dark:text-gray-400 mb-2 capitalize">
                        {metric === 'clicks' ? '点击率' : 
                         metric === 'conversions' ? '转化率' : '成本占比'}
                      </h5>
                      <div className="space-y-2">
                        {adChannelsData.map((channel, index) => (
                          <div key={channel.name} className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: COLORS[index % COLORS.length] }}
                            ></div>
                            <span className="text-xs text-gray-600 dark:text-gray-300 w-16">{channel.name}</span>
                            <div className="flex-1 mx-2">
                              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                                <div 
                                  className="h-1.5 rounded-full" 
                                  style={{ 
                                    width: `${channel[metric]}%`,
                            backgroundColor: COLORS[index % COLORS.length]
                         }}
                       ></div>
                       {channel.status === 'active' && (
                         <span className="w-2 h-2 rounded-full bg-green-500 ml-2"></span>
                       )}
                       {channel.status === 'inactive' && (
                         <span className="w-2 h-2 rounded-full bg-gray-500 ml-2"></span>
                       )}
                     </div>
                   </div>
                   <span className="text-xs font-medium text-gray-900 dark:text-white">{channel[metric]}%</span>
                 </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Performance metrics */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">广告活动效果</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  活动名称
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  渠道
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  展示量
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  点击率
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  转化量
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  花费
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  ROI
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  状态
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {[
                { name: '夏季促销活动', channel: 'Google Ads', impressions: '850K', ctr: '4.2%', conversions: '2,150', spend: '$24,800', roi: '6.2x', status: 'active' },
                { name: '新用户获取', channel: 'Facebook', impressions: '620K', ctr: '3.9%', conversions: '1,850', spend: '$19,500', roi: '5.8x', status: 'active' },
                { name: '游戏新版本推广', channel: 'TikTok', impressions: '480K', ctr: '4.5%', conversions: '1,420', spend: '$16,200', roi: '5.4x', status: 'active' },
               { name: '节日特惠', channel: 'Instagram', impressions: '320K', ctr: '3.8%', conversions: '680', spend: '$9,200', roi: '4.8x', status: 'ended' },
               { name: '新用户获取', channel: 'TikTok', impressions: '350K', ctr: '5.2%', conversions: '1,250', spend: '$12,800', roi: '5.1x', status: 'active' },
                { name: '用户召回', channel: '其他', impressions: '250K', ctr: '3.2%', conversions: '320', spend: '$9,500', roi: '3.5x', status: 'active' },
              ].map((campaign, index) => (
                <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    {campaign.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {campaign.channel}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {campaign.impressions}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                      {campaign.ctr}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {campaign.conversions}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    ${campaign.spend}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {campaign.roi}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      campaign.status === 'active' 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {campaign.status === 'active' ? '进行中' : '已结束'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}