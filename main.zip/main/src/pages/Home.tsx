import { useEffect, useContext } from 'react';
import { AdminAuthContext } from '@/contexts/authContext';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const { isAuthenticated } = useContext(AdminAuthContext);
  const navigate = useNavigate();
  
  useEffect(() => {
    // Redirect to dashboard if authenticated, otherwise to login
    if (isAuthenticated) {
      navigate('/');
    } else {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);
  
  return (
    <div className="flex items-center justify-center h-screen bg-gray-50 dark:bg-gray-900">
      <div className="flex flex-col items-center">
        <i className="fa-solid fa-gamepad text-blue-600 text-4xl animate-pulse"></i>
        <p className="mt-4 text-lg font-medium text-gray-700 dark:text-gray-300">正在重定向...</p>
      </div>
    </div>
  );
}