import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ApiService } from '@/services/api';
import { cn } from '@/lib/utils';

// 游戏卡片组件
const GameCard = ({ game }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:scale-105 border border-gray-200 dark:border-gray-700">
      <div className="relative">
        <img 
          src={`https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=${game.name}%2C%20game%20cover%2C%20vibrant%20colors`} 
          alt={game.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-2 right-2 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded">
          {game.price > 0 ? `$${game.price}` : '免费'}
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{game.name}</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-3 line-clamp-2">{game.description}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <i className="fa-solid fa-star text-yellow-400 mr-1"></i>
            <span className="text-sm text-gray-700 dark:text-gray-300">{game.rating}</span>
          </div>
          <Link 
            to={`/player/games/${game.id}`}
            className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium"
          >
            查看详情 <i className="fa-solid fa-arrow-right ml-1"></i>
          </Link>
        </div>
      </div>
    </div>
  );
};

// 新闻卡片组件
const NewsCard = ({ item }) => {
  return (
    <div className="flex space-x-4 p-3 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg transition-colors">
      <img 
        src={`https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=${item.title}%2C%20game%20news%2C%20vibrant%20colors`} 
        alt={item.title}
        className="w-20 h-20 object-cover rounded"
      />
      <div>
        <h4 className="font-medium text-gray-900 dark:text-white line-clamp-2">{item.title}</h4>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{item.date}</p>
      </div>
    </div>
  );
};

export default function PlayerHome() {
  const [featuredGames, setFeaturedGames] = useState([]);
  const [newReleases, setNewReleases] = useState([]);
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // 加载游戏数据
    const loadData = async () => {
      try {
        setLoading(true);
        
        // 模拟API调用获取游戏数据
        const gameData = [
          {
            id: 1,
            name: "星际冒险",
            description: "探索广阔的宇宙，与外星文明接触，展开一场史诗般的太空冒险。",
            price: 29.99,
            rating: 4.8,
            image: "space-adventure.jpg",
            genre: "角色扮演",
            releaseDate: "2025-01-15"
          },
          {
            id: 2,
            name: "魔法王国",
            description: "成为一名强大的魔法师，学习各种咒语，拯救被黑暗势力笼罩的王国。",
            price: 39.99,
            rating: 4.6,
            image: "magic-kingdom.jpg",
            genre: "奇幻",
            releaseDate: "2025-03-22"
          },
          {
            id: 3,
            name: "赛车传奇",
            description: "体验极速赛车的快感，解锁各种超级跑车，成为赛道上的传奇。",
            price: 49.99,
            rating: 4.5,
            image: "racing-legend.jpg",
            genre: "竞速",
            releaseDate: "2025-05-10"
          },
          {
            id: 4,
            name: "篮球大师",
            description: "组建自己的篮球队，参加各种比赛，赢得总冠军奖杯。",
            price: 0,
            rating: 4.3,
            image: "basketball-master.jpg",
            genre: "体育",
            releaseDate: "2025-06-18"
          },
          {
            id: 5,
            name: "生存挑战",
            description: "在荒野中生存下去，收集资源，建造庇护所，对抗野生动物和恶劣环境。",
            price: 19.99,
            rating: 4.7,
            image: "survival-challenge.jpg",
            genre: "生存",
            releaseDate: "2025-07-05"
          },
          {
            id: 6,
            name: "城市建造者",
            description: "设计并建造自己的梦想城市，管理资源，满足市民需求，发展成为大都市。",
            price: 29.99,
            rating: 4.4,
            image: "city-builder.jpg",
            genre: "模拟",
            releaseDate: "2025-08-12"
          }
        ];
        
        // 模拟新闻数据
        const newsData = [
          {
            id: 1,
            title: "《星际冒险》推出全新DLC，探索未知星球",
            date: "2025-08-10",
            category: "更新"
          },
          {
            id: 2,
            title: "夏季游戏节将于下月开幕，多款新作将亮相",
            date: "2025-08-08",
            category: "活动"
          },
          {
            id: 3,
            title: "《魔法王国》全球玩家突破1000万",
            date: "2025-08-05",
            category: "新闻"
          }
        ];
        
        setFeaturedGames(gameData.slice(0, 4));
        setNewReleases(gameData.slice(4, 6));
        setNews(newsData);
      } catch (error) {
        console.error("Failed to load data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* 导航栏 */}
      <header className="bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/player" className="flex-shrink-0 flex items-center">
                <i className="fa-solid fa-gamepad text-blue-600 text-2xl mr-2"></i>
                <span className="font-bold text-xl text-gray-900 dark:text-white">GamePortal</span>
              </Link>
              <nav className="hidden md:ml-10 md:flex md:space-x-8">
                <Link 
                  to="/player" 
                  className="border-blue-500 text-gray-900 dark:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  首页
                </Link>
                <Link 
                  to="/player/games" 
                  className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  游戏库
                </Link>
                <Link 
                  to="/player/news" 
                  className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  新闻
                </Link>
                <Link 
                  to="/player/community" 
                  className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  社区
                </Link>
              </nav>
            </div>
            <div className="flex items-center">
              <div className="hidden md:ml-4 md:flex md:items-center md:space-x-4">
                <button className="p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
                  <span className="sr-only">查看通知</span>
                  <i className="fa-solid fa-bell text-lg"></i>
                </button>
                <button className="p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
                  <span className="sr-only">搜索</span>
                  <i className="fa-solid fa-search text-lg"></i>
                </button>
                <Link to="/player/cart" className="p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900 relative">
                  <span className="sr-only">购物车</span>
                  <i className="fa-solid fa-shopping-cart text-lg"></i>
                  <span className="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">3</span>
                </Link>
                <div className="ml-3 relative">
                  <div>
                    <button className="flex text-sm border-2 border-transparent rounded-full focus:outline-none focus:border-gray-300 transition duration-150 ease-in-out">
                      <img
                        className="h-8 w-8 rounded-full object-cover"
                        src="https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Player%20Avatar&sign=e4e8b75e0d230745288823fa14b3ca7c"
                        alt="用户头像"
                      />
                    </button>
                  </div>
                </div>
              </div>
              <div className="-mr-2 flex items-center md:hidden">
                <button type="button" className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500">
                  <span className="sr-only">打开主菜单</span>
                  <i className="fa-solid fa-bars"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 英雄区域 */}
        <section className="relative rounded-xl overflow-hidden mb-12">
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40 z-10"></div>
          <img 
            src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Game%20platform%20banner%2C%20vibrant%20colors%2C%20epic%20game%20scene&sign=bb1f88349792aca2865873585d4d832e" 
            alt="Featured game" 
            className="w-full h-[400px] object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 p-8 z-20">
            <span className="inline-block px-3 py-1 bg-blue-600 text-white text-sm font-semibold rounded-full mb-4">新品发布</span>
            <h1 className="text-4xl font-bold text-white mb-3">星际冒险：未知领域</h1>
            <p className="text-gray-200 max-w-2xl mb-6">探索广阔的宇宙，发现新的星球，与外星文明接触，展开一场史诗般的太空冒险。</p>
            <div className="flex flex-wrap gap-4">
              <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <i className="fa-solid fa-gamepad mr-2"></i> 立即游玩
              </button>
              <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-gray-900 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                <i className="fa-solid fa-plus mr-2"></i> 加入愿望单
              </button>
            </div>
          </div>
        </section>

        {/* 特色游戏 */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">特色游戏</h2>
            <Link 
              to="/player/games"
              className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium"
            >
              查看全部 <i className="fa-solid fa-arrow-right ml-1"></i>
            </Link>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array(4).fill(0).map((_, index) => (
                <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow animate-pulse h-64"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredGames.map(game => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          )}
        </section>

        {/* 最新发布和新闻 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* 最新发布 */}
          <div className="lg:col-span-2">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">最新发布</h2>
              <Link 
                to="/player/games/new"
                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium"
              >
                查看全部 <i className="fa-solid fa-arrow-right ml-1"></i>
              </Link>
            </div>
            
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {Array(2).fill(0).map((_, index) => (
                  <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow animate-pulse h-64"></div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {newReleases.map(game => (
                  <GameCard key={game.id} game={game} />
                ))}
              </div>
            )}
          </div>

          {/* 最新动态 */}
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">最新动态</h2>
              <Link 
                to="/player/news"
                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium"
              >
                更多 <i className="fa-solid fa-arrow-right ml-1"></i>
              </Link>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
              {loading ? (
                <div className="p-4 space-y-4">
                  {Array(3).fill(0).map((_, index) => (
                    <div key={index} className="flex space-x-4">
                      <div className="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
                        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-1/2"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {news.map(item => (
                    <NewsCard key={item.id} item={item} />
                  ))}
                </div>
              )}
              
              <div className="p-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <button className="w-full py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600">
                  <i className="fa-solid fa-bell mr-2"></i> 订阅新闻通讯
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 游戏分类 */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">按分类浏览</h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {[
              { name: "动作", icon: "fa-fist-raised", count: 42 },
              { name: "角色扮演", icon: "fa-hat-wizard", count: 36 },
              { name: "策略", icon: "fa-chess", count: 28 },
              { name: "模拟", icon: "fa-city", count: 24 },
              { name: "体育", icon: "fa-baseball", count: 18 },
              { name: "休闲", icon: "fa-gamepad", count: 52 }
            ].map((category, index) => (
              <Link 
                key={index}
                to={`/player/games?category=${category.name}`}
                className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 text-center hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-3">
                  <i className={`fa-solid ${category.icon} text-blue-600 dark:text-blue-400 text-xl`}></i>
                </div>
                <h3 className="font-medium text-gray-900 dark:text-white">{category.name}</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{category.count} 款游戏</p>
              </Link>
            ))}
          </div>
        </section>

        {/* 平台特色 */}
        <section className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-white mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fa-solid fa-cloud-download-alt text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold mb-2">一键安装</h3>
              <p className="text-blue-100">简单快捷的游戏安装流程，让你快速开始游戏</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fa-solid fa-users text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold mb-2">社区互动</h3>
              <p className="text-blue-100">与全球玩家交流，组队游戏，分享游戏心得</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fa-solid fa-gift text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold mb-2">独家优惠</h3>
              <p className="text-blue-100">会员专享折扣，限时特惠，免费游戏领取</p>
            </div>
          </div>
          <div className="text-center mt-8">
            <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
              <i className="fa-solid fa-rocket mr-2"></i> 立即加入会员
            </button>
          </div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <i className="fa-solid fa-gamepad text-blue-400 text-2xl mr-2"></i>
                <span className="font-bold text-xl">GamePortal</span>
              </div>
              <p className="text-gray-400 mb-4">您的一站式游戏平台，提供最新、最热门的游戏下载和资讯。</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <i className="fa-brands fa-facebook"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <i className="fa-brands fa-twitter"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <i className="fa-brands fa-instagram"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <i className="fa-brands fa-discord"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">快速链接</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">首页</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">游戏库</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">新闻</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">社区</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">支持</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">支持</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">帮助中心</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">联系我们</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">常见问题</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">退款政策</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">服务状态</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">法律</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">服务条款</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">隐私政策</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cookie 设置</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">版权信息</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
            <p>© 2025 GamePortal. 保留所有权利。</p>
          </div>
        </div>
      </footer>
    </div>
  );
}