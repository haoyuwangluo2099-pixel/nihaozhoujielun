import { useState, useContext, useEffect } from 'react';
  import { AdminAuthContext } from '@/contexts/authContext';
  import { useTheme } from '@/hooks/useTheme';
import { toast } from 'sonner';

// Mock settings data
const settingsData = {
  general: {
    siteName: 'GameAdmin',
    language: 'zh-CN',
    timezone: 'Asia/Shanghai',
    dateFormat: 'YYYY-MM-DD'
  },
  notifications: {
    email: true,
    push: true,
    sms: false,
    marketing: true
  },
  security: {
    twoFactorAuth: false,
    passwordExpiry: '90',
    sessionTimeout: '30'
  },
  integrations: {
    googleAnalytics: true,
    firebase: false,
    slack: true,
    discord: false
  }
};

// Options for select inputs
const options = {
  languages: [
    { value: 'zh-CN', name: '简体中文' },
    { value: 'en-US', name: 'English' },
    { value: 'ja-JP', name: '日本語' },
    { value: 'ko-KR', name: '한국어' }
  ],
  timezones: [
    { value: 'Asia/Shanghai', name: 'Asia/Shanghai (GMT+8)' },
    { value: 'America/New_York', name: 'America/New_York (GMT-4)' },
    { value: 'Europe/London', name: 'Europe/London (GMT+1)' },
    { value: 'Asia/Tokyo', name: 'Asia/Tokyo (GMT+9)' }
  ],
  dateFormats: [
    { value: 'YYYY-MM-DD', name: '2025-08-15' },
    { value: 'DD/MM/YYYY', name: '15/08/2025' },
    { value: 'MM/DD/YYYY', name: '08/15/2025' }
  ]
};

export default function Settings() {
  const [activeTab, setActiveTab] = useState('general');
  const [settings, setSettings] = useState(settingsData);
  const [originalSettings, setOriginalSettings] = useState(settingsData);
  const [isDirty, setIsDirty] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { logout } = useContext(AdminAuthContext);
  
  // Check if settings have changed
  useEffect(() => {
    setIsDirty(JSON.stringify(settings) !== JSON.stringify(originalSettings));
  }, [settings, originalSettings]);
  
  // Handle input changes
  const handleInputChange = (section, field, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };
  
  // Save settings
  const saveSettings = () => {
    // In a real app, this would save to an API
    setOriginalSettings({...settings});
    toast.success('设置已保存');
  };
  
  // Reset settings
  const resetSettings = () => {
    setSettings({...originalSettings});
  };
  
  // Render settings form based on active tab
  const renderSettingsForm = () => {
    switch (activeTab) {
      case 'general':
        return (
          <div className="space-y-6">
            <div>
              <label htmlFor="siteName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                网站名称
              </label>
              <input
                type="text"
                id="siteName"
                value={settings.general.siteName}
                onChange={(e) => handleInputChange('general', 'siteName', e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              />
            </div>
            
            <div>
              <label htmlFor="language" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                语言
              </label>
              <select
                id="language"
                value={settings.general.language}
                onChange={(e) => handleInputChange('general', 'language', e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              >
                {options.languages.map(option => (
                  <option key={option.value} value={option.value}>{option.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="timezone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                时区
              </label>
              <select
                id="timezone"
                value={settings.general.timezone}
                onChange={(e) => handleInputChange('general', 'timezone', e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              >
                {options.timezones.map(option => (
                  <option key={option.value} value={option.value}>{option.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="dateFormat" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                日期格式
              </label>
              <select
                id="dateFormat"
                value={settings.general.dateFormat}
                onChange={(e) => handleInputChange('general', 'dateFormat', e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              >
                {options.dateFormats.map(option => (
                  <option key={option.value} value={option.value}>{option.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                主题模式
              </label>
              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <input
                    id="lightTheme"
                    name="theme"
                    type="radio"
                    checked={theme === 'light'}
                    onChange={toggleTheme}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:focus:ring-blue-400 dark:border-gray-600"
                  />
                  <label htmlFor="lightTheme" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">
                    浅色模式
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="darkTheme"
                    name="theme"
                    type="radio"
                    checked={theme === 'dark'}
                    onChange={toggleTheme}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:focus:ring-blue-400 dark:border-gray-600"
                  />
                  <label htmlFor="darkTheme" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">
                    深色模式
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="systemTheme"
                    name="theme"
                    type="radio"
                    checked={theme === 'system'}
                    onChange={() => {}} // Would implement system theme detection
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:focus:ring-blue-400 dark:border-gray-600"
                    disabled
                  />
                  <label htmlFor="systemTheme" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">
                    跟随系统
                  </label>
                </div>
              </div>
            </div>
          </div>
        );
        
      case 'notifications':
        return (
          <div className="space-y-6">
            {[
              { id: 'email', label: '邮件通知', description: '接收系统邮件通知' },
              { id: 'push', label: '推送通知', description: '接收浏览器推送通知' },
              { id: 'sms', label: '短信通知', description: '接收重要事件短信通知' },
              { id: 'marketing', label: '营销通知', description: '接收活动和促销信息' }
            ].map((item) => (
              <div key={item.id} className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id={`notification-${item.id}`}
                    name={item.id}
                    type="checkbox"
                    checked={settings.notifications[item.id]}
                    onChange={(e) => handleInputChange('notifications', item.id, e.target.checked)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:focus:ring-blue-400 dark:border-gray-600"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor={`notification-${item.id}`} className="font-medium text-gray-900 dark:text-gray-300">
                    {item.label}
                  </label>
                  <p className="text-gray-500 dark:text-gray-400">{item.description}</p>
                </div>
              </div>
            ))}
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <h3 className="text-sm font-medium text-gray-900 dark:text-gray-300 mb-4">通知频率</h3>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="digestFrequency" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                     digest 邮件频率
                  </label>
                  <select
                    id="digestFrequency"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  >
                    <option value="daily">每天</option>
                    <option value="weekly" selected>每周</option>
                    <option value="monthly">每月</option>
                    <option value="none">不发送</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        );
        
      case 'security':
        return (
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="twoFactorAuth"
                  name="twoFactorAuth"
                  type="checkbox"
                  checked={settings.security.twoFactorAuth}
                  onChange={(e) => handleInputChange('security', 'twoFactorAuth', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:focus:ring-blue-400 dark:border-gray-600"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="twoFactorAuth" className="font-medium text-gray-900 dark:text-gray-300">
                  双因素认证
                </label>
                <p className="text-gray-500 dark:text-gray-400">启用后，登录时需要额外的验证码验证</p>
              </div>
            </div>
            
            <div>
              <label htmlFor="passwordExpiry" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                密码过期时间 (天)
              </label>
              <input
                type="number"
                id="passwordExpiry"
                value={settings.security.passwordExpiry}
                onChange={(e) => handleInputChange('security', 'passwordExpiry', e.target.value)}
                min="0"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              />
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">设置为0表示密码永不过期</p>
            </div>
            
            <div>
              <label htmlFor="sessionTimeout" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                会话超时时间 (分钟)
              </label>
              <input
                type="number"
                id="sessionTimeout"
                value={settings.security.sessionTimeout}
                onChange={(e) => handleInputChange('security', 'sessionTimeout', e.target.value)}
                min="5"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
              />
            </div>
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <h3 className="text-sm font-medium text-gray-900 dark:text-gray-300 mb-4">密码修改</h3>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    当前密码
                  </label>
                  <input
                    type="password"
                    id="currentPassword"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
                
                <div>
                  <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    新密码
                  </label>
                  <input
                    type="password"
                    id="newPassword"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
                
                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    确认新密码
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  />
                </div>
                
                <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
                  更新密码
                </button>
              </div>
            </div>
          </div>
        );
        
      case 'integrations':
        return (
          <div className="space-y-6">
               {[
                { id: 'googleAnalytics', label: 'Google Analytics', description: '启用Google Analytics跟踪' },
                { id: 'firebase', label: 'Firebase', description: '连接Firebase服务' },
                { id: 'slack', label: 'Slack', description: '启用Slack通知集成' },
                { id: 'discord', label: 'Discord', description: '启用Discord通知集成' },
                { id: 'googleAds', label: 'Google Ads', description: '配置Google Ads广告平台' },
                { id: 'facebookAds', label: 'Facebook Ads', description: '配置Facebook Ads广告平台' },
                { id: 'appleSearchAds', label: 'Apple Search Ads', description: '配置Apple Search Ads广告平台' },
                { id: 'googlePlay', label: 'Google Play', description: '接入Google Play应用商店' },
                { id: 'googlePlay', label: 'Google Play', description: '接入Google Play应用商店' },
                 { id: 'appStore', label: 'iOS App Store', description: '接入iOS App Store应用商店' },
                 { id: 'googleSdk', label: 'Google SDK', description: '配置Google SDK' },
                 { id: 'iosSdk', label: 'iOS SDK', description: '配置iOS SDK' }
              ].map((item) => (
              <div key={item.id} className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id={`integration-${item.id}`}
                    name={item.id}
                    type="checkbox"
                    checked={settings.integrations[item.id]}
                    onChange={(e) => handleInputChange('integrations', item.id, e.target.checked)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:focus:ring-blue-400 dark:border-gray-600"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor={`integration-${item.id}`} className="font-medium text-gray-900 dark:text-gray-300">
                    {item.label}
                  </label>
                  <p className="text-gray-500 dark:text-gray-400">{item.description}</p>
                  
                  {settings.integrations[item.id] && (
                    <div className="mt-3 pl-2 border-l-2 border-gray-200 dark:border-gray-700">
                      <div className="space-y-3">
                        {item.id === 'googleAds' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="googleAdsClientId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                客户端ID
                              </label>
                              <input
                                type="text"
                                id="googleAdsClientId"
                                placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="googleAdsApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                API 密钥
                              </label>
                              <input
                                type="text"
                                id="googleAdsApiKey"
                                placeholder="AIzaSyDXXXXXXXXXXXXXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="googleAdsConversionId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                转化跟踪ID
                              </label>
                              <input
                                type="text"
                                id="googleAdsConversionId"
                                placeholder="AW-XXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <button className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300">
                              <i className="fa-solid fa-check mr-1"></i> 测试连接
                            </button>
                          </div>
                        )}
                        
                        {item.id === 'facebookAds' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="facebookAdsAccountId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                广告账户ID
                              </label>
                              <input
                                type="text"
                                id="facebookAdsAccountId"
                                placeholder="act_XXXXXXXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="facebookAdsAccessToken" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                访问令牌
                              </label>
                              <input
                                type="text"
                                id="facebookAdsAccessToken"
                                placeholder="EAAXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="facebookAdsPixelId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                Pixel ID
                              </label>
                              <input
                                type="text"
                                id="facebookAdsPixelId"
                                placeholder="XXXXXXXXXXXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <button className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300">
                              <i className="fa-solid fa-check mr-1"></i> 测试连接
                            </button>
                          </div>
                        )}
                        
                        {item.id === 'appleSearchAds' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="appleSearchAdsTeamId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                团队ID
                              </label>
                              <input
                                type="text"
                                id="appleSearchAdsTeamId"
                                placeholder="XXXXXXXXXX"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="appleSearchAdsClientId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                客户端ID
                              </label>
                              <input
                                type="text"
                                id="appleSearchAdsClientId"
                                placeholder="com.yourcompany.app"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <button className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300">
                              <i className="fa-solid fa-check mr-1"></i> 测试连接
                            </button>
                          </div>
                        )}
                        
                        {item.id === 'slack' && (
                          <div>
                            <label htmlFor="slackChannel" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                              Slack 频道
                            </label>
                            <input
                              type="text"
                              id="slackChannel"
                              placeholder="#game-notifications"
                              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                            />
                          </div>
                        )}
                        
                        {['googleAnalytics', 'firebase', 'discord', 'googlePlay', 'appStore'].includes(item.id) && (
                          <div>
                            <label htmlFor={`${item.id}ApiKey`} className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                              API Key
                            </label>
                            <input
                              type="text"
                              id={`${item.id}ApiKey`}
                              placeholder={`输入${item.label} API Key`}
                              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                            />
                          </div>
                        )}
                        
                        {item.id === 'googlePlay' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="googlePlayApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                API 密钥
                              </label>
                              <input
                                type="text"
                                id="googlePlayApiKey"
                                placeholder="输入Google Play API密钥"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="googlePlayAppId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                应用ID
                              </label>
                              <input
                                type="text"
                                id="googlePlayAppId"
                                placeholder="com.yourcompany.game"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                          </div>
                        )}
                        
                        {item.id === 'appStore' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="appStoreIssuerId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                Issuer ID
                              </label>
                              <input
                                type="text"
                                id="appStoreIssuerId"
                                placeholder="输入App Store Issuer ID"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="appStoreKeyId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                Key ID
                              </label>
                              <input
                                type="text"
                                id="appStoreKeyId"
                                placeholder="输入App Store Key ID"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="appStoreBundleId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                Bundle ID
                              </label>
                              <input
                                type="text"
                                id="appStoreBundleId"
                                placeholder="com.yourcompany.game"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                          </div>
                        )}
                        
                        {item.id === 'googleSdk' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="googleSdkApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                API 密钥
                              </label>
                              <input
                                type="text"
                                id="googleSdkApiKey"
                                placeholder="输入Google SDK API密钥"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="googleSdkClientId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                客户端ID
                              </label>
                              <input
                                type="text"
                                id="googleSdkClientId"
                                placeholder="输入Google SDK客户端ID"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <button className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300">
                              <i className="fa-solid fa-check mr-1"></i> 测试连接
                            </button>
                          </div>
                        )}
                        
                        {item.id === 'iosSdk' && (
                          <div className="space-y-3">
                            <div>
                              <label htmlFor="iosSdkBundleId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                Bundle ID
                              </label>
                              <input
                                type="text"
                                id="iosSdkBundleId"
                                placeholder="输入iOS应用Bundle ID"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="iosSdkApiKey" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                API 密钥
                              </label>
                              <input
                                type="text"
                                id="iosSdkApiKey"
                                placeholder="输入iOS SDK API密钥"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <div>
                              <label htmlFor="iosSdkTeamId" className="block text-xs font-medium text-gray-700 dark:text-gray-400 mb-1">
                                团队ID
                              </label>
                              <input
                                type="text"
                                id="iosSdkTeamId"
                                placeholder="输入Apple开发团队ID"
                                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                              />
                            </div>
                            <button className="w-full py-2 px-3 bg-green-100 text-green-800 text-xs font-medium rounded-md hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300">
                              <i className="fa-solid fa-check mr-1"></i> 测试连接
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        );
        
      case 'account':
        return (
          <div className="space-y-6">
            <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-gray-900 dark:text-gray-300 mb-3">账户信息</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">用户名</label>
                  <p className="text-sm text-gray-900 dark:text-white">管理员</p>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">邮箱</label>
                  <p className="text-sm text-gray-900 dark:text-white">admin@game.com</p>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">角色</label>
                  <p className="text-sm text-gray-900 dark:text-white">超级管理员</p>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">创建日期</label>
                  <p className="text-sm text-gray-900 dark:text-white">2025-01-15</p>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-900 dark:text-gray-300 mb-4">账户操作</h3>
              
              <div className="space-y-4">
                <button className="w-full flex justify-start items-center px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:bg-gray-700 dark:text-red-400 dark:border-red-700 dark:hover:bg-red-900/20">
                  <i className="fa-solid fa-user-times mr-2"></i>
                  删除账户
                </button>
                
                <button 
                  onClick={logout}
                  className="w-full flex justify-start items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600"
                >
                  <i className="fa-solid fa-sign-out-alt mr-2"></i>
                  退出登录
                </button>
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">系统设置</h1>
        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
          配置系统参数和个人偏好
        </p>
      </div>
      
      {/* Settings tabs */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow border border-gray-200 dark:border-gray-700">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="-mb-px flex flex-wrap">
            {[
              { id: 'general', name: '基本设置' },
              { id: 'notifications', name: '通知设置' },
              { id: 'security', name: '安全设置' },
              { id: 'integrations', name: '集成服务' },
              { id: 'account', name: '账户管理' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-4 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                {tab.name}
              </button>
            ))}
          </nav>
        </div>
        
        {/* Settings content */}
        <div className="p-6">
          {renderSettingsForm()}
        </div>
        
        {/* Save buttons */}
        {(activeTab !== 'account' && (
          <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={resetSettings}
              disabled={!isDirty}
              className={`px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium ${
                isDirty
                  ? 'text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600'
                  : 'text-gray-400 bg-gray-100 cursor-not-allowed dark:bg-gray-800 dark:text-gray-500'
              }`}
            >
              重置
            </button>
            <button
              onClick={saveSettings}
              disabled={!isDirty}
              className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                isDirty
                  ? 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900'
                  : 'bg-blue-300 cursor-not-allowed'
              }`}
            >
              保存设置
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}