import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from 'sonner';
import App from "./App.tsx";
import "./index.css";
import { DataService } from './services/db';
import { API_CONFIG } from './services/apiConfig';
import { toast } from 'sonner';
import { ApiService } from './services/api';

// 应用初始化
const initApp = () => {
  console.log('GamePortal 应用初始化...');
  
  // 初始化本地数据
  DataService.init();
  
  // 检查API配置
  if (API_CONFIG.baseUrl === 'https://api.your-game-domain.com') {
    toast.warning('注意：当前使用的是默认API地址，请在商业环境中配置实际API地址');
    
    // 显示后端集成指南
    setTimeout(() => {
      if (window.confirm('是否查看后端集成指南？')) {
        alert(`后端集成指南:\n\nPHP后端配置步骤:\n${API_CONFIG.integrationGuide.php.setupSteps.join('\n')}\n\n推荐PHP版本: ${API_CONFIG.integrationGuide.php.recommendedVersion}\n所需扩展: ${API_CONFIG.integrationGuide.php.requiredExtensions.join(', ')}\n\nAPI认证方式: ${API_CONFIG.integrationGuide.php.authentication}`);
      }
    }, 2000);
  }
  
  // 渲染应用
  createRoot(document.getElementById("root")!).render(
    <StrictMode>
      <BrowserRouter>
        <App />
        <Toaster position="top-right" />
      </BrowserRouter>
    </StrictMode>
  );
  
  console.log('GamePortal 应用初始化完成');
};

// 启动应用
initApp();