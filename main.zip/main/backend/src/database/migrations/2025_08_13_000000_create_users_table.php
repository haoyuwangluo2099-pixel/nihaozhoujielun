<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('users', function (Blueprint $table) {
    $table->id();
    $table->string('username')->unique();
    $table->string('email')->unique();
    $table->string('password');
    $table->string('role');
    $table->integer('level')->default(0);
    $table->string('country')->nullable();
    $table->string('status')->default('active');
    $table->string('avatar')->nullable();
    $table->timestamp('last_login')->nullable();
    $table->timestamps();
    $table->softDeletes();
});