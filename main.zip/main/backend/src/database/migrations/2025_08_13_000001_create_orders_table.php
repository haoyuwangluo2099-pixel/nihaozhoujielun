<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('orders', function (Blueprint $table) {
  $table->id();
  $table->foreignId('user_id')->constrained('users');
  $table->decimal('amount', 8, 2);
  $table->string('product');
  $table->string('status');
  $table->string('payment_method');
  $table->string('transaction_id')->nullable();
  $table->string('currency')->default('USD');
  $table->decimal('tax', 8, 2)->default(0);
  $table->decimal('total', 8, 2);
  // 新增字段以支持退款警告功能
  $table->string('platform')->default('unknown');
  $table->boolean('refund_warning')->default(0);
  $table->text('refund_reason')->nullable();
  $table->timestamps();
  
  // 添加索引以提高查询性能
  $table->index('status');
  $table->index('refund_warning');
  $table->index('platform');
});