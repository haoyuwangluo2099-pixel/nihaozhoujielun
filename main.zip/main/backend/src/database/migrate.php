<?php

require __DIR__ . '/../../vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

// Initialize database connection
require __DIR__ . '/connection.php';

// Run migrations
$migrationFiles = glob(__DIR__ . '/migrations/*.php');
usort($migrationFiles, function($a, $b) {
    return filemtime($a) - filemtime($b);
});

foreach ($migrationFiles as $file) {
    require $file;
    echo "Migrated: " . basename($file) . "\n";
}

echo "Migration completed successfully!\n";