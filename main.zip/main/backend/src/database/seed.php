<?php

require __DIR__ . '/../../vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../..');
$dotenv->load();

// Initialize database connection
require __DIR__ . '/connection.php';

// Import models
require __DIR__ . '/../models/User.php';
require __DIR__ . '/../models/Game.php';
require __DIR__ . '/../models/Order.php';
require __DIR__ . '/../models/Server.php';
require __DIR__ . '/../models/Event.php';

// Clear existing data
App\Models\User::truncate();
App\Models\Game::truncate();
App\Models\Order::truncate();
App\Models\Server::truncate();
App\Models\Event::truncate();

// Create users
$users = [
    [
        'username' => 'admin',
        'email' => 'admin@game.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'role' => 'admin',
        'level' => 0,
        'status' => 'active',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'username' => 'player123',
        'email' => 'player@example.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'role' => 'player',
        'level' => 45,
        'country' => 'US',
        'status' => 'active',
        'avatar' => 'https://space.coze.cn/api/coze_space/generate_image?prompt=player+avatar&sign=7835cdb995e7a67d2812e7e7d4209fb4',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'username' => 'gamer456',
        'email' => 'gamer456@example.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'role' => 'player',
        'level' => 67,
        'country' => 'JP',
        'status' => 'active',
        'avatar' => 'https://space.coze.cn/api/coze_space/generate_image?prompt=gamer+avatar&sign=46b00120bf5005a836de76813e0630b2',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]
];

foreach ($users as $user) {
    App\Models\User::create($user);
}

// Create games
$games = [
    [
        'name' => '星际冒险',
        'description' => '探索广阔的宇宙，与外星文明接触，展开一场史诗般的太空冒险。',
        'price' => 29.99,
        'rating' => 4.8,
        'genre' => '角色扮演',
        'release_date' => '2025-01-15',
        'players' => 1250000,
        'active_players' => 85000,
        'revenue' => 3650000,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => '魔法王国',
        'description' => '成为一名强大的魔法师，学习各种咒语，拯救被黑暗势力笼罩的王国。',
        'price' => 39.99,
        'rating' => 4.6,
        'genre' => '奇幻',
        'release_date' => '2025-02-20',
        'players' => 980000,
        'active_players' => 62000,
        'revenue' => 3920000,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'name' => '赛车传奇',
        'description' => '体验极速赛车的快感，解锁各种超级跑车，成为赛道上的传奇。',
        'price' => 49.99,
        'rating' => 4.5,
        'genre' => '竞速',
        'release_date' => '2025-03-10',
        'players' => 750000,
        'active_players' => 42000,
        'revenue' => 3740000,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]
];

foreach ($games as $game) {
    App\Models\Game::create($game);
}

// Create servers
$servers = [
    [
        'server_id' => 'us-west',
        'name' => '美国西部',
        'status' => 'online',
        'load' => 65,
        'users' => 45200,
        'uptime' => '99.9%',
        'location' => '美国加利福尼亚州',
        'ip' => '192.168.1.10',
        'last_restart' => '2025-08-01 03:00:00',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'server_id' => 'eu-central',
        'name' => '欧洲中部',
        'status' => 'online',
        'load' => 58,
        'users' => 38700,
        'uptime' => '99.8%',
        'location' => '德国法兰克福', 
        'ip' => '192.168.1.11',
        'last_restart' => '2025-08-05 04:00:00',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'server_id' => 'asia-east',
        'name' => '东亚',
        'status' => 'degraded',
        'load' => 82,
        'users' => 29500,
        'uptime' => '99.7%',
        'location' => '日本东京',
        'ip' => '192.168.1.12',
        'last_restart' => '2025-08-10 02:00:00',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]
];

foreach ($servers as $server) {
    App\Models\Server::create($server);
}

// Create events
$events = [
    [
        'title' => '夏日狂欢活动',
        'description' => '参与夏日主题活动，赢取限定皮肤和游戏道具',
        'start_date' => '2025-08-15 00:00:00',
        'end_date' => '2025-08-30 23:59:59',
        'status' => 'upcoming',
        'image' => 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Summer%20Game%20Event%2C%20vibrant%20colors%2C%20beach%20theme&sign=9351aa922e37f738ef9f31598588fdf9',
        'participants' => 0,
        'rewards' => '限定皮肤、游戏币、稀有道具',
        'type' => 'limited_time',
        'game_id' => 1,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'title' => '周年庆典',
        'description' => '庆祝游戏上线一周年，登录即可领取丰厚奖励',
        'start_date' => '2025-07-20 00:00:00',
        'end_date' => '2025-08-05 23:59:59',
        'status' => 'active',
        'image' => 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Game%20Anniversary%20Event%2C%20festive%20atmosphere%2C%20confetti&sign=04249382a5b8db64042d5013dc802c8d',
        'participants' => 125400,
        'rewards' => '周年限定称号、免费英雄、周年纪念皮肤',
        'type' => 'anniversary',
        'game_id' => 2,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]
];

foreach ($events as $event) {
    App\Models\Event::create($event);
}

// Create orders
$orders = [
    [
        'user_id' => 2,
        'amount' => 49.99,
        'product' => '高级会员 (1个月)',
        'status' => 'completed',
        'payment_method' => 'credit_card',
        'transaction_id' => 'txn_123456789',
        'currency' => 'USD',
        'tax' => 4.50,
        'total' => 54.49,
        'created_at' => '2025-08-10 09:25:00',
        'updated_at' => '2025-08-10 09:26:15'
    ],
    [
        'user_id' => 3,
        'amount' => 29.99,
        'product' => '钻石礼包',
        'status' => 'completed',
        'payment_method' => 'paypal',
        'transaction_id' => 'txn_987654321',
        'currency' => 'USD',
        'tax' => 2.70,
        'total' => 32.69,
        'created_at' => '2025-08-11 14:32:00',
        'updated_at' => '2025-08-11 14:33:45'
    ]
];

foreach ($orders as $order) {
    App\Models\Order::create($order);
}

echo "Seeding completed successfully!\n";
echo "Default admin credentials:\n";
echo "Email: admin@game.com\n";
echo "Password: password123\n";