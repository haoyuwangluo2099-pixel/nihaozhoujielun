<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Server extends Model
{
    protected $table = 'servers';
    protected $fillable = [
        'server_id', 'name', 'status', 'load', 'users', 
        'uptime', 'location', 'ip', 'last_restart'
    ];
    protected $primaryKey = 'server_id';
    public $incrementing = false;
}