<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Game extends Model
{
    protected $table = 'games';
    protected $fillable = [
        'name', 'description', 'price', 'rating', 'genre', 
        'release_date', 'image', 'features', 'platform', 
        'developer', 'publisher', 'tags', 'players', 
        'active_players', 'revenue'
    ];
    protected $casts = [
        'features' => 'array',
        'platform' => 'array',
        'tags' => 'array'
    ];
    
    public function events()
    {
        return $this->hasMany(Event::class);
    }
}