<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\User;

class UserController
{
    public function index(Request $request, Response $response)
    {
        $users = User::all();
        $response->getBody()->write(json_encode($users));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function show(Request $request, Response $response, $args)
    {
        $user = User::find($args['id']);
        if (!$user) {
            $response->getBody()->write(json_encode(['error' => 'User not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        $response->getBody()->write(json_encode($user));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function create(Request $request, Response $response)
    {
        $data = $request->getParsedBody();
        
        // Validate data
        if (empty($data['email']) || empty($data['password']) || empty($data['username'])) {
            $response->getBody()->write(json_encode(['error' => 'Missing required fields']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
        
        // Check if user already exists
        if (User::where('email', $data['email'])->exists() || User::where('username', $data['username'])->exists()) {
            $response->getBody()->write(json_encode(['error' => 'User already exists']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
        
        // Create user
        $user = new User();
        $user->username = $data['username'];
        $user->email = $data['email'];
        $user->password = password_hash($data['password'], PASSWORD_DEFAULT);
        $user->role = $data['role'] ?? 'player';
        $user->level = $data['level'] ?? 0;
        $user->status = 'active';
        $user->save();
        
        $response->getBody()->write(json_encode($user));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(201);
    }
    
    public function update(Request $request, Response $response, $args)
    {
        $user = User::find($args['id']);
        if (!$user) {
            $response->getBody()->write(json_encode(['error' => 'User not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        $data = $request->getParsedBody();
        
        // Update fields
        if (!empty($data['username'])) $user->username = $data['username'];
        if (!empty($data['email'])) $user->email = $data['email'];
        if (!empty($data['role'])) $user->role = $data['role'];
        if (isset($data['level'])) $user->level = $data['level'];
        if (!empty($data['country'])) $user->country = $data['country'];
        if (!empty($data['status'])) $user->status = $data['status'];
        if (!empty($data['avatar'])) $user->avatar = $data['avatar'];
        
        // Update password if provided
        if (!empty($data['password'])) {
            $user->password = password_hash($data['password'], PASSWORD_DEFAULT);
        }
        
        $user->save();
        
        $response->getBody()->write(json_encode($user));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function delete(Request $request, Response $response, $args)
    {
        $user = User::find($args['id']);
        if (!$user) {
            $response->getBody()->write(json_encode(['error' => 'User not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        // Prevent deletion of admin user
        if ($user->role === 'admin') {
            $response->getBody()->write(json_encode(['error' => 'Cannot delete admin user']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(403);
        }
        
        $user->delete();
        
        $response->getBody()->write(json_encode(['message' => 'User deleted successfully']));
        return $response->withHeader('Content-Type', 'application/json');
    }
}