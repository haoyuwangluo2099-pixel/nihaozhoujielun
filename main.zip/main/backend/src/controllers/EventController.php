<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Event;

class EventController
{
    public function index(Request $request, Response $response)
    {
        $events = Event::all();
        $response->getBody()->write(json_encode($events));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function show(Request $request, Response $response, $args)
    {
        $event = Event::find($args['id']);
        if (!$event) {
            $response->getBody()->write(json_encode(['error' => 'Event not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        $response->getBody()->write(json_encode($event));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function create(Request $request, Response $response)
    {
        $data = $request->getParsedBody();
        
        // Validate data
        if (empty($data['title']) || empty($data['description']) || empty($data['start_date']) || empty($data['end_date'])) {
            $response->getBody()->write(json_encode(['error' => 'Missing required fields']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
        
        // Create event
        $event = new Event();
        $event->title = $data['title'];
        $event->description = $data['description'];
        $event->start_date = $data['start_date'];
        $event->end_date = $data['end_date'];
        $event->status = $data['status'] ?? 'upcoming';
        $event->image = $data['image'] ?? null;
        $event->participants = 0;
        $event->rewards = $data['rewards'] ?? '';
        $event->type = $data['type'] ?? 'limited_time';
        $event->game_id = $data['game_id'] ?? null;
        $event->save();
        
        $response->getBody()->write(json_encode($event));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(201);
    }
}