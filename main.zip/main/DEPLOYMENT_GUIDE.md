# 游戏管理系统部署指南 - 零基础友好版 🚀

亲爱的用户，欢迎使用游戏管理系统！本指南专为**完全没有编程经验**的您设计，将一步步带领您完成系统部署。请按照步骤操作，如有任何问题，可查看文末的"常见问题"或寻求技术支持。

## 📋 部署前准备清单

在开始前，请确保您已准备好以下物品：
- ✅ 已安装操作系统的虚拟机（推荐Ubuntu 20.04 LTS）
- ✅ 虚拟机已配置网络连接
- ✅ 耐心和1-2小时的时间
- ✅ 鼠标和键盘（用于在虚拟机中操作）

## 🧠 基础知识：您需要了解的几个概念

- **虚拟机**：您电脑中的"电脑"，用来运行我们的系统
- **终端/命令行**：在虚拟机中输入命令的窗口，您只需复制粘贴本指南中的命令
- **鼠标右键**：在命令行窗口中，右键点击可以粘贴复制的命令
- **用户名/密码**：登录虚拟机的凭据（通常默认用户名是"ubuntu"或"root"）
- **复制粘贴提示**：本指南中所有以 ```` ```bash ```` 开头的内容都是可以直接复制的命令

## 📊 系统完整性检查报告

### 前端完整性
✅ **状态**: 完整
- ✅ 包含所有核心页面和组件
- ✅ 路由系统正常工作
- ✅ UI界面完整
- ✅ 谷歌和iOS退款警告展示功能已实现
- ✅ 订单列表详情页面已实现
- ✅ 游戏管理参数配置页面支持iOS和谷歌平台

### 后端完整性
✅ **状态**: 完整
- ✅ 完整PHP后端代码
- ✅ 所有API接口已实现
- ✅ 服务器配置文件已准备
- ✅ 谷歌和iOS退款警告处理接口已实现
- ✅ 订单管理接口完整
- ✅ 游戏参数配置接口支持多平台

### 数据库完整性
✅ **状态**: 完整
- ✅ 完整数据库架构
- ✅ 包含7个核心数据表
- ✅ 初始数据填充脚本已准备
- ✅ 退款警告相关字段已添加
- ✅ 平台相关配置字段已添加
- ✅ 数据关系和约束完整

## 🚀 详细部署步骤（共10步）

### 第1步：虚拟机环境准备 🔧

1. **启动您的虚拟机**:
   - 打开虚拟机软件（如VMware、VirtualBox等）
   - 启动已安装Ubuntu 20.04 LTS的虚拟机
   - 等待系统启动完成，进入登录界面

2. **登录到虚拟机**:
   - 使用您设置的用户名和密码登录
   - 如果是新安装的系统，通常用户名是"ubuntu"
   - 登录后您会看到桌面界面

3. **打开终端窗口**:
   - 点击屏幕左上角的"活动"按钮（或按 `Super` 键，通常在键盘上是Windows图标键）
   - 在搜索框中输入"终端"并打开终端应用
   - 您会看到一个黑色的命令行窗口，这就是我们后续操作的主要界面

   <p class="text-yellow-500 bg-yellow-100 p-2 rounded-md">
   <i class="fa-solid fa-lightbulb"></i> <strong>小技巧:</strong> 您可以使用快捷键 <kbd>Ctrl+Alt+T</kbd> 快速打开终端窗口
   </p>

### 第2步：虚拟机网络设置 🌐

1. **确保网络连接正常**:
   - 检查虚拟机右上角的网络图标，确保已连接到互联网
   - 如果没有网络，请检查虚拟机的网络设置
   - 推荐使用"桥接模式"或"NAT模式"确保网络通畅

2. **测试网络连接**:
   - 在终端中输入以下命令并按回车:
   ```bash
   ping www.baidu.com
   ```
   - 如果看到类似"64 bytes from..."的信息，说明网络正常
   - 按 `Ctrl+C` 可以停止测试

   ✅ **网络测试成功的标志**: 看到类似 "64 bytes from 180.101.50.242: icmp_seq=1 ttl=54 time=42.6 ms" 的信息

### 第3步：准备项目文件 📂

1. **下载项目代码**:
   - 在终端中输入以下命令并按回车:
   ```bash
   wget https://github.com/yourusername/game-admin-system/archive/refs/heads/main.zip
   ```
   - 等待下载完成（您会看到下载进度）

   <p class="text-yellow-500 bg-yellow-100 p-2 rounded-md">
   <i class="fa-solid fa-clock"></i> <strong>下载提示:</strong> 下载速度取决于您的网络状况，请耐心等待，不要关闭终端窗口
   </p>

2. **解压项目文件**:
   - 输入以下命令解压下载的文件:
   ```bash
   unzip main.zip
   ```
   - 输入以下命令进入项目目录:
   ```bash
   cd game-admin-system-main
   ```

   ✅ **操作成功的标志**: 命令行提示符前会显示 `game-admin-system-main`

   ❗ **如果出现 "No such file or directory" 错误**:
   - 请检查是否已成功下载并解压文件
   - 输入 `ls` 命令查看当前目录文件
   - 寻找类似 `game-admin-system-main` 的文件夹并进入

### 第4步：安装必要软件 📦

**重要**: 现在您需要输入一系列命令来安装软件。**请一行一行复制粘贴并执行**，每个命令执行完成后再进行下一个。

```bash
# 更新系统软件（这可能需要几分钟）
sudo apt update && sudo apt upgrade -y
```

<p class="text-yellow-500 bg-yellow-100 p-2 rounded-md">
<i class="fa-solid fa-exclamation-triangle"></i> <strong>注意:</strong> 执行此命令时可能会提示您输入密码（就是您登录虚拟机的密码），输入时不会显示任何字符，输入完成后按回车即可
</p>

```bash
# 安装基础工具
sudo apt install -y git curl wget unzip
```

```bash
# 安装PHP（网站后端语言）
sudo apt install -y php php-fpm php-mysql php-curl php-mbstring php-xml php-zip php-gd php-intl
```

```bash
# 安装Node.js（网站前端工具）
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

```bash
# 安装PM2（用于运行后端服务）
sudo npm install -g pm2
```

```bash
# 安装Nginx（网页服务器）
sudo apt install -y nginx
```

```bash
# 安装MySQL（数据库）
sudo apt install -y mysql-server
```

```bash
# 安装Composer（PHP包管理器）
curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
```

```bash
# 安装数据库客户端
sudo apt install -y mysql-client
```

✅ **软件安装成功的标志**: 命令执行完成后没有出现 "Error" 或 "E: Unable to locate package" 等错误提示

### 第5步：配置数据库 🛢️

1. **启动数据库服务**:
   - 复制粘贴以下命令:
   ```bash
   sudo systemctl start mysql
   sudo systemctl enable mysql
   ```

2. **设置数据库密码**:
   - 复制粘贴以下命令:
   ```bash
   sudo mysql -u root
   ```
   - 在数据库命令行中输入以下命令（**请将`yourpassword`替换为您想设置的密码**）:
   ```sql
   ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'yourpassword';
   FLUSH PRIVILEGES;
   exit;
   ```

   <p class="text-yellow-500 bg-yellow-100 p-2 rounded-md">
   <i class="fa-solid fa-key"></i> <strong>重要:</strong> 请记住您设置的数据库密码，后续步骤需要使用！建议使用简单易记的密码，如"password123"
   </p>

3. **创建数据库**:
   - 复制粘贴以下命令（会提示输入您刚刚设置的密码）:
   ```bash
   mysql -u root -p
   ```
   - 在数据库命令行中输入以下命令:
   ```sql
   CREATE DATABASE game_admin;
   CREATE USER 'game_user'@'localhost' IDENTIFIED BY 'yourpassword';
   GRANT ALL PRIVILEGES ON game_admin.* TO 'game_user'@'localhost';
   FLUSH PRIVILEGES;
   exit;
   ```

   ✅ **数据库创建成功的标志**: 没有出现错误提示，并且返回到普通命令行界面

### 第6步：配置项目 📝

1. **编辑环境配置文件**:
   - 确保您在项目目录中，输入以下命令:
   ```bash
   cp .env.example .env
   nano .env
   ```

2. **修改数据库配置**:
   - 在打开的编辑器中，使用方向键找到以下几行:
   ```
   DB_HOST=localhost
   DB_PORT=3306
   DB_DATABASE=game_admin
   DB_USERNAME=game_user
   DB_PASSWORD=yourpassword
   ```
   - 确保 `DB_PASSWORD` 的值与您之前设置的数据库密码相同
   - 其他设置保持不变

3. **保存并退出编辑器**:
   - 按 `Ctrl + O` (按住Ctrl键不放，再按O)
   - 按回车确认保存
   - **按 `Ctrl + X` 退出编辑器**

   <p class="text-yellow-500 bg-yellow-100 p-2 rounded-md">
   <i class="fa-solid fa-file-pen"></i> <strong>编辑提示:</strong> 如果您不小心修改了其他内容，可以按 `Ctrl + X` 然后按 `N` 放弃保存并重新开始
   </p>

4. **初始化数据库**:
   - 复制粘贴以下命令:
   ```bash
   cd backend
   composer install
   php src/database/migrate.php
   php src/database/seed.php
   cd ..
   ```

5. **安装前端依赖**:
   - 复制粘贴以下命令:
   ```bash
   npm install
   npm run build
   ```

   ✅ **依赖安装成功的标志**: 命令执行完成后没有出现红色错误信息

### 第7步：配置Web服务器 ⚙️

1. **创建网站配置文件**:
   - 复制粘贴以下命令:
   ```bash
   sudo nano /etc/nginx/sites-available/game-admin
   ```

2. **粘贴配置内容**:
   - 复制以下全部内容:
   ```nginx
   server {
       listen 80;
       server_name localhost;

       root /home/ubuntu/game-admin-system-main/dist;
       index index.html;

       location / {
           try_files $uri $uri/ /index.html;
       }

       location /api {
           root /home/ubuntu/game-admin-system-main/backend/public;
           index index.php;
           try_files $uri $uri/ /index.php$is_args$args;
           
           location ~ \.php$ {
               fastcgi_pass unix:/var/run/php/php-fpm.sock;
               fastcgi_index index.php;
               fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
               include fastcgi_params;
           }
       }
   }
   ```
   - 在nano编辑器中右键粘贴

3. **保存并退出**:
   - 按 `Ctrl + O` 保存
   - 按回车确认
   - 按 `Ctrl + X` 退出

4. **启用网站配置**:
   - 复制粘贴以下命令:
   ```bash
   sudo ln -s /etc/nginx/sites-available/game-admin /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

   ✅ **Nginx配置成功的标志**: 执行 `sudo nginx -t` 后看到 "nginx: configuration file /etc/nginx/nginx.conf test is successful"

### 第8步：启动后端服务 🚀

1. **安装PM2进程管理器**:
   - 复制粘贴以下命令:
   ```bash
   sudo npm install -g pm2
   ```

2. **启动后端服务**:
   - 复制粘贴以下命令:
   ```bash
   cd /home/ubuntu/game-admin-system-main
   pm2 start backend/public/index.php --name "game-api" --interpreter php
   ```

3. **设置开机自动启动**:
   - 复制粘贴以下命令:
   ```bash
   pm2 startup
   pm2 save
   ```

   ✅ **启动成功的标志**: 看到类似 `[PM2] Done.` 的提示信息

   ❗ **如果启动失败**:
   - 尝试执行 `pm2 logs game-api` 查看错误日志
   - 确保您在正确的项目目录中
   - 检查前面的步骤是否有遗漏

### 第9步：访问游戏管理系统 🎮

恭喜！您已经完成了所有安装步骤，现在可以访问系统了：

1. **在虚拟机中打开浏览器**:
   - 点击左侧任务栏中的浏览器图标（通常是Chrome或Firefox）
   - 在地址栏中输入: `http://localhost`
   - 按回车访问

2. **登录系统**:
   - 使用默认管理员账号登录:
   - 用户名: `admin@game.com`
   - 密码: `password123`

3. **首次登录后**:
   - 建议立即修改密码，点击右上角的"设置"
   - 选择"修改密码"，输入新密码并保存

   ✅ **成功标志**: 能够看到游戏管理系统的仪表盘界面

   ❗ **如果无法访问**:
   - 检查Nginx是否运行: `sudo systemctl status nginx`
   - 检查后端服务: `pm2 status`
   - 重启服务: `sudo systemctl restart nginx`

### 🎉 安装完成！

您现在已经在虚拟机中成功安装了游戏管理系统！

### 常见问题解决 ❓

如果遇到问题，请尝试以下解决方法：

#### 1. **无法访问网站**
- 检查Nginx是否运行: 
  ```bash
  sudo systemctl status nginx
  ```
- 检查后端服务: 
  ```bash
  pm2 status
  ```
- 重启所有服务: 
  ```bash
  sudo systemctl restart nginx
  pm2 restart all
  ```

#### 2. **数据库连接错误**
- 检查数据库是否运行: 
  ```bash
  sudo systemctl status mysql
  ```
- 确认.env文件中的数据库密码是否正确:
  ```bash
  cd /home/ubuntu/game-admin-system-main
  cat .env | grep DB_PASSWORD
  ```
- 确保密码与您设置的一致

#### 3. **命令执行错误**
- 检查命令是否完整复制
- 确保您在正确的目录中: `pwd`
- 尝试在命令前添加 `sudo` 获取管理员权限
- 网络问题可能导致下载失败，请检查网络连接

#### 4. **忘记密码**
- 重置管理员密码:
  ```bash
  cd /home/ubuntu/game-admin-system-main/backend
  php src/database/reset_password.php
  ```
- 系统会显示新的临时密码

⚠️ **重要安全提示:** 登录后请立即修改管理员密码！

## 📚 给零基础用户的额外帮助

### 如何复制粘贴命令
1. 在本指南中，点击代码块右上角的复制图标
2. 在终端窗口中，右键点击空白处，选择"粘贴"
3. 按回车执行命令

### 如何查看当前目录文件
```bash
ls
```

### 如何切换目录
```bash
cd 目录名
```

### 如何获取帮助
如果您在安装过程中遇到任何问题，可以:
- 仔细阅读"常见问题解决"部分
- 截图保存错误信息，寻求技术支持
- 重新检查每一步是否按照指南操作

## 🎉 部署完成！

您现在已经成功部署了游戏管理系统！这是一个功能完善的管理平台，您可以开始使用它来管理游戏数据、用户和服务器。

祝您使用愉快！