# Game Admin System

A comprehensive game management system with admin dashboard and player portal.

## Features

- Admin dashboard with key metrics and analytics
- User management and authentication
- Game data visualization and reporting
- Server status monitoring
- Event management
- Revenue tracking and analytics
- Content management
- Support ticket system

## Tech Stack

### Frontend
- React + TypeScript
- Tailwind CSS
- React Router
- Recharts for data visualization
- Font Awesome icons

### Backend (New!)
- PHP 8.1+
- Slim Framework
- Eloquent ORM
- MySQL database
- JWT authentication

## Getting Started

### Prerequisites
- Node.js 16+ and npm/yarn/pnpm
- PHP 8.1+ with required extensions
- MySQL database
- Composer (for PHP dependencies)

### Frontend Setup

1. Install dependencies:
```bash
pnpm install
```

2. Create `.env` file:
```
VITE_API_BASE_URL=http://localhost:8000/api
VITE_APP_VERSION=1.0.0
VITE_API_ENV=development
VITE_API_TIMEOUT=10000
```

3. Start development server:
```bash
pnpm dev
```

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Install PHP dependencies:
```bash
composer install
```

3. Create `.env` file:
```
APP_ENV=development
APP_DEBUG=true
APP_KEY=base64:your_app_key_here

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=game_admin
DB_USERNAME=root
DB_PASSWORD=your_password
DB_CHARSET=utf8mb4
DB_COLLATION=utf8mb4_unicode_ci

JWT_SECRET=your_jwt_secret_key
JWT_EXPIRY=3600

API_BASE_URL=http://localhost:8000/api
CORS_ALLOWED_ORIGINS=http://localhost:3000
```

4. Run database migrations:
```bash
php src/database/migrate.php
```

5. Seed initial data:
```bash
php src/database/seed.php
```

6. Start PHP development server:
```bash
composer start
```

## Default Credentials

After running the seed command, you can log in with:
- Email: admin@game.com
- Password: password123

## Deployment

### Frontend
Build the frontend for production:
```bash
pnpm build
```

### Backend
- Configure a production web server (Apache/Nginx)
- Set appropriate environment variables
- Run migrations on production database
- Configure SSL for secure connections

## License

MIT