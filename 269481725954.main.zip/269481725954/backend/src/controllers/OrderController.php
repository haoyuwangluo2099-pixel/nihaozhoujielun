<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Order;
use App\Models\User;

class OrderController
{
    public function index(Request $request, Response $response)
    {
        $orders = Order::all();
        $response->getBody()->write(json_encode($orders));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function show(Request $request, Response $response, $args)
    {
        $order = Order::find($args['id']);
        if (!$order) {
            $response->getBody()->write(json_encode(['error' => 'Order not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        $response->getBody()->write(json_encode($order));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    public function create(Request $request, Response $response)
    {
        $data = $request->getParsedBody();
        
        // Validate data
        if (empty($data['user_id']) || empty($data['amount']) || empty($data['product'])) {
            $response->getBody()->write(json_encode(['error' => 'Missing required fields']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }
        
        // Check if user exists
        if (!User::find($data['user_id'])) {
            $response->getBody()->write(json_encode(['error' => 'User not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        // Create order
        $order = new Order();
        $order->user_id = $data['user_id'];
        $order->amount = $data['amount'];
        $order->product = $data['product'];
        $order->status = 'pending';
        $order->payment_method = $data['payment_method'] ?? 'credit_card';
        $order->transaction_id = 'txn_' . rand(100000000, 999999999);
        $order->currency = $data['currency'] ?? 'USD';
        $order->tax = $data['tax'] ?? 0;
        $order->total = $data['amount'] + ($data['tax'] ?? 0);
        $order->platform = $data['platform'] ?? 'unknown';
        $order->refund_warning = $data['refund_warning'] ?? 0;
        $order->refund_reason = $data['refund_reason'] ?? null;
        $order->save();
        
        $response->getBody()->write(json_encode($order));
        return $response->withHeader('Content-Type', 'application/json')->withStatus(201);
    }
    
    // 新增退款警告处理接口
    public function handleRefundWarning(Request $request, Response $response, $args)
    {
        $order = Order::find($args['id']);
        if (!$order) {
            $response->getBody()->write(json_encode(['error' => 'Order not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        $data = $request->getParsedBody();
        
        $order->refund_warning = 1;
        $order->refund_reason = $data['reason'] ?? '未指定原因';
        $order->status = 'warning';
        $order->save();
        
        $response->getBody()->write(json_encode([
            'success' => true,
            'message' => '退款警告已处理',
            'order' => $order
        ]));
        return $response->withHeader('Content-Type', 'application/json');
    }
    
    // 解决退款警告接口
    public function resolveRefundWarning(Request $request, Response $response, $args)
    {
        $order = Order::find($args['id']);
        if (!$order) {
            $response->getBody()->write(json_encode(['error' => 'Order not found']));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
        }
        
        $order->refund_warning = 0;
        $order->status = 'completed';
        $order->save();
        
        $response->getBody()->write(json_encode([
            'success' => true,
            'message' => '退款警告已解决',
            'order' => $order
        ]));
        return $response->withHeader('Content-Type', 'application/json');
    }
}