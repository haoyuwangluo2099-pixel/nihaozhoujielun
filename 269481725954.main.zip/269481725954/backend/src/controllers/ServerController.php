<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Server;

class ServerController
{
    public function index(Request $request, Response $response)
    {
        $servers = Server::all();
        $response->getBody()->write(json_encode($servers));
        return $response->withHeader('Content-Type', 'application/json');
    }
}