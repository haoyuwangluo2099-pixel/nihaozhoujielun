<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'events';
    protected $fillable = [
        'title', 'description', 'start_date', 'end_date', 
        'status', 'image', 'participants', 'rewards', 
        'type', 'game_id', 'banner_image', 'rules', 'prize_pool'
    ];
    protected $casts = [
        'prize_pool' => 'array'
    ];
    
    public function game()
    {
        return $this->belongsTo(Game::class);
    }
}