<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = 'users';
    protected $fillable = [
        'username', 'email', 'password', 'role', 'level', 
        'country', 'status', 'avatar', 'last_login'
    ];
    protected $hidden = ['password'];
    
    public function orders()
    {
        return $this->hasMany(Order::class);
    }
    
    public function tickets()
    {
        return $this->hasMany(SupportTicket::class);
    }
}