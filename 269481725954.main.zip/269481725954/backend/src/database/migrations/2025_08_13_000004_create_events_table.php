<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('events', function (Blueprint $table) {
    $table->id();
    $table->string('title');
    $table->text('description');
    $table->dateTime('start_date');
    $table->dateTime('end_date');
    $table->string('status');
    $table->string('image')->nullable();
    $table->integer('participants')->default(0);
    $table->text('rewards')->nullable();
    $table->string('type')->nullable();
    $table->foreignId('game_id')->nullable()->constrained('games');
    $table->string('banner_image')->nullable();
    $table->text('rules')->nullable();
    $table->json('prize_pool')->nullable();
    $table->timestamps();
});