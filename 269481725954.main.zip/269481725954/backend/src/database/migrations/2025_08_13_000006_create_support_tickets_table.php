<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('support_tickets', function (Blueprint $table) {
    $table->id();
    $table->string('subject');
    $table->text('description');
    $table->string('status');
    $table->string('priority');
    $table->foreignId('user_id')->constrained('users');
    $table->string('category')->nullable();
    $table->string('platform')->nullable();
    $table->string('game_version')->nullable();
    $table->text('resolution')->nullable();
    $table->string('assigned_to')->nullable();
    $table->integer('replies')->default(0);
    $table->timestamps();
});