<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('servers', function (Blueprint $table) {
    $table->id();
    $table->string('server_id')->unique();
    $table->string('name');
    $table->string('status');
    $table->integer('load')->default(0);
    $table->integer('users')->default(0);
    $table->string('uptime')->default('0%');
    $table->string('location')->nullable();
    $table->string('ip')->nullable();
    $table->timestamp('last_restart')->nullable();
    $table->timestamps();
});