<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('games', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->text('description');
    $table->decimal('price', 8, 2);
    $table->float('rating');
    $table->string('genre');
    $table->date('release_date');
    $table->string('image')->nullable();
    $table->json('features')->nullable();
    $table->json('platform')->nullable();
    $table->string('developer')->nullable();
    $table->string('publisher')->nullable();
    $table->json('tags')->nullable();
    $table->integer('players')->default(0);
    $table->integer('active_players')->default(0);
    $table->decimal('revenue', 12, 2)->default(0);
    $table->timestamps();
});