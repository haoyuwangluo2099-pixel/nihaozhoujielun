<?php

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;

Capsule::schema()->create('content', function (Blueprint $table) {
    $table->id();
    $table->string('title');
    $table->string('type');
    $table->string('status');
    $table->text('content')->nullable();
    $table->foreignId('game_id')->nullable()->constrained('games');
    $table->string('image')->nullable();
    $table->json('tags')->nullable();
    $table->integer('views')->default(0);
    $table->integer('likes')->default(0);
    $table->string('video_url')->nullable();
    $table->string('author');
    $table->timestamps();
});