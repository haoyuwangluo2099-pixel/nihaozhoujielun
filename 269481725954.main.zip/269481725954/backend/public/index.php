<?php
require __DIR__ . '/../vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Create Slim app
$app = Slim\Factory\AppFactory::create();

// Add middleware
$app->addBodyParsingMiddleware();

// CORS middleware
$app->add(function ($request, $handler) {
    $response = $handler->handle($request);
    return $response
        ->withHeader('Access-Control-Allow-Origin', $_ENV['CORS_ALLOWED_ORIGINS'])
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
});

// Routes
$app->group('/api', function ($app) {
  // User routes
  $app->get('/users', 'App\Controllers\UserController:index');
  $app->get('/users/{id}', 'App\Controllers\UserController:show');
  $app->post('/users', 'App\Controllers\UserController:create');
  $app->put('/users/{id}', 'App\Controllers\UserController:update');
  $app->delete('/users/{id}', 'App\Controllers\UserController:delete');
  
  // Order routes
  $app->get('/orders', 'App\Controllers\OrderController:index');
  $app->get('/orders/{id}', 'App\Controllers\OrderController:show');
  $app->post('/orders', 'App\Controllers\OrderController:create');
  // 新增退款警告相关路由
  $app->post('/orders/{id}/refund-warning', 'App\Controllers\OrderController:handleRefundWarning');
  $app->post('/orders/{id}/resolve-warning', 'App\Controllers\OrderController:resolveRefundWarning');
  
  // Dashboard routes
  $app->get('/dashboard', 'App\Controllers\DashboardController:index');
  
  // Server routes
  $app->get('/servers', 'App\Controllers\ServerController:index');
  
  // Event routes
  $app->get('/events', 'App\Controllers\EventController:index');
  $app->get('/events/{id}', 'App\Controllers\EventController:show');
  $app->post('/events', 'App\Controllers\EventController:create');
});

// Handle OPTIONS requests
$app->options('/{routes:.+}', function ($request, $response, $args) {
    return $response;
});

// Run app
$app->run();