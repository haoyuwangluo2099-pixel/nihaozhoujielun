// 仪表盘模拟数据

// 关键指标数据
export const kpiData = {
  dau: {
    value: 125800,
    change: 12.5,
    trend: 'up',
    icon: 'fa-users'
  },
  mau: {
    value: 3245000,
    change: 8.2,
    trend: 'up',
    icon: 'fa-user-friends'
  },
  newUsers: {
    value: 18450,
    change: -2.1,
    trend: 'down',
    icon: 'fa-user-plus'
  },
  retention: {
    value: 42.8,
    change: 3.5,
    trend: 'up',
    icon: 'fa-recycle'
  },
  arpu: {
    value: 3.85,
    change: 5.2,
    trend: 'up',
    icon: 'fa-dollar-sign'
  },
  ltv: {
    value: 28.45,
    change: 7.8,
    trend: 'up',
    icon: 'fa-chart-line',
    prefix: '$'
  },
  revenue: {
    value: 485200,
    change: 15.7,
    trend: 'up',
    icon: 'fa-chart-line'
  }
};

// User growth trend data
export const userGrowthData = [
  { date: '1月', dau: 85000, mau: 2400000, newUsers: 12000 },
  { date: '2月', dau: 92000, mau: 2550000, newUsers: 14500 },
  { date: '3月', dau: 98000, mau: 2680000, newUsers: 15200 },
  { date: '4月', dau: 105000, mau: 2800000, newUsers: 16800 },
  { date: '5月', dau: 112000, mau: 2950000, newUsers: 17500 },
  { date: '6月', dau: 118000, mau: 3100000, newUsers: 18200 },
  { date: '7月', dau: 125800, mau: 3245000, newUsers: 18450 },
];

// Daily game metrics data
export const dailyMetricsData = [
  { date: '00:00', newUsers: 120, dau: 4500, payingUsers: 85, newPayingUsers: 12, revenue: 420 },
  { date: '03:00', newUsers: 85, dau: 3200, payingUsers: 60, newPayingUsers: 8, revenue: 280 },
  { date: '06:00', newUsers: 60, dau: 2800, payingUsers: 45, newPayingUsers: 5, revenue: 210 },
  { date: '09:00', newUsers: 210, dau: 6500, payingUsers: 150, newPayingUsers: 25, revenue: 850 },
  { date: '12:00', newUsers: 320, dau: 8200, payingUsers: 210, newPayingUsers: 35, revenue: 1250 },
  { date: '15:00', newUsers: 480, dau: 12500, payingUsers: 320, newPayingUsers: 58, revenue: 2100 },
  { date: '18:00', newUsers: 520, dau: 15800, payingUsers: 450, newPayingUsers: 82, revenue: 3200 },
  { date: '21:00', newUsers: 380, dau: 14200, payingUsers: 380, newPayingUsers: 65, revenue: 2800 },
];

// 收入趋势数据
export const revenueData = [
  { date: '1月', revenue: 280000, arpu: 2.95, payingUsers: 95000 },
  { date: '2月', revenue: 310000, arpu: 3.10, payingUsers: 100000 },
  { date: '3月', revenue: 345000, arpu: 3.25, payingUsers: 106000 },
  { date: '4月', revenue: 380000, arpu: 3.40, payingUsers: 112000 },
  { date: '5月', revenue: 420000, arpu: 3.55, payingUsers: 118000 },
  { date: '6月', revenue: 450000, arpu: 3.70, payingUsers: 122000 },
  { date: '7月', revenue: 485200, arpu: 3.85, payingUsers: 126000 },
];

// 用户地区分布数据
export const regionData = [
  { name: '美国', value: 35 },
  { name: '欧洲', value: 28 },
  { name: '东南亚', value: 18 },
  { name: '日韩', value: 12 },
  { name: '其他', value: 7 },
];

// 游戏列表数据
export const gamesData = [
  { id: 1, name: '星际冒险' },
  { id: 2, name: '魔法王国' },
   { id: 3, name: '赛车传奇' },
   { id: 4, name: '篮球大师' },
  { id: 4, name: '篮球大师' },
];

// 区服列表数据
export const serversData = [
  { id: 1, gameId: 1, name: '星际一区' },
  { id: 2, gameId: 1, name: '星际二区' },
  { id: 3, gameId: 2, name: '魔法一区' },
  { id: 4, gameId: 2, name: '魔法二区' },
  { id: 5, gameId: 3, name: '赛车一区' },
  { id: 6, gameId: 4, name: '篮球一区' },
];

// 游戏区服留存率数据
export const retentionData = {
  1: { // 星际冒险
    1: [ // 星际一区
      { day: '1', retention: 100 },
      { day: '3', retention: 68 },
      { day: '7', retention: 45 },
      { day: '14', retention: 32 },
      { day: '30', retention: 22 },
    ],
    2: [ // 星际二区
      { day: '1', retention: 100 },
      { day: '3', retention: 62 },
      { day: '7', retention: 40 },
      { day: '14', retention: 28 },
      { day: '30', retention: 18 },
    ]
  },
  2: { // 魔法王国
    3: [ // 魔法一区
      { day: '1', retention: 100 },
      { day: '3', retention: 72 },
      { day: '7', retention: 52 },
      { day: '14', retention: 38 },
      { day: '30', retention: 25 },
    ],
    4: [ // 魔法二区
      { day: '1', retention: 100 },
      { day: '3', retention: 65 },
      { day: '7', retention: 48 },
      { day: '14', retention: 35 },
      { day: '30', retention: 22 },
    ]
  },
  3: { // 赛车传奇
    5: [ // 赛车一区
      { day: '1', retention: 100 },
      { day: '3', retention: 58 },
      { day: '7', retention: 35 },
      { day: '14', retention: 22 },
      { day: '30', retention: 15 },
    ]
  },
  4: { // 篮球大师
    6: [ // 篮球一区
      { day: '1', retention: 100 },
      { day: '3', retention: 60 },
      { day: '7', retention: 38 },
      { day: '14', retention: 25 },
      { day: '30', retention: 18 },
    ]
  }
};

// 游戏区服LTV数据
export const ltvData = {
  1: { // 星际冒险
    1: [ // 星际一区
      { month: '1', ltv: 25.5 },
      { month: '2', ltv: 32.8 },
      { month: '3', ltv: 38.2 },
      { month: '4', ltv: 42.5 },
      { month: '5', ltv: 45.8 },
      { month: '6', ltv: 48.2 },
    ],
    2: [ // 星际二区
      { month: '1', ltv: 22.3 },
      { month: '2', ltv: 28.5 },
      { month: '3', ltv: 33.2 },
      { month: '4', ltv: 36.8 },
      { month: '5', ltv: 39.5 },
      { month: '6', ltv: 41.2 },
    ]
  },
  2: { // 魔法王国
    3: [ // 魔法一区
      { month: '1', ltv: 30.2 },
      { month: '2', ltv: 38.5 },
      { month: '3', ltv: 45.2 },
      { month: '4', ltv: 50.8 },
      { month: '5', ltv: 54.5 },
      { month: '6', ltv: 57.2 },
    ],
    4: [ // 魔法二区
      { month: '1', ltv: 28.5 },
      { month: '2', ltv: 35.2 },
      { month: '3', ltv: 40.8 },
      { month: '4', ltv: 45.2 },
      { month: '5', ltv: 48.5 },
      { month: '6', ltv: 51.2 },
    ]
  },
  3: { // 赛车传奇
    5: [ // 赛车一区
      { month: '1', ltv: 18.5 },
      { month: '2', ltv: 24.2 },
      { month: '3', ltv: 28.8 },
      { month: '4', ltv: 32.5 },
      { month: '5', ltv: 35.2 },
      { month: '6', ltv: 37.8 },
    ]
  },
  4: { // 篮球大师
    6: [ // 篮球一区
      { month: '1', ltv: 20.8 },
      { month: '2', ltv: 26.5 },
      { month: '3', ltv: 31.2 },
      { month: '4', ltv: 34.8 },
      { month: '5', ltv: 37.5 },
      { month: '6', ltv: 39.8 },
    ]
  }
};

// 最近活动数据
export const recentActivities = [
  { id: 1, title: '新用户注册量突破历史新高', time: '今天 09:24', status: 'success' },
  { id: 2, title: '服务器维护已完成', time: '昨天 16:45', status: 'info' },
  { id: 3, title: '新活动"夏日狂欢"已上线', time: '昨天 10:12', status: 'info' },
  { id: 4, title: 'iOS退款警告通知', time: '今天 11:30', status: 'warning' },
  { id: 5, title: 'Google退款申请处理', time: '今天 10:15', status: 'warning' },
  { id: 6, title: '版本更新 v2.3.0 已发布', time: '3天前', status: 'success' }
];

// 服务器状态数据
export const serverStatus = [
  { id: 'us-west', name: '美国西部', status: 'online', load: 65, users: 45200 },
  { id: 'eu-central', name: '欧洲中部', status: 'online', load: 58, users: 38700 },
  { id: 'asia-east', name: '东亚', status: 'degraded', load: 82, users: 29500 },
  { id: 'sea-south', name: '东南亚', status: 'online', load: 72, users: 21400 },
  { id: 'us-east', name: '美国东部', status: 'maintenance', load: 0, users: 0 },
];

// 内容管理模拟数据
export const contentItems = [
  { 
    id: 1, 
    title: "《星际冒险》新版本更新公告", 
    type: "announcement", 
    status: "published", 
    createdAt: "2025-08-10",
    updatedAt: "2025-08-10",
    author: "管理员"
  },
  { 
    id: 2, 
    title: "夏日活动宣传图", 
    type: "image", 
    status: "published", 
    createdAt: "2025-08-05",
    updatedAt: "2025-08-05",
    author: "管理员"
  },
  { 
    id: 3, 
    title: "新英雄介绍视频", 
    type: "video", 
    status: "draft", 
    createdAt: "2025-08-12",
    updatedAt: "2025-08-12",
    author: "内容编辑"
  },
  { 
    id: 4, 
    title: "游戏内商店更新", 
    type: "announcement", 
    status: "scheduled", 
    createdAt: "2025-08-08",
    updatedAt: "2025-08-09",
    author: "管理员",
    scheduledTime: "2025-08-15T10:00:00Z"
  }
];

// 支持工单模拟数据
export const supportTickets = [
  { 
    id: 1001, 
    user: "player123", 
    subject: "无法登录游戏", 
    status: "resolved", 
    priority: "high", 
    createdAt: "2025-08-12T08:30:00Z",
    updatedAt: "2025-08-12T09:15:00Z",
    assignedTo: "support_agent1",
    replies: 3
  },
  { 
    id: 1002, 
    user: "gamer456", 
    subject: "支付失败问题", 
    status: "in_progress", 
    priority: "high", 
    createdAt: "2025-08-12T09:45:00Z",
    updatedAt: "2025-08-12T10:00:00Z",
    assignedTo: "support_agent2",
    replies: 1
  },
  { 
    id: 1003, 
    user: "proplayer789", 
    subject: "游戏卡顿问题", 
    status: "pending", 
    priority: "medium", 
    createdAt: "2025-08-12T11:20:00Z",
    updatedAt: "2025-08-12T11:20:00Z",
    assignedTo: null,
    replies: 0
  },
  { 
    id: 1004, 
    user: "casualplayer", 
    subject: "账号被盗申诉", 
    status: "in_progress", 
    priority: "high", 
    createdAt: "2025-08-11T16:30:00Z",
    updatedAt: "2025-08-12T09:30:00Z",
    assignedTo: "support_agent1",
    replies: 4
  },
  { 
    id: 1005, 
    user: "mobilegamer", 
    subject: "游戏崩溃问题", 
    status: "pending", 
    priority: "medium", 
    createdAt: "2025-08-12T14:10:00Z",
    updatedAt: "2025-08-12T14:10:00Z",
    assignedTo: null,
    replies: 0
  }
];

// 系统日志模拟数据
export const systemLogs = [
  { 
    id: 1, 
    user: "admin", 
    action: "用户管理", 
    details: "更新了用户 player123 的账号状态", 
    ipAddress: "192.168.1.100", 
    timestamp: "2025-08-12T09:15:32Z"
  },
  { 
    id: 2, 
    user: "support_agent1", 
    action: "工单处理", 
    details: "解决了工单 #1001", 
    ipAddress: "192.168.1.101", 
    timestamp: "2025-08-12T09:15:00Z"
  },
  { 
    id: 3, 
    user: "admin", 
    action: "内容管理", 
    details: "发布了新公告《星际冒险》新版本更新公告", 
    ipAddress: "192.168.1.100", 
    timestamp: "2025-08-12T08:30:15Z"
  },
  { 
    id: 4, 
    user: "system", 
    action: "服务器状态", 
    details: "美国东部服务器进入维护状态", 
    ipAddress: "系统自动操作", 
    timestamp: "2025-08-12T02:00:00Z"
  },
  { 
    id: 5, 
    user: "content_editor", 
    action: "内容管理", 
    details: "创建了新视频内容《新英雄介绍视频》", 
    ipAddress: "192.168.1.102", 
    timestamp: "2025-08-12T14:25:45Z"
  }
];

// 角色权限模拟数据
export const roles = [
  { 
    id: 1, 
    name: "超级管理员", 
    description: "拥有系统所有权限", 
    usersCount: 1,
    permissions: [
      "user_management", "game_data", "revenue_analysis", "server_management", 
      "event_management", "ad_monitoring", "order_management", "content_management",
      "support_tickets", "system_logs", "role_management", "settings"
    ]
  },
  { 
    id: 2, 
    name: "运营管理员", 
    description: "负责游戏运营相关功能", 
    usersCount: 3,
    permissions: [
      "user_management", "game_data", "revenue_analysis", "event_management", 
      "ad_monitoring", "order_management", "content_management", "support_tickets"
    ]
  },
  { 
    id: 3, 
    name: "客服人员", 
    description: "处理用户支持工单", 
    usersCount: 5,
    permissions: ["support_tickets"]
  },
  { 
    id: 4, 
    name: "内容编辑", 
    description: "管理游戏内内容和公告", 
    usersCount: 2,
    permissions: ["content_management"]
  },
  { 
    id: 5, 
    name: "只读用户", 
    description: "只能查看数据，无修改权限", 
    usersCount: 4,
    permissions: []
  }
];

// 游戏详细指标数据
export const gameMetricsData = [
  {
    date: '2025-08-13',
    game: '星际冒险',
    login: 95,
    register: 14,
    registerIos: 0,
    registerAndroid: 14,
    rechargeUsers: 1,
    paymentRate: '1.05%',
    rechargeAmount: '$19.98',
    arpu: '$19.98',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-13',
    game: '魔法王国',
    login: 50,
    register: 9,
    registerIos: 0,
    registerAndroid: 9,
    rechargeUsers: 1,
    paymentRate: '2.00%',
    rechargeAmount: '$16.99',
    arpu: '$16.99',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-13',
    game: '赛车传奇',
    login: 18,
    register: 3,
    registerIos: 0,
    registerAndroid: 3,
    rechargeUsers: 0,
    paymentRate: '0.00%',
    rechargeAmount: '$0.00',
    arpu: '0',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-12',
    game: '星际冒险',
    login: 129,
    register: 29,
    registerIos: 0,
    registerAndroid: 29,
    rechargeUsers: 2,
    paymentRate: '1.55%',
    rechargeAmount: '$34.97',
    arpu: '$17.48',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-12',
    game: '魔法王国',
    login: 60,
    register: 10,
    registerIos: 0,
    registerAndroid: 10,
    rechargeUsers: 2,
    paymentRate: '3.33%',
    rechargeAmount: '$21.80',
    arpu: '$1.09',
    newRechargeUsers: 1,
    newRechargeAmount: '$1.09',
    newUserPaymentRate: '10.00%'
  },
  {
    date: '2025-08-12',
    game: '赛车传奇',
    login: 18,
    register: 4,
    registerIos: 0,
    registerAndroid: 4,
    rechargeUsers: 0,
    paymentRate: '0.00%',
    rechargeAmount: '$0.00',
    arpu: '0',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-11',
    game: '星际冒险',
    login: 144,
    register: 47,
    registerIos: 0,
    registerAndroid: 47,
    rechargeUsers: 7,
    paymentRate: '4.86%',
    rechargeAmount: '$67.91',
    arpu: '$9.70',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-11',
    game: '魔法王国',
    login: 60,
    register: 12,
    registerIos: 0,
    registerAndroid: 12,
    rechargeUsers: 2,
    paymentRate: '3.33%',
    rechargeAmount: '$56.04',
    arpu: '$28.02',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-11',
    game: '赛车传奇',
    login: 13,
    register: 2,
    registerIos: 0,
    registerAndroid: 2,
    rechargeUsers: 0,
    paymentRate: '0.00%',
    rechargeAmount: '$0.00',
    arpu: '0',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-10',
    game: '星际冒险',
    login: 155,
    register: 37,
    registerIos: 0,
    registerAndroid: 37,
    rechargeUsers: 10,
    paymentRate: '6.45%',
    rechargeAmount: '$98.84',
    arpu: '$9.88',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-10',
    game: '魔法王国',
    login: 59,
    register: 15,
    registerIos: 0,
    registerAndroid: 15,
    rechargeUsers: 3,
    paymentRate: '5.08%',
    rechargeAmount: '$18.65',
    arpu: '$6.22',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  },
  {
    date: '2025-08-10',
    game: '赛车传奇',
    login: 12,
    register: 2,
    registerIos: 0,
    registerAndroid: 2,
    rechargeUsers: 0,
    paymentRate: '0.00%',
    rechargeAmount: '$0.00',
    arpu: '0',
    newRechargeUsers: 0,
    newRechargeAmount: '$0.00',
    newUserPaymentRate: '0.00%'
  }
];

// 确保数据按日期倒序排列
gameMetricsData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

// 广告监控数据
export const adPerformanceData = [
  { date: '1月', impressions: 1250000, clicks: 45200, ctr: 3.62, cpc: 0.85, conversions: 2850, cost: 38420 },
  { date: '2月', impressions: 1420000, clicks: 52800, ctr: 3.72, cpc: 0.82, conversions: 3240, cost: 43300 },
  { date: '3月', impressions: 1680000, clicks: 65400, ctr: 3.89, cpc: 0.79, conversions: 3870, cost: 51670 },
  { date: '4月', impressions: 1850000, clicks: 72100, ctr: 3.89, cpc: 0.78, conversions: 4250, cost: 56240 },
  { date: '5月', impressions: 2100000, clicks: 84600, ctr: 4.03, cpc: 0.76, conversions: 4980, cost: 64300 },
  { date: '6月', impressions: 2350000, clicks: 95200, ctr: 4.05, cpc: 0.75, conversions: 5640, cost: 71400 },
  { date: '7月', impressions: 2580000, clicks: 108500, ctr: 4.21, cpc: 0.73, conversions: 6420, cost: 79200 },
];

// 广告渠道数据
export const adChannelsData = [
  { name: 'Google Ads', impressions: 35, clicks: 38, conversions: 42, cost: 40, status: 'active' },
  { name: 'Facebook', impressions: 28, clicks: 29, conversions: 27, cost: 25, status: 'active' },
  { name: 'TikTok', impressions: 18, clicks: 15, conversions: 14, cost: 18, status: 'inactive' },
  { name: 'Instagram', impressions: 12, clicks: 10, conversions: 9, cost: 10, status: 'active' },
  { name: 'Apple Search Ads', impressions: 8, clicks: 7, conversions: 5, cost: 12, status: 'active' },
  { name: '其他', impressions: 7, clicks: 8, conversions: 8, cost: 7, status: 'active' },
];