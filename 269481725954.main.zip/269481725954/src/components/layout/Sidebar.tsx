import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface SidebarProps {
  open: boolean;
  toggleSidebar: () => void;
}

const navItems = [
  { name: '仪表盘', icon: 'fa-tachometer-alt', path: '/' },
  { name: '用户管理', icon: 'fa-users', path: '/users' },
  { name: '游戏数据', icon: 'fa-chart-line', path: '/game-data' },
  { name: '游戏管理', icon: 'fa-gamepad', path: '/game-management' },
  { name: '收入分析', icon: 'fa-chart-pie', path: '/revenue' },
  { name: '订单管理', icon: 'fa-shopping-cart', path: '/orders' },

  { name: '广告监控', icon: 'fa-bullhorn', path: '/ad-monitoring' },
  { name: '活动管理', icon: 'fa-calendar-alt', path: '/events' },
  { name: '内容管理', icon: 'fa-file-alt', path: '/content' },
  { name: '客户支持', icon: 'fa-headphones', path: '/support' },
  { name: '系统日志', icon: 'fa-history', path: '/logs' },
  { name: '角色权限', icon: 'fa-shield-alt', path: '/roles' },
  { name: '设置', icon: 'fa-cog', path: '/settings' },
];

export default function Sidebar({ open, toggleSidebar }: SidebarProps) {
  const location = useLocation();
  
  return (
    <div 
      className={cn(
        "fixed inset-y-0 z-50 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 ease-in-out",
        open ? "w-64" : "w-20 md:w-24"
      )}
    >
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700">
        <div className={cn("flex items-center space-x-2", !open && "justify-center w-full")}>
          <i className="fa-solid fa-gamepad text-blue-600 text-xl"></i>
          {open && <span className="font-bold text-lg">GameAdmin</span>}
        </div>
        <button 
          onClick={toggleSidebar}
          className={cn("p-1 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700", !open && "hidden")}
        >
          <i className="fa-solid fa-chevron-left"></i>
        </button>
      </div>
    
    {/* Navigation Links */}
  <div className="px-2 pt-2 pb-3 space-y-1">
    {navItems.map((item) => (
      <Link
        key={item.name}
        to={item.path}
        className="group flex items-center px-3 py-3 text-base font-medium rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
      >
        <i className={`fa-solid ${item.icon} mr-3 text-lg text-gray-400 group-hover:text-gray-500 dark:text-gray-400 dark:group-hover:text-white`}></i>
        {item.name}
      </Link>
    ))}
  </div>
    
    </div>
  );
}