import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface KpiCardProps {
  title: string;
  value: number | string;
  change: number;
  trend: 'up' | 'down';
  icon: string;
  formatValue?: (value: number) => string;
  description?: string;
  isCritical?: boolean;
}

export default function KpiCard({ 
  title, 
  value, 
  change, 
  trend, 
  icon,
  formatValue 
}: KpiCardProps) {
  // Format value if formatter is provided
  const formattedValue = formatValue && typeof value === 'number' 
    ? formatValue(value) 
    : value;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
          <h3 className="mt-1 text-2xl font-semibold text-gray-900 dark:text-white">{formattedValue}</h3>
          <div className={cn(
            "mt-1 flex items-center text-sm",
            trend === 'up' ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"
          )}>
            {trend === 'up' ? (
              <i className="fa-solid fa-arrow-up mr-1"></i>
            ) : (
              <i className="fa-solid fa-arrow-down mr-1"></i>
            )}
            <span>{Math.abs(change)}%</span>
            <span className="ml-1 text-gray-500 dark:text-gray-400">vs 上月</span>
          </div>
        </div>
        <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
          <i className={`fa-solid ${icon}`}></i>
        </div>
      </div>
    </div>
  );
}