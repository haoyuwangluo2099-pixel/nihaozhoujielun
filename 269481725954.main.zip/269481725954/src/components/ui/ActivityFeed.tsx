import { recentActivities } from '@/mocks/dashboardData';
import { cn } from '@/lib/utils';

export default function ActivityFeed() {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <i className="fa-solid fa-check-circle text-green-500"></i>;
      case 'warning':
        return <i className="fa-solid fa-exclamation-circle text-yellow-500"></i>;
      case 'info':
        return <i className="fa-solid fa-info-circle text-blue-500"></i>;
      default:
        return <i className="fa-solid fa-circle text-gray-500"></i>;
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-100 dark:border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">最近活动</h3>
        <button className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-500 dark:hover:text-blue-300">
          查看全部
        </button>
      </div>
      
      <div className="space-y-4">
        {recentActivities.map((activity) => (
          <div key={activity.id} className="flex">
            <div className="flex-shrink-0 mt-0.5">{getStatusIcon(activity.status)}</div>
            <div className="ml-3">
              <p className="text-sm text-gray-900 dark:text-gray-100">{activity.title}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}