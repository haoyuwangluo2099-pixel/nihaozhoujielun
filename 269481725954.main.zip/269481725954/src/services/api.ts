import { toast } from 'sonner';
import { API_CONFIG } from './apiConfig';
import type { RequestInit } from 'node-fetch';

/**
  * API服务 - 后端集成增强版
  * 修复: 添加了更健壮的错误处理和模拟数据回退机制
 * 支持完整的API请求生命周期管理、错误处理、缓存和后端集成
 */
export class ApiService {
  // 缓存存储
  private static cache = new Map<string, { data: any; timestamp: number }>();
  
  // 检查是否使用真实API
  private static useRealAPI(): boolean {
    return !!API_CONFIG.baseUrl && API_CONFIG.baseUrl !== 'https://api.your-game-domain.com';
  }
  
  // 获取完整API URL
  private static getFullUrl(endpoint: string): string {
    return `${API_CONFIG.baseUrl}${endpoint}`;
  }
  
  // 通用API请求方法
  private static async request<T>(
    endpoint: string, 
    options: RequestInit = {},
    cacheTime: number = 0 // 缓存时间(秒)，0表示不缓存
  ): Promise<T> {
    const url = this.getFullUrl(endpoint);
    const cacheKey = `${url}-${JSON.stringify(options)}`;
    
    // 检查缓存
    if (cacheTime > 0 && options.method === 'GET') {
      const cachedData = this.cache.get(cacheKey);
      if (cachedData && Date.now() - cachedData.timestamp < cacheTime * 1000) {
        return cachedData.data as T;
      }
    }
    
    // 检查API配置是否有效
    if (!this.isValidApiConfig()) {
      console.warn('API配置无效，将使用模拟数据');
      return this.mockRequest<T>(endpoint, options);
    }
    
    if (!this.useRealAPI()) {
      // 使用模拟数据
      const mockData = await this.mockRequest<T>(endpoint, options);
      
      // 缓存模拟数据
      if (cacheTime > 0 && options.method === 'GET') {
        this.cache.set(cacheKey, {
          data: mockData,
          timestamp: Date.now()
        });
      }
      
      return mockData;
    }
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.timeout);
    
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          ...API_CONFIG.defaultHeaders,
          'Authorization': `Bearer ${this.getAuthToken()}`,
          ...options.headers,
        },
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      // 处理JSON响应
      let responseData: any;
      try {
        responseData = await response.json();
      } catch (e) {
        responseData = { status: response.status, statusText: response.statusText };
      }
      
      if (!response.ok) {
        this.handleApiError(response.status, responseData);
        throw new Error(responseData?.message || `API错误: ${response.status}`);
      }
      
      // 缓存成功的GET请求
      if (cacheTime > 0 && options.method === 'GET') {
        this.cache.set(cacheKey, {
          data: responseData,
          timestamp: Date.now()
        });
      }
      
      return responseData as T;
    } catch (error) {
      return this.handleRequestError(error, endpoint, options);
    }
  }
  
  // 处理API错误
  private static handleApiError(statusCode: number, errorData: any): void {
    switch (statusCode) {
      case 401:
        toast.error('身份验证失败，请重新登录');
        // 可以在这里添加自动登出逻辑
        break;
      case 403:
        toast.error('您没有访问该资源的权限');
        break;
      case 404:
        toast.error('请求的资源不存在');
        break;
      case 500:
        toast.error('服务器内部错误，请稍后重试');
        break;
      default:
        toast.error(`API请求失败: ${errorData?.message || '未知错误'}`);
    }
  }
  
  // 处理请求错误
  private static async handleRequestError<T>(error: any, endpoint: string, options: RequestInit): Promise<T> {
    if (error.name === 'AbortError') {
      toast.error('请求超时，请检查网络连接');
    } else if (!navigator.onLine) {
      toast.error('网络连接中断，正在使用本地缓存数据');
      // 尝试从缓存获取
      const cacheKey = `${this.getFullUrl(endpoint)}-${JSON.stringify(options)}`;
      const cachedData = this.cache.get(cacheKey);
      if (cachedData) {
        return cachedData.data as T;
      }
      // 回退到localStorage
      return this.localStorageRequest<T>(endpoint, options);
    } else {
      toast.error(`请求失败: ${error.message || '未知错误'}`);
    }
    throw error;
  }
  
  // 获取认证令牌
  private static getAuthToken(): string | null {
    // 在实际应用中，这里应该从安全存储中获取令牌
    return localStorage.getItem('auth_token');
  }
  
  /**
   * 检查API配置是否有效
   */
  private static isValidApiConfig(): boolean {
    try {
      if (!this.baseUrl) return false;
      new URL(this.baseUrl);
      return this.baseUrl !== 'http://localhost:8000/api' || this.pingApiServer();
    } catch (error) {
      return false;
    }
  }
  
  /**
   * 简单ping API服务器检查连接
   */
  private static async pingApiServer(): Promise<boolean> {
    try {
      const controller = new AbortController();
      setTimeout(() => controller.abort(), 2000);
      
      await fetch(`${this.baseUrl}/health`, { 
        signal: controller.signal,
        method: 'HEAD'
      });
      return true;
    } catch (error) {
      console.error('无法连接到API服务器:', error);
      return false;
    }
  }
  
  // 清除缓存
  static clearCache(): void {
    this.cache.clear();
    toast.success('API缓存已清除');
  }
  
  /**
   * 强制使用模拟数据
   */
  static forceMockData(force: boolean = true): void {
    this.forceMock = force;
    if (force) {
      toast.info('已切换到强制模拟数据模式');
    } else {
      toast.info('已恢复正常API模式');
    }
  }
  
  // 模拟请求 - 使用模拟数据和延迟
  private static async mockRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    // 模拟网络延迟
    await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 300));
    
    // 根据不同端点返回模拟数据
    if (endpoint.includes('users')) {
      return this.mockUserRequest<T>(endpoint, options);
    } else if (endpoint.includes('orders')) {
      return this.mockOrderRequest<T>(endpoint, options);
    } else if (endpoint.includes('dashboard')) {
      return this.mockDashboardData() as Promise<T>;
    } else if (endpoint.includes('servers')) {
      return this.mockServerStatus() as Promise<T>;
    } else if (endpoint.includes('events')) {
      return this.mockEvents() as Promise<T>;
    }
    
    // 未找到匹配的模拟端点
    console.warn(`模拟API端点未实现: ${endpoint}`);
    throw new Error(`模拟API端点未实现: ${endpoint}`);
  }
  
  // 模拟用户相关请求
  private static async mockUserRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // GET请求 - 获取用户列表或单个用户
    if (options.method === 'GET') {
      const match = endpoint.match(/users\/(\d+)/);
      if (match) {
        // 获取单个用户
        const userId = parseInt(match[1]);
        const user = users.find((u: any) => u.id === userId);
        if (!user) throw new Error(`用户不存在: ${userId}`);
        return user as T;
      } else {
        // 获取用户列表
        return users as T;
      }
    }
    
    // POST请求 - 创建用户
    if (options.method === 'POST' && options.body) {
      const userData = JSON.parse(options.body.toString());
      const newId = users.length > 0 
        ? Math.max(...users.map((u: any) => u.id)) + 1 
        : 1;
      
      const newUser = { 
        id: newId, 
        ...userData, 
        createdAt: new Date().toISOString(),
        status: 'active'
      };
      
      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      return newUser as T;
    }
    
    // PUT请求 - 更新用户
    if (options.method === 'PUT' && options.body) {
      const match = endpoint.match(/users\/(\d+)/);
      if (match) {
        const userId = parseInt(match[1]);
        const userData = JSON.parse(options.body.toString());
        const index = users.findIndex((u: any) => u.id === userId);
        
        if (index === -1) throw new Error(`用户不存在: ${userId}`);
        
        users[index] = { ...users[index], ...userData, updatedAt: new Date().toISOString() };
        localStorage.setItem('users', JSON.stringify(users));
        return users[index] as T;
      }
    }
    
    // DELETE请求 - 删除用户
    if (options.method === 'DELETE') {
      const match = endpoint.match(/users\/(\d+)/);
      if (match) {
        const userId = parseInt(match[1]);
        const initialLength = users.length;
        const filteredUsers = users.filter((u: any) => u.id !== userId);
        
        if (filteredUsers.length === initialLength) throw new Error(`用户不存在: ${userId}`);
        
        localStorage.setItem('users', JSON.stringify(filteredUsers));
        return { success: true } as T;
      }
    }
    
    throw new Error(`未实现的用户API操作: ${options.method} ${endpoint}`);
  }
  
  // 模拟订单相关请求
  private static async mockOrderRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    
    // GET请求 - 获取订单列表或单个订单
    if (options.method === 'GET') {
      const match = endpoint.match(/orders\/(\d+)/);
      if (match) {
        // 获取单个订单
        const orderId = parseInt(match[1]);
        const order = orders.find((o: any) => o.id === orderId);
        if (!order) throw new Error(`订单不存在: ${orderId}`);
        return order as T;
      } else {
        // 获取订单列表
        return orders as T;
      }
    }
    
    // POST请求 - 创建订单
    if (options.method === 'POST' && options.body) {
      const orderData = JSON.parse(options.body.toString());
      const newId = orders.length > 0 
        ? Math.max(...orders.map((o: any) => o.id)) + 1 
        : 1;
      
      const newOrder = { 
        id: newId, 
        ...orderData, 
        createdAt: new Date().toISOString(),
        status: 'pending'
      };
      
      orders.push(newOrder);
      localStorage.setItem('orders', JSON.stringify(orders));
      return newOrder as T;
    }
    
    throw new Error(`未实现的订单API操作: ${options.method} ${endpoint}`);
  }
  
  // 模拟仪表盘数据
   private static mockDashboardData(): any {
    // 从localStorage获取数据或使用默认值
    const gameDataStr = localStorage.getItem('games');
    const games = gameDataStr ? JSON.parse(gameDataStr) : [];
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    
    // 添加季度数据
    const quarterlyMetrics = [
      { date: 'Q1', newUsers: 45000, dau: 285000, revenue: 950000, retention: 38.5 },
      { date: 'Q2', newUsers: 52500, dau: 335000, revenue: 1250000, retention: 41.2 },
      { date: 'Q3', newUsers: 58200, dau: 375000, revenue: 1450000, retention: 43.8 },
      { date: 'Q4', newUsers: 62800, dau: 412000, revenue: 1680000, retention: 45.5 },
    ];
    
    localStorage.setItem('quarterly_metrics', JSON.stringify(quarterlyMetrics));
    
    // 计算关键指标
    const userCount = users.length;
    const orderCount = orders.length;
    const revenue = orders.reduce((sum: number, order: any) => sum + order.amount, 0);
    
    return {
      dau: Math.floor(userCount * 0.3),
      mau: userCount,
      newUsers: Math.floor(userCount * 0.15),
      retention: 42.8,
      arpu: 3.85,
      ltv: 28.45,
      revenue: revenue,
      totalOrders: orderCount,
      gameCount: games.length,
      activeServers: 18,
      totalServers: 24,
      conversionRate: 24.8,
      avgSessionTime: 18.5
    };
  }
  
  // 模拟服务器状态数据
  private static mockServerStatus(): any[] {
    return [
      { id: 'us-west', name: '美国西部', status: 'online', load: 65, users: 45200, uptime: '99.9%' },
      { id: 'eu-central', name: '欧洲中部', status: 'online', load: 58, users: 38700, uptime: '99.8%' },
      { id: 'asia-east', name: '东亚', status: 'degraded', load: 82, users: 29500, uptime: '99.7%' },
      { id: 'sea-south', name: '东南亚', status: 'online', load: 72, users: 21400, uptime: '99.9%' },
      { id: 'us-east', name: '美国东部', status: 'maintenance', load: 0, users: 0, uptime: '99.6%' },
      { id: 'south-america', name: '南美', status: 'online', load: 45, users: 18200, uptime: '99.8%' },
    ];
  }
  
  // 模拟活动数据
  private static mockEvents(): any[] {
    return [
      {
        id: 1,
        title: '夏日狂欢活动',
        description: '参与夏日主题活动，赢取限定皮肤和游戏道具',
        startDate: '2025-08-15T00:00:00Z',
        endDate: '2025-08-30T23:59:59Z',
        status: 'upcoming',
        image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Summer%20Game%20Event%2C%20vibrant%20colors%2C%20beach%20theme&sign=9351aa922e37f738ef9f31598588fdf9',
        participants: 0,
        rewards: '限定皮肤、游戏币、稀有道具'
      },
      {
        id: 2,
        title: '周年庆典',
        description: '庆祝游戏上线一周年，登录即可领取丰厚奖励',
        startDate: '2025-07-20T00:00:00Z',
        endDate: '2025-08-05T23:59:59Z',
        status: 'active',
        image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Game%20Anniversary%20Event%2C%20festive%20atmosphere%2C%20confetti&sign=04249382a5b8db64042d5013dc802c8d',
        participants: 125400,
        rewards: '周年限定称号、免费英雄、周年纪念皮肤'
      },
      {
        id: 3,
        title: '春季挑战赛',
        description: '参与PvP挑战赛，争夺排行榜奖励',
        startDate: '2025-06-10T00:00:00Z',
        endDate: '2025-06-25T23:59:59Z',
        status: 'ended',
        image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Spring%20Challenge%20Event%2C%20green%20theme%2C%20tournament&sign=bf9822a5267e57b9f6bc1bb69ef6d959',
        participants: 89600,
        rewards: '冠军奖杯、限定头像框、大量游戏币'
      }
    ];
  }
  
  // localStorage请求回退
  private static async localStorageRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    // 模拟API请求延迟
    await new Promise(resolve => setTimeout(resolve, 200));
    
    if (endpoint.includes('users')) {
      return this.localStorageUserRequest<T>(endpoint, options);
    } else if (endpoint.includes('orders')) {
      return this.localStorageOrderRequest<T>(endpoint, options);
    } else if (endpoint.includes('dashboard')) {
      return this.mockDashboardData() as T;
    }
    
    throw new Error(`未实现的本地API端点: ${endpoint}`);
  }
  
  // localStorage用户请求
  private static localStorageUserRequest<T>(endpoint: string, options: RequestInit = {}): T {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    if (options.method === 'GET') {
      const match = endpoint.match(/users\/(\d+)/);
      if (match) {
        const userId = parseInt(match[1]);
        const user = users.find((u: any) => u.id === userId);
        return (user || null) as T;
      }
      return users as T;
    }
    
    throw new Error(`本地存储请求未实现: ${options.method} ${endpoint}`);
  }
  
  // localStorage订单请求
  private static localStorageOrderRequest<T>(endpoint: string, options: RequestInit = {}): T {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    
    if (options.method === 'GET') {
      const match = endpoint.match(/orders\/(\d+)/);
      if (match) {
        const orderId = parseInt(match[1]);
        const order = orders.find((o: any) => o.id === orderId);
        return (order || null) as T;
      }
      return orders as T;
    }
    
    throw new Error(`本地存储请求未实现: ${options.method} ${endpoint}`);
  }
  
  // 用户相关API
  static async getUsers(): Promise<any[]> {
    return this.request<any[]>(API_CONFIG.endpoints.users, {}, 60); // 缓存1分钟
  }
  
  static async getUserById(id: number): Promise<any | null> {
    return this.request<any>(`${API_CONFIG.endpoints.users}/${id}`, {}, 300); // 缓存5分钟
  }
  
  static async createUser(userData: any): Promise<any> {
    this.clearCache(); // 创建用户后清除缓存
    return this.request<any>(API_CONFIG.endpoints.users, {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  }
  
  static async updateUser(id: number, userData: any): Promise<boolean> {
    this.clearCache(); // 更新用户后清除缓存
    try {
      await this.request<any>(`${API_CONFIG.endpoints.users}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(userData)
      });
      return true;
    } catch (error) {
      return false;
    }
  }
  
  static async deleteUser(id: number): Promise<boolean> {
    this.clearCache(); // 删除用户后清除缓存
    try {
      await this.request<any>(`${API_CONFIG.endpoints.users}/${id}`, {
        method: 'DELETE'
      });
      return true;
    } catch (error) {
      return false;
    }
  }
  
  // 订单相关API
  static async getOrders(filters: any = {}): Promise<any[]> {
    // 构建查询参数
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        params.append(key, value.toString());
      }
    });
    
    const query = params.toString() ? `?${params.toString()}` : '';
    return this.request<any[]>(`${API_CONFIG.endpoints.orders}${query}`, {}, 300); // 缓存5分钟
  }
  
     static async getOrderById(id: number): Promise<any | null> {
      return this.request<any>(`${API_CONFIG.endpoints.orders}/${id}`, {}, 300); // 缓存5分钟
    }
    
    // 处理退款警告
    static async handleRefundWarning(orderId: number, reason: string): Promise<{ success: boolean; message: string }> {
      try {
        const response = await this.request<any>(`${API_CONFIG.endpoints.orders}/${orderId}/refund-warning`, {
          method: 'POST',
          body: JSON.stringify({ reason })
        });
        return { success: true, message: '退款警告已处理' };
      } catch (error) {
        console.error('处理退款警告失败:', error);
        return { success: false, message: '处理退款警告失败' };
      }
    }
    
    // 解决退款警告
    static async resolveRefundWarning(orderId: number): Promise<{ success: boolean; message: string }> {
      try {
        const response = await this.request<any>(`${API_CONFIG.endpoints.orders}/${orderId}/resolve-warning`, {
          method: 'POST'
        });
        return { success: true, message: '退款警告已解决' };
      } catch (error) {
        console.error('解决退款警告失败:', error);
        return { success: false, message: '解决退款警告失败' };
      }
    }
   
   static async createOrder(orderData: any): Promise<any> {
     this.clearCache(); // 创建订单后清除缓存
     return this.request<any>(API_CONFIG.endpoints.orders, {
       method: 'POST',
       body: JSON.stringify(orderData)
     });
   }
   
   // 新增退款警告相关API方法
    static async createRefundWarning(orderId: number, reason: string): Promise<{ success: boolean; message: string }> {
      try {
        const response = await this.request<any>(`${API_CONFIG.endpoints.orders}/${orderId}/refund-warning`, {
          method: 'POST',
          body: JSON.stringify({ reason })
        });
        return {
          success: true,
          message: '退款警告已创建'
        };
      } catch (error) {
        console.error('创建退款警告失败:', error);
        return {
          success: false,
          message: '创建退款警告失败'
        };
      }
    }
   
    static async markRefundWarningAsResolved(orderId: number): Promise<{ success: boolean; message: string }> {
      try {
        const response = await this.request<any>(`${API_CONFIG.endpoints.orders}/${orderId}/resolve-warning`, {
          method: 'POST'
        });
        return {
          success: true,
          message: '退款警告已解决'
        };
      } catch (error) {
        console.error('解决退款警告失败:', error);
        return {
          success: false,
          message: '解决退款警告失败'
        };
      }
    }
  
  // 仪表盘数据API
  static async getDashboardData(): Promise<any> {
    return this.request<any>(API_CONFIG.endpoints.dashboard, {}, 300); // 缓存5分钟
  }
  
  // 服务器状态API
  static async getServerStatus(): Promise<any[]> {
    return this.request<any[]>(API_CONFIG.endpoints.servers, {}, 60); // 缓存1分钟
  }
  
  // 活动相关API
  static async getEvents(): Promise<any[]> {
    return this.request<any[]>(API_CONFIG.endpoints.events, {}, 3600); // 缓存1小时
  }
  
   static async getGameMetrics(): Promise<any[] | null> {
     try {
       const response = await this.request<any[]>(API_CONFIG.endpoints.gameData, {}, 300);
       return response;
     } catch (error) {
       console.error('Error fetching game metrics:', error);
       return null;
     }
   }

   static async getEventById(id: number): Promise<any | null> {
    return this.request<any>(`${API_CONFIG.endpoints.events}/${id}`, {}, 3600); // 缓存1小时
  }
  
  static async createEvent(eventData: any): Promise<any> {
    this.clearCache();
    return this.request<any>(API_CONFIG.endpoints.events, {
      method: 'POST',
      body: JSON.stringify(eventData)
    });
  }
  
  // 广告配置相关API
   static async getAdConfig(): Promise<any> {
     const config = localStorage.getItem('adConfig');
     return config ? JSON.parse(config) : {
         googleAds: { 
           enabled: false,
           clientId: "",
           apiKey: "",
           conversionId: "",
           campaigns: []
         },
         facebookAds: { 
           enabled: false,
           accountId: "",
           accessToken: "",
           pixelId: "",
           campaigns: []
         },
         appleSearchAds: { 
           enabled: false,
           teamId: "",
           clientId: "",
           keyId: "",
           campaigns: []
         },
         googleSdk: { enabled: false },
         iosSdk: { enabled: false }
       };
    }
   
    static async saveAdConfig(config: any): Promise<boolean> {
      try {
        localStorage.setItem('adConfig', JSON.stringify(config));
        return true;
      } catch (error) {
        console.error('保存广告配置失败:', error);
        return false;
      }
    }
   
    // 获取广告计划数据
    static async getAdCampaigns(platform: string): Promise<any[]> {
      // 模拟获取各平台广告计划数据
      await new Promise(resolve => setTimeout(resolve, 800));
      
      if (platform === 'google') {
        return [
          { id: 'campaign_1', name: '获客计划', impressions: 125000, clicks: 4520, conversions: 285, cost: 3842 },
          { id: 'campaign_2', name: '再营销计划', impressions: 89000, clicks: 3200, conversions: 420, cost: 2950 },
          { id: 'campaign_3', name: '品牌推广', impressions: 210000, clicks: 2850, conversions: 120, cost: 4200 }
        ];
      } else if (platform === 'facebook') {
        return [
          { id: 'campaign_101', name: '安装广告', impressions: 95000, clicks: 3800, conversions: 520, cost: 3200 },
          { id: 'campaign_102', name: '转化广告', impressions: 78000, clicks: 2950, conversions: 380, cost: 2450 }
        ];
      } else if (platform === 'apple') {
        return [
          { id: 'campaign_201', name: 'Search Ads', impressions: 45000, clicks: 1200, conversions: 180, cost: 1800 }
        ];
      }
      
      return [];
    }
  
   static async testAdConnection(platform: string): Promise<{ success: boolean; message: string }> {
     // 模拟API连接测试
     return new Promise(resolve => {
       setTimeout(() => {
         // 模拟不同平台的连接测试结果
         let success = true;
         let message = `${platform} 连接测试成功`;
         
         // 为演示目的，让某些平台测试失败
         if (['google', 'facebook'].includes(platform) && Math.random() > 0.5) {
           success = false;
           message = `${platform} 连接测试失败: 无法连接到API服务器`;
         }
         
         resolve({ success, message });
       }, 1500);
     });
   }
   
   /**
    * 检查退款警告
    */
     static async checkRefundWarnings(platform: string): Promise<{ hasWarnings: boolean; warnings: any[] }> {
        // 检查API连接状态
        if (!this.useRealAPI()) {
          console.warn('使用模拟数据模式，无法检查真实退款警告');
        } else {
          console.log('正在检查真实退款警告...');
        }
     // 模拟获取退款警告数据
     await new Promise(resolve => setTimeout(resolve, 800));
     
     // 模拟不同平台的退款警告数据
     if (platform === 'ios') {
       return {
         hasWarnings: true,
         warnings: [
           { orderId: 'ORD-9875', userId: 'gamer456', amount: 29.99, reason: '用户争议', status: 'pending' },
           { orderId: 'ORD-9864', userId: 'mobilegamer', amount: 19.99, reason: '产品未收到', status: 'investigating' }
         ]
       };
     } else if (platform === 'google') {
       return {
         hasWarnings: true,
         warnings: [
           { orderId: 'ORD-9873', userId: 'mobilegamer', amount: 19.99, reason: '欺诈嫌疑', status: 'warning' },
           { orderId: 'ORD-9862', userId: 'casualplayer', amount: 39.99, reason: '重复购买', status: 'refunded' }
         ]
       };
     }
     
     return { hasWarnings: false, warnings: [] };
   }
   
   /**
    * 处理退款警告
    */
    static async processRefundWarningAction(orderId: string, action: 'approve' | 'deny' | 'investigate'): Promise<{ success: boolean; message: string }> {
      // 模拟处理退款警告
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      return {
        success: true,
        message: `退款警告处理成功: ${action === 'approve' ? '已批准退款' : action === 'deny' ? '已拒绝退款' : '已标记为需要调查'}`
      };
    }
}