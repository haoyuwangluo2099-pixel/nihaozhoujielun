/**
 * 数据服务 - 本地存储与模拟数据管理
 * 提供本地数据初始化、管理和模拟后端API响应功能
 */
import { toast } from 'sonner';

export class DataService {
  // 初始化状态键
  private static INITIALIZED_KEY = 'app_initialized';
  
  /**
   * 初始化应用数据
   * @param forceReset - 是否强制重置所有数据
   */
  static init(forceReset: boolean = false): void {
    // 检查是否已初始化且不强制重置
    if (!forceReset && localStorage.getItem(this.INITIALIZED_KEY)) {
      return;
    }
    
    console.log('初始化应用数据...');
    
    // 初始化所有数据存储
    this.initUsers();
    this.initOrders();
    this.initGames();
    this.initEvents();
    this.initServers();
    this.initContent();
    this.initSupportTickets();
    this.initAdConfig();
    this.initSystemSettings();
    
    // 标记为已初始化
    localStorage.setItem(this.INITIALIZED_KEY, 'true');
    
    console.log('应用数据初始化完成');
  }
  
  /**
   * 重置所有应用数据
   */
  static resetAllData(): void {
    if (window.confirm('确定要重置所有应用数据吗？此操作不可恢复。')) {
      // 清除所有应用数据
      const keysToRemove = [
        this.INITIALIZED_KEY,
        'users', 'orders', 'games', 'events', 'servers', 
        'content', 'support_tickets', 'ad_config', 'system_settings',
        'auth_token', 'user_preferences'
      ];
      
      keysToRemove.forEach(key => localStorage.removeItem(key));
      
      // 重新初始化
      this.init(true);
      toast.success('所有数据已重置并重新初始化');
    }
  }
  
  /**
   * 初始化用户数据
   */
  private static initUsers(): void {
    const initialUsers = [
      { 
        id: 1, 
        username: 'admin', 
        email: 'admin@game.com', 
        password: 'hashed_password', // 在实际应用中应使用加密存储
        role: 'admin', 
        level: 0, 
        status: 'active',
        lastLogin: new Date().toISOString(),
        createdAt: '2025-01-15T08:30:00Z',
        updatedAt: new Date().toISOString(),
        lastLoginIp: '192.168.1.1',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36'
      },
      { 
        id: 2, 
        username: 'player123', 
        email: 'player@example.com', 
        password: 'hashed_password',
        role: 'player', 
        level: 45, 
        country: 'US', 
        status: 'active',
        lastLogin: new Date(Date.now() - 86400000).toISOString(),
        createdAt: '2025-01-20T14:22:00Z',
        updatedAt: '2025-08-10T09:15:00Z',
        avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Player%20Avatar&sign=e4e8b75e0d230745288823fa14b3ca7c',
        lastLoginIp: '10.0.0.5',
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) Firefox/121.0'
      },
      { 
        id: 3, 
        username: 'gamer456', 
        email: 'gamer456@example.com', 
        password: 'hashed_password',
        role: 'player', 
        level: 67, 
        country: 'JP', 
        status: 'active',
        lastLogin: new Date(Date.now() - 43200000).toISOString(),
        createdAt: '2025-02-10T11:45:00Z',
        updatedAt: '2025-08-11T16:30:00Z',
        avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Gamer%20Avatar&sign=0b43602481fb76ad1537e83e24cfb6ce',
        lastLoginIp: '172.16.0.2',
        userAgent: 'Mozilla/5.0 (Linux; Android 14) Mobile Safari/537.36'
      },
      { 
        id: 4, 
        username: 'proplayer789', 
        email: 'pro@example.com', 
        password: 'hashed_password',
        role: 'player', 
        level: 89, 
        country: 'KR', 
        status: 'active',
        lastLogin: new Date(Date.now() - 3600000).toISOString(),
        createdAt: '2025-03-05T09:12:00Z',
        updatedAt: '2025-08-12T11:45:00Z',
        avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Pro%20Gamer%20Avatar&sign=8fd89f9f2520f18c38e2a50f43603b3a',
        lastLoginIp: '192.168.1.100',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Edge/120.0.0.0'
      },
      { 
        id: 5, 
        username: 'casualplayer', 
        email: 'casual@example.com', 
        password: 'hashed_password',
        role: 'player', 
        level: 23, 
        country: 'DE', 
        status: 'inactive',
        lastLogin: new Date(Date.now() - 604800000).toISOString(),
        createdAt: '2025-04-18T16:30:00Z',
        updatedAt: '2025-07-20T08:15:00Z',
        avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Casual%20Player%20Avatar&sign=65b7d81f3cec0036790737a4223e5e29',
        lastLoginIp: '10.0.1.5',
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) Chrome/120.0.0.0'
      },
      { 
        id: 6, 
        username: 'mobilegamer', 
        email: 'mobile@example.com', 
        password: 'hashed_password',
        role: 'player', 
        level: 36, 
        country: 'CN', 
        status: 'active',
        lastLogin: new Date(Date.now() - 1800000).toISOString(),
        createdAt: '2025-05-22T10:15:00Z',
        updatedAt: '2025-08-12T14:20:00Z',
        avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Mobile%20Gamer%20Avatar&sign=9ceb21a9b269301c39b09398deaf7fb5',
        lastLoginIp: '192.168.0.5',
        userAgent: 'Mozilla/5.0 (iPhone; iOS 17) Mobile Safari/537.36'
      }
    ];
    
    localStorage.setItem('users', JSON.stringify(initialUsers));
  }
  
  /**
   * 初始化订单数据
   */
  private static initOrders(): void {
    const initialOrders = [
      { 
        id: 1, 
        userId: 2, 
        amount: 49.99, 
        product: '高级会员 (1个月)', 
        date: '2025-08-10T09:25:00Z', 
        status: 'completed',
        paymentMethod: 'credit_card',
        transactionId: 'txn_123456789',
        currency: 'USD',
        tax: 4.50,
        total: 54.49,
        items: [
          { id: 101, name: '高级会员', price: 49.99, quantity: 1 }
        ],
        createdAt: '2025-08-10T09:25:00Z',
        updatedAt: '2025-08-10T09:26:15Z'
      },
      { 
        id: 2, 
        userId: 4, 
        amount: 29.99, 
        product: '钻石礼包', 
        date: '2025-08-11T14:32:00Z', 
        status: 'completed',
        paymentMethod: 'paypal',
        transactionId: 'txn_987654321',
        currency: 'USD',
        tax: 2.70,
        total: 32.69,
        items: [
          { id: 202, name: '钻石礼包', price: 29.99, quantity: 1 }
        ],
        createdAt: '2025-08-11T14:32:00Z',
        updatedAt: '2025-08-11T14:33:45Z'
      },
      { 
        id: 3, 
        userId: 3, 
        amount: 79.99, 
        product: '星际战士皮肤套装', 
        date: '2025-08-12T11:15:00Z', 
        status: 'pending',
        paymentMethod: 'credit_card',
        transactionId: 'txn_567890123',
        currency: 'USD',
        tax: 7.20,
        total: 87.19,
        items: [
          { id: 303, name: '星际战士皮肤', price: 59.99, quantity: 1 },
          { id: 304, name: '专属武器外观', price: 19.99, quantity: 1 }
        ],
        createdAt: '2025-08-12T11:15:00Z',
        updatedAt: '2025-08-12T11:15:00Z'
      },
      { 
        id: 4, 
        userId: 6, 
        amount: 19.99, 
        product: '游戏道具包', 
        date: '2025-08-12T15:40:00Z', 
        status: 'completed',
        paymentMethod: 'mobile_payment',
        transactionId: 'txn_345678901',
        currency: 'USD',
        tax: 1.80,
        total: 21.79,
        items: [
          { id: 405, name: '游戏道具包', price: 19.99, quantity: 1 }
        ],
        createdAt: '2025-08-12T15:40:00Z',
        updatedAt: '2025-08-12T15:41:30Z'
      },
      { 
        id: 5, 
        userId: 2, 
        amount: 39.99, 
        product: '季票通行证', 
        date: '2025-08-12T16:20:00Z', 
        status: 'completed',
        paymentMethod: 'credit_card',
        transactionId: 'txn_678901234',
        currency: 'USD',
        tax: 3.60,
        total: 43.59,
        items: [
          { id: 506, name: '季票通行证', price: 39.99, quantity: 1 }
        ],
        createdAt: '2025-08-12T16:20:00Z',
        updatedAt: '2025-08-12T16:21:10Z'
      }
    ];
    
    localStorage.setItem('orders', JSON.stringify(initialOrders));
  }
  
  /**
   * 初始化游戏数据
   */
  private static initGames(): void {
    const initialGames = [
      { 
        id: 1, 
        name: "星际冒险", 
        description: "探索广阔的宇宙，与外星文明接触，展开一场史诗般的太空冒险。玩家将扮演一名星际探险家，驾驶自己的飞船穿越星系，发现新的星球和资源，与各种外星生物互动，建立星际殖民地。",
        price: 29.99, 
        rating: 4.8, 
        genre: "角色扮演", 
        releaseDate: "2025-01-15",
        image: "space-adventure.jpg",
        features: ["开放世界", "太空探索", "角色自定义", "多人游戏"],
        platform: ["PC", "PlayStation", "Xbox", "Switch"],
        developer: "星际游戏工作室",
        publisher: "GamePortal",
        tags: ["太空", "冒险", "科幻", "RPG"],
        createdAt: "2024-11-01T00:00:00Z",
        updatedAt: "2025-08-05T14:30:00Z",
        players: 1250000,
        activePlayers: 85000,
        revenue: 3650000
      },
      { 
        id: 2, 
        name: "魔法王国", 
        description: "成为一名强大的魔法师，学习各种咒语，拯救被黑暗势力笼罩的王国。探索广阔的魔法世界，收集古老的法术卷轴，与黑暗巫师战斗，揭开魔法世界的秘密。",
        price: 39.99, 
        rating: 4.6, 
        genre: "奇幻", 
        releaseDate: "2025-02-20",
        image: "magic-kingdom.jpg",
        features: ["魔法系统", "剧情驱动", "角色成长", "团队合作"],
        platform: ["PC", "PlayStation", "Xbox"],
        developer: "魔法游戏公司",
        publisher: "GamePortal",
        tags: ["魔法", "幻想", "冒险", "RPG"],
        createdAt: "2024-12-15T00:00:00Z",
        updatedAt: "2025-08-10T09:15:00Z",
        players: 980000,
        activePlayers: 62000,
        revenue: 3920000
      },
      { 
        id: 3, 
        name: "赛车传奇", 
        description: "体验极速赛车的快感，解锁各种超级跑车，成为赛道上的传奇。从城市街道到专业赛道，挑战各种赛道和天气条件，证明你是最快的赛车手。",
        price: 49.99, 
        rating: 4.5, 
        genre: "竞速", 
        releaseDate: "2025-03-10",
        image: "racing-legend.jpg",
        features: ["真实物理", "多种赛道", "车辆改装", "多人竞速"],
        platform: ["PC", "PlayStation", "Xbox"],
        developer: "速度游戏工作室",
        publisher: "GamePortal",
        tags: ["赛车", "竞速", "多人", "体育"],
        createdAt: "2025-01-20T00:00:00Z",
        updatedAt: "2025-07-28T16:45:00Z",
        players: 750000,
        activePlayers: 42000,
        revenue: 3740000
      },
      { 
        id: 4, 
        name: "篮球大师", 
        description: "组建自己的篮球队，参加各种比赛，赢得总冠军奖杯。招募明星球员，制定战术，训练球队，在各种联赛中脱颖而出。",
        price: 0, 
        rating: 4.3, 
        genre: "体育", 
        releaseDate: "2025-04-05",
        image: "basketball-master.jpg",
        features: ["真实球员", "球队管理", "多种赛事", "在线对战"],
        platform: ["PC", "PlayStation", "Xbox", "Switch", "Mobile"],
        developer: "体育游戏公司",
        publisher: "GamePortal",
        tags: ["篮球", "体育", "多人", "免费"],
        createdAt: "2025-02-10T00:00:00Z",
        updatedAt: "2025-08-12T11:20:00Z",
        players: 2100000,
        activePlayers: 185000,
        revenue: 2450000 // 免费游戏通过应用内购买获得收入
      },
      { 
        id: 5, 
        name: "生存挑战", 
        description: "在荒野中生存下去，收集资源，建造庇护所，对抗野生动物和恶劣环境。从茂密的森林到寒冷的雪山，在各种环境中测试你的生存技能。",
        price: 19.99, 
        rating: 4.7, 
        genre: "生存", 
        releaseDate: "2025-05-18",
        image: "survival-challenge.jpg",
        features: ["开放世界", "资源收集", "建造系统", "动态天气"],
        platform: ["PC", "PlayStation", "Xbox"],
        developer: "荒野工作室",
        publisher: "GamePortal",
        tags: ["生存", "开放世界", "建造", "冒险"],
        createdAt: "2025-03-25T00:00:00Z",
        updatedAt: "2025-07-15T10:20:00Z",
        players: 680000,
        activePlayers: 38000,
        revenue: 1360000
      },
      { 
        id: 6, 
        name: "城市建造者", 
        description: "设计并建造自己的梦想城市，管理资源，满足市民需求，发展成为大都市。从一个小村庄开始，规划交通系统，提供公共服务，吸引更多居民。",
        price: 29.99, 
        rating: 4.4, 
        genre: "模拟", 
        releaseDate: "2025-06-12",
        image: "city-builder.jpg",
        features: ["城市规划", "资源管理", "动态事件", "无限扩张"],
        platform: ["PC", "Mac"],
        developer: "城市工作室",
        publisher: "GamePortal",
        tags: ["模拟", "建造", "策略", "城市"],
        createdAt: "2025-04-15T00:00:00Z",
        updatedAt: "2025-08-01T09:45:00Z",
        players: 520000,
        activePlayers: 25000,
        revenue: 1560000
      }
    ];
    
    localStorage.setItem('games', JSON.stringify(initialGames));
  }
  
  /**
   * 初始化活动数据
   */
  private static initEvents(): void {
    const initialEvents = [
      {
        id: 1,
        title: '夏日狂欢活动',
        description: '参与夏日主题活动，赢取限定皮肤和游戏道具。完成每日任务可获得活动积分，兑换丰厚奖励。',
        startDate: '2025-08-15T00:00:00Z',
        endDate: '2025-08-30T23:59:59Z',
        status: 'upcoming',
        image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Summer%20Game%20Event%2C%20vibrant%20colors%2C%20beach%20theme&sign=9351aa922e37f738ef9f31598588fdf9",
        participants: 0,
        rewards: '限定皮肤、游戏币、稀有道具、独家称号',
        createdAt: "2025-07-20T10:00:00Z",
        updatedAt: "2025-08-12T08:15:00Z",
        type: "limited_time",
        gameId: 1,
        bannerImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Summer%20Event%20Banner&sign=112a20c02376c4d04176525459ba7832",
        rules: "1. 每日登录可获得10积分\n2. 完成指定游戏任务可获得额外积分\n3. 积分可在活动商店兑换奖励\n4. 活动排行榜前100名可获得额外奖励",
        prizePool: [
          { rank: "1-10", reward: "传奇皮肤+1000游戏币" },
          { rank: "11-50", reward: "史诗皮肤+500游戏币" },
          { rank: "51-100", reward: "稀有皮肤+200游戏币" },
          { rank: "参与奖", reward: "活动积分+100游戏币" }
        ]
      },
      {
        id: 2,
        title: '周年庆典',
        description: '庆祝游戏上线一周年，登录即可领取丰厚奖励。参与周年庆特别活动，赢取限定纪念物品。',
        startDate: "2025-07-20T00:00:00Z",
        endDate: "2025-08-05T23:59:59Z",
        status: "active",
        image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Game%20Anniversary%20Event%2C%20festive%20atmosphere%2C%20confetti&sign=04249382a5b8db64042d5013dc802c8d",
        participants: 125400,
        rewards: "周年限定称号、免费英雄、周年纪念皮肤、游戏币礼包",
        createdAt: "2025-06-15T00:00:00Z",
        updatedAt: "2025-08-12T10:30:00Z",
        type: "anniversary",
        gameId: 2,
        bannerImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Anniversary%20Event%20Banner&sign=400f30e443fb8f2044cba14344318c7e",
        rules: "1. 活动期间登录即可领取登录奖励\n2. 完成周年庆任务可获得周年币\n3. 周年币可兑换限定奖励\n4. 参与周年庆特别副本可获得额外奖励",
        prizePool: [
          { rank: "所有玩家", reward: "周年限定称号+1000游戏币" },
          { rank: "累计登录7天", reward: "免费英雄" },
          { rank: "完成所有任务", reward: "周年纪念皮肤" }
        ]
      },
      {
        id: 3,
        title: '春季挑战赛',
        description: '参与PvP挑战赛，争夺排行榜奖励。与其他玩家一决高下，证明你的实力。',
        startDate: "2025-06-10T00:00:00Z",
        endDate: "2025-06-25T23:59:59Z",
        status: "ended",
        image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Spring%20Challenge%20Event%2C%20green%20theme%2C%20tournament&sign=bf9822a5267e57b9f6bc1bb69ef6d959",
        participants: 89600,
        rewards: "冠军奖杯、限定头像框、大量游戏币、独家称号",
        createdAt: "2025-05-20T00:00:00Z",
        updatedAt: "2025-06-26T00:00:00Z",
        type: "tournament",
        gameId: 3,
        bannerImage: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Spring%20Challenge%20Banner&sign=f953ed9025f081befc2fa0103c419d40",
        rules: "1. 玩家需达到30级才能参与\n2. 挑战赛分为小组赛和淘汰赛\n3. 每场胜利可获得积分\n4. 根据积分排名发放奖励",
        prizePool: [
          { rank: "冠军", reward: "冠军奖杯+限定头像框+5000游戏币+冠军称号" },
          { rank: "亚军", reward: "亚军奖牌+3000游戏币+亚军称号" },
          { rank: "季军", reward: "季军奖牌+2000游戏币+季军称号" },
          { rank: "4-10名", reward: "1000游戏币" }
        ]
      }
    ];
    
    localStorage.setItem('events', JSON.stringify(initialEvents));
  }
  
  /**
   * 初始化服务器数据
   */
  private static initServers(): void {
    const initialServers = [{ id: 'us-west', name: '美国西部', status: 'online', load: 65, users: 45200, uptime: '99.9%', location: '美国加利福尼亚州', ip: '192.168.1.10', lastRestart: '2025-08-01T03:00:00Z' },
      { id: 'eu-central', name: '欧洲中部', status: 'online', load: 58, users: 38700, uptime: '99.8%', location: '德国法兰克福', ip: '192.168.1.11', lastRestart: '2025-08-05T04:00:00Z' },
      { id: 'asia-east', name: '东亚', status: 'degraded', load: 82, users: 29500, uptime: '99.7%', location: '日本东京', ip: '192.168.1.12', lastRestart: '2025-08-10T02:00:00Z' },
      { id: 'sea-south', name: '东南亚', status: 'online', load: 72, users: 21400, uptime: '99.9%', location: '新加坡', ip: '192.168.1.13', lastRestart: '2025-08-08T03:30:00Z' },
      { id: 'us-east', name: '美国东部', status: 'maintenance', load: 0, users: 0, uptime: '99.6%', location: '美国弗吉尼亚州', ip: '192.168.1.14', lastRestart: '2025-08-12T01:00:00Z' },
      { id: 'south-america', name: '南美', status: 'online', load: 45, users: 18200, uptime: '99.8%', location: '巴西圣保罗', ip: '192.168.1.15', lastRestart: '2025-08-03T05:00:00Z' }
    ];
    
    localStorage.setItem('servers', JSON.stringify(initialServers));
  }
  
  /**
   * 初始化内容管理数据
   */
  private static initContent(): void {
    const initialContent = [
      { 
        id: 1, 
        title: "《星际冒险》新版本更新公告", 
        type: "announcement", 
        status: "published", 
        createdAt: "2025-08-10T09:00:00Z",
        updatedAt: "2025-08-10T09:00:00Z",
        author: "管理员",
        content: `
          <h3>《星际冒险》新版本 1.2.0 更新内容</h3>
          <p>亲爱的玩家：</p>
          <p>我们很高兴地宣布《星际冒险》新版本 1.2.0 将于 2025年8月15日正式上线！本次更新将带来全新星球、角色和游戏功能。</p>
          <h4>主要更新内容：</h4>
          <ul>
            <li>新增「阿尔法星系」区域，包含5个全新星球</li>
            <li>新增3个可玩角色和专属技能</li>
            <li>优化太空战斗系统，增加新的战斗机制</li>
            <li>新增「星际贸易」系统</li>
            <li>修复已知bug，优化游戏性能</li>
          </ul>
          <p>更新维护时间：2025年8月15日 02:00 - 06:00（UTC+8）</p>
          <p>维护期间将无法登录游戏，请各位玩家提前做好准备。维护结束后，所有玩家将获得维护补偿：1000星际币+高级补给箱*1。</p>
          <p>感谢各位玩家的支持与理解！</p>
        `,
        gameId: 1,
        image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Game%20Update%20Announcement&sign=dda5a749ec115d883e5c8ad507bd468b",
        tags: ["更新", "星际冒险", "重要"],
        views: 12500,
        likes: 850
      },
      { 
        id: 2, 
        title: "夏日活动宣传图", 
        type: "image", 
        status: "published", 
        createdAt: "2025-08-05T14:30:00Z",
        updatedAt: "2025-08-05T14:30:00Z",
        author: "内容编辑",
        content: "",
        gameId: null,
        image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Summer%20Event%20Promotion&sign=6aa0d223577886944d916ea0bfd3ae82",
        tags: ["图片", "宣传", "夏日活动"],
        views: 8200,
        likes: 420
      },
      { 
        id: 3, 
        title: "新英雄介绍视频", 
        type: "video", 
        status: "draft", 
        createdAt: "2025-08-12T10:15:00Z",
        updatedAt: "2025-08-12T10:15:00Z",
        author: "内容编辑",
        content: "新英雄「暗影猎手」技能展示与背景故事介绍",
        gameId: 2,
        image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=New%20Hero%20Video%20Thumbnail&sign=ef2dc61f1715cdbb6919b0961604e8b6",
        tags: ["视频", "英雄介绍", "魔法王国"],
        views: 0,
        likes: 0,
        videoUrl: "#"
      }
    ];
    
    localStorage.setItem('content', JSON.stringify(initialContent));
  }
  
  /**
   * 初始化支持工单数据
   */
  private static initSupportTickets(): void {
    const initialTickets = [
      { 
        id: 1001, 
        user: "player123", 
        userId: 2,
        subject: "无法登录游戏", 
        status: "resolved", 
        priority: "high", 
        createdAt: "2025-08-12T08:30:00Z",
        updatedAt: "2025-08-12T09:15:00Z",
        assignedTo: "support_agent1",
        replies: 3,
        category: "login",
        platform: "PC",
        gameVersion: "1.1.5",
        description: "尝试登录游戏时提示「连接服务器失败」，已经尝试重启路由器和重新安装游戏，但问题仍然存在。",
        resolution: "用户DNS设置问题，指导修改DNS为8.8.8.8后问题解决。",
        messages: [
          { 
            id: 1, 
            sender: "user", 
            content: "尝试登录游戏时提示「连接服务器失败」，已经尝试重启路由器和重新安装游戏，但问题仍然存在。",
            timestamp: "2025-08-12T08:30:00Z"
          },
          { 
            id: 2, 
            sender: "agent", 
            content: "您好，请尝试修改DNS设置为8.8.8.8和8.8.4.4，然后重启游戏再试。",
            timestamp: "2025-08-12T08:45:00Z"
          },
          { 
            id: 3, 
            sender: "user", 
            content: "修改DNS后可以登录了，谢谢！",
            timestamp: "2025-08-12T09:10:00Z"
          },
          { 
            id: 4, 
            sender: "agent", 
            content: "不客气，很高兴为您解决问题。",
            timestamp: "2025-08-12T09:15:00Z"
          }
        ]
      },
      { 
        id: 1002, 
        user: "gamer456", 
        userId: 3,
        subject: "支付失败问题", 
        status: "in_progress", 
        priority: "high", 
        createdAt: "2025-08-12T09:45:00Z",
        updatedAt: "2025-08-12T10:00:00Z",
        assignedTo: "support_agent2",
        replies: 1,
        category: "payment",
        platform: "Mobile",
        gameVersion: "1.1.5",
        description: "购买钻石礼包时支付失败，但银行卡已经扣款，游戏内未收到钻石。",
        resolution: "",
        messages: [
          { 
            id: 1, 
            sender: "user", 
            content: "购买钻石礼包时支付失败，但银行卡已经扣款，游戏内未收到钻石。交易ID: txn_789012345",
            timestamp: "2025-08-12T09:45:00Z"
          },
          { 
            id: 2, 
            sender: "agent", 
            content: "您好，我们已经收到您的反馈，正在查询交易记录，请您耐心等待。",
            timestamp: "2025-08-12T10:00:00Z"
          }
        ]
      },
      { 
        id: 1003, 
        user: "proplayer789", 
        userId: 4,
        subject: "游戏卡顿问题", 
        status: "pending", 
        priority: "medium", 
        createdAt: "2025-08-12T11:20:00Z",
        updatedAt: "2025-08-12T11:20:00Z",
        assignedTo: null,
        replies: 0,
        category: "performance",
        platform: "PC",
        gameVersion: "1.1.5",
        description: "进入大型战斗场景时游戏卡顿严重，帧率从60fps下降到15fps左右。电脑配置：i7-10700K, RTX 3070, 16GB内存。",
        resolution: "",
        messages: [
          { 
            id: 1, 
            sender: "user", 
            content: "进入大型战斗场景时游戏卡顿严重，帧率从60fps下降到15fps左右。电脑配置：i7-10700K, RTX 3070, 16GB内存。已经尝试降低画质设置，但问题依然存在。",
            timestamp: "2025-08-12T11:20:00Z"
          }
        ]
      }
    ];
    
    localStorage.setItem('support_tickets', JSON.stringify(initialTickets));
  }
  
  /**
   * 初始化广告配置数据
   */
  private static initAdConfig(): void {
    const adConfig = {
      googleAds: {
        enabled: false,
        clientId: "",
        apiKey: "",
        conversionId: "",
        trackingId: "",
        autoTagging: false
      },
      facebookAds: {
        enabled: false,
        accountId: "",
        accessToken: "",
        pixelId: "",
        appId: "",
        sdkVersion: "17.0.0"
      },
      appleSearchAds: {
        enabled: false,
        teamId: "",
        clientId: "",
        keyId: "",
        privateKey: "",
        campaignId: ""
      },
      tiktokAds: {
        enabled: false,
        advertiserId: "",
        accessToken: "",
        pixelId: ""
      },
      googlePlay: {
        enabled: false,
        apiKey: "",
        appId: "",
        trackConversions: false
      },
      appStore: {
        enabled: false,
        issuerId: "",
        keyId: "",
        bundleId: "",
        privateKey: ""
      },
      googleSdk: {
        enabled: false,
        apiKey: "",
        clientId: "",
        trackingId: ""
      },
      iosSdk: {
        enabled: false,
        bundleId: "",
        apiKey: "",
        teamId: ""
      }
    };
    
    localStorage.setItem('ad_config', JSON.stringify(adConfig));
  }
  
  /**
   * 初始化系统设置
   */
  private static initSystemSettings(): void {
    const systemSettings = {
      general: {
        siteName: "GamePortal",
        language: "zh-CN",
        timezone: "Asia/Shanghai",
        dateFormat: "YYYY-MM-DD",
        timeFormat: "HH:mm:ss",
        theme: "auto",
        version: "1.0.0"
      },
      notifications: {
        email: true,
        push: true,
        sms: false,
        marketing: true
      },
      security: {
        twoFactorAuth: false,
        passwordExpiry: "90",
        sessionTimeout: "30",
        loginAttempts: "5"
      },
      maintenance: {
        enabled: false,
        startTime: null,
        endTime: null,
        message: "系统维护中，请稍后访问"
      },
      integrations: {
        googleAnalytics: false,
        firebase: false,
        slack: false,
        discord: false,
        sentry: false
      },
      api: {
        rateLimit: "100/minute",
        cors: ["https://gameportal.com", "https://admin.gameportal.com"],
        timeout: "30s"
      }
    };
    
    localStorage.setItem('system_settings', JSON.stringify(systemSettings));
  }
  
  /**
   * 获取模拟数据
   * @param type - 数据类型
   * @returns 对应类型的模拟数据
   */
  static getMockData(type: string): any[] {
    const data = localStorage.getItem(type);
    return data ? JSON.parse(data) : [];
  }
  
  /**
   * 保存模拟数据
   * @param type - 数据类型
   * @param data - 要保存的数据
   */
  static saveMockData(type: string, data: any[]): void {
    localStorage.setItem(type, JSON.stringify(data));
  }
  
  /**
   * 生成模拟API响应
   * @param endpoint - API端点
   * @param method - HTTP方法
   * @param body - 请求体
   * @returns 模拟API响应
   */
  static generateApiResponse(endpoint: string, method: string = 'GET', body: any = null): { status: number; data: any } {
    // 实现基于端点和方法的模拟响应生成
    if (endpoint.includes('/api/users')) {
      return this.generateUserResponse(endpoint, method, body);
    } else if (endpoint.includes('/api/orders')) {
      return this.generateOrderResponse(endpoint, method, body);
    } else if (endpoint.includes('/api/dashboard')) {
      return { status: 200, data: this.generateDashboardData() };
    }
    
    // 默认响应
    return { status: 404, data: { error: '未找到模拟端点' } };
  }
  
  /**
   * 生成用户相关API响应
   */
  private static generateUserResponse(endpoint: string, method: string, body: any): { status: number; data: any } {
    const users = this.getMockData('users');
    
    if (method === 'GET') {
      const match = endpoint.match(/\/api\/users\/(\d+)/);
      if (match) {
        const userId = parseInt(match[1]);
        const user = users.find((u: any) => u.id === userId);
        return user ? { status: 200, data: user } : { status: 404, data: { error: '用户不存在' } };
      }
      return { status: 200, data: users };
    } else if (method === 'POST' && body) {
      const newUser = {
        id: users.length > 0 ? Math.max(...users.map((u: any) => u.id)) + 1 : 1,
        ...body,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'active'
      };
      
      users.push(newUser);
      this.saveMockData('users', users);
      return { status: 201, data: newUser };
    }
    
    return { status: 405, data: { error: '方法不支持' } };
  }
  
  /**
   * 生成订单相关API响应
   */
  private static generateOrderResponse(endpoint: string, method: string, body: any): { status: number; data: any } {
    const orders = this.getMockData('orders');
    
    if (method === 'GET') {
      const match = endpoint.match(/\/api\/orders\/(\d+)/);
      if (match) {
        const orderId = parseInt(match[1]);
        const order = orders.find((o: any) => o.id === orderId);
        return order ? { status: 200, data: order } : { status: 404, data: { error: '订单不存在' } };
      }
      return { status: 200, data: orders };
    } else if (method === 'POST' && body) {
      const newOrder = {
        id: orders.length > 0 ? Math.max(...orders.map((o: any) => o.id)) + 1 : 1,
        ...body,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'pending'
      };
      
      orders.push(newOrder);
      this.saveMockData('orders', orders);
      return { status: 201, data: newOrder };
    }
    
    return { status: 405, data: { error: '方法不支持' } };
  }
  
  /**
   * 生成仪表盘数据
   */
  private static generateDashboardData(): any {
    const users = this.getMockData('users');
    const orders = this.getMockData('orders');
    const games = this.getMockData('games');
    const servers = this.getMockData('servers');
    
    const userCount = users.length;
    const orderCount = orders.length;
    const revenue = orders.reduce((sum: number, order: any) => sum + order.total, 0);
    const gameCount = games.length;
    const activeServers = servers.filter((s: any) => s.status === 'online').length;
    const totalServers = servers.length;
    
    return {
      dau: Math.floor(userCount * 0.3),
      mau: userCount,
      newUsers: Math.floor(userCount * 0.15),
      retention: 42.8,
      arpu: 3.85,
      ltv: 28.45,
      revenue: revenue,
      totalOrders: orderCount,
      gameCount: gameCount,
      activeServers: activeServers,
      totalServers: totalServers,
      conversionRate: 24.8,
      avgSessionTime: 18.5,
      activeEvents: 2,
      totalEvents: 3,
      supportTickets: 125,
      resolvedTickets: 108,
      ticketResolutionRate: 86.4,
      uptime: 99.8,
      responseTime: 125,
      errorRate: 0.3
    };
  }
}