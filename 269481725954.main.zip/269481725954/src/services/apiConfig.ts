/**
 * API配置 - 后端集成增强版
 * 用于配置后端API连接信息和环境变量
 */
export const API_CONFIG = {
  // 后端API基础URL
 // 配置为本地服务器API地址
 baseUrl: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api',
  
  // API环境
  environment: import.meta.env.VITE_API_ENV || 'development',
  
  // 请求超时时间(毫秒)
  timeout: parseInt(import.meta.env.VITE_API_TIMEOUT || '10000'),
  
  // 默认请求头
  defaultHeaders: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-App-Version': import.meta.env.VITE_APP_VERSION || '1.0.0',
    'X-Platform': 'web'
  },
  
  // API端点配置
  endpoints: {
    // 用户相关
    users: '/users',
    userById: (id: number) => `/users/${id}`,
    userRegistration: '/auth/register',
    userLogin: '/auth/login',
    userLogout: '/auth/logout',
    userProfile: '/users/profile',
    userPasswordReset: '/auth/reset-password',
    
    // 订单相关
    orders: '/orders',
    orderById: (id: number) => `/orders/${id}`,
    orderStatistics: '/orders/statistics',
    
    // 游戏数据相关
    dashboard: '/dashboard',
    gameData: '/game-data',
         gameById: (id: number) => `/games/${id}`,
          gameMetrics: '/game-data/metrics',
    gameList: '/games',
    
    // 服务器相关
    servers: '/servers',
    serverById: (id: string) => `/servers/${id}`,
    serverStatus: '/servers/status',
    
    // 活动相关
    events: '/events',
    eventById: (id: number) => `/events/${id}`,
    eventStatistics: '/events/statistics',
    
    // 广告相关
    adConfig: '/ad/config',
    adPerformance: '/ad/performance',
    adChannels: '/ad/channels',
    
    // 内容管理相关
    contentItems: '/content',
    contentById: (id: number) => `/content/${id}`,
    
    // 支持相关
    supportTickets: '/support/tickets',
    supportTicketById: (id: number) => `/support/tickets/${id}`,
    
    // 系统相关
    systemLogs: '/system/logs',
    systemSettings: '/system/settings',
    systemStatus: '/system/status'
  },
  
  // 后端集成文档
  integrationGuide: {
    php: {
      recommendedVersion: '8.1+',
      requiredExtensions: ['curl', 'json', 'mbstring', 'openssl'],
      setupSteps: [
        '1. 进入backend目录: cd backend',
        '2. 安装依赖: composer install',
        '3. 复制.env.example到.env并配置数据库连接',
        '4. 运行数据库迁移: php src/database/migrate.php',
        '5. 填充初始数据: php src/database/seed.php',
        '6. 启动开发服务器: composer start',
        '7. 更新前端API_BASE_URL指向您的后端服务'
      ],
      exampleEndpoints: [
        'GET /api/users - 获取用户列表',
        'POST /api/users - 创建新用户',
        'GET /api/dashboard - 获取仪表盘数据',
        'GET /api/orders - 获取订单列表'
      ],
      authentication: '使用Bearer令牌认证，在请求头中添加 Authorization: Bearer {token}'
    }
  }
};