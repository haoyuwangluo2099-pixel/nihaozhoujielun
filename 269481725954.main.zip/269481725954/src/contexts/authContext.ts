import { createContext } from "react";

// 管理员认证上下文
export const AdminAuthContext = createContext({
  isAuthenticated: false,
  login: () => {},
  logout: () => {},
});

// 玩家认证上下文
export const PlayerAuthContext = createContext({
  isAuthenticated: false,
  login: () => {},
  logout: () => {},
});