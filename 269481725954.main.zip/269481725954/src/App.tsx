import { Routes, Route, Navigate } from "react-router-dom";
import { toast } from 'sonner';
import React, { useState, useEffect, createContext, useContext } from "react";
import { AdminAuthContext, PlayerAuthContext } from '@/contexts/authContext';
import { ApiService } from '@/services/api';
import { API_CONFIG } from '@/services/apiConfig';
import Layout from '@/components/layout/Layout';
import Dashboard from '@/pages/Dashboard';
import AdminLogin from '@/pages/Login';
  import NotFound from '@/pages/NotFound';
  import Users from '@/pages/Users';
  import GameData from '@/pages/GameData';
  import GameDataDetailed from '@/pages/GameDataDetailed';
  import GameManagement from '@/pages/GameManagement';
  import Revenue from '@/pages/Revenue';
  import Servers from '@/pages/Servers';
  import Events from '@/pages/Events';

import AdMonitoring from '@/pages/AdMonitoring';
import Orders from '@/pages/Orders';
import OrderDetail from '@/pages/OrderDetail';
import UserRegistration from '@/pages/UserRegistration';
import Settings from '@/pages/Settings';
import ContentManagement from '@/pages/ContentManagement';
import SupportTickets from '@/pages/SupportTickets';
import SystemLogs from '@/pages/SystemLogs';
  import Roles from '@/pages/Roles';

// Player pages
import PlayerHome from '@/pages/player/Home';
import PlayerLogin from '@/pages/player/Login';



// Mock authentication check for admin
const checkAdminAuth = () => {
  return localStorage.getItem('isAuthenticated') === 'true';
};

// Mock authentication check for player
const checkPlayerAuth = () => {
  return localStorage.getItem('playerAuthenticated') === 'true';
};

// Player auth provider component
function PlayerAuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(checkPlayerAuth());

  const login = () => {
    setIsAuthenticated(true);
    localStorage.setItem('playerAuthenticated', 'true');
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('playerAuthenticated');
  };

  return (
    <PlayerAuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </PlayerAuthContext.Provider>
  );
}

// Player protected route component
function PlayerProtectedRoute({ children }) {
  const { isAuthenticated } = useContext(PlayerAuthContext);
  
  if (!isAuthenticated) {
    return <Navigate to="/player/login" />;
  }
  
  return children;
}

export default function App() {
  // 管理员认证状态
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(checkAdminAuth());
  // 玩家认证状态
  const [isPlayerAuthenticated, setIsPlayerAuthenticated] = useState(checkPlayerAuth());
  const [loading, setLoading] = useState(true);

  // 安全检查和初始化
  useEffect(() => {
    // Simulate auth check delay
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [isAdminAuthenticated, isPlayerAuthenticated]);

  // 全局错误处理
     useEffect(() => {
    // 监听API错误事件
    const handleApiError = (event: CustomEvent) => {
      console.error('全局API错误处理:', event.detail);
      // 自动切换到模拟数据模式
      ApiService.forceMockData(true);
    };

    window.addEventListener('apiError', handleApiError);
    
     // 网络状态检测
     // 后端服务健康检查
     const checkBackendHealth = async () => {
       try {
         const response = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.healthCheckUrl}`);
         if (!response.ok) throw new Error('后端服务不可用');
         const healthData = await response.json();
         console.log('后端服务状态:', healthData);
         
         // 数据库连接检查
         const dbResponse = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.dbCheckUrl}`);
         if (!dbResponse.ok) throw new Error('数据库连接失败');
         const dbData = await dbResponse.json();
         console.log('数据库状态:', dbData);
         
         toast.success('后端服务和数据库连接正常');
       } catch (error) {
         console.error('后端服务检查失败:', error);
         toast.warning('后端服务或数据库连接异常，使用模拟数据');
       }
     };
     
     // 应用加载时检查后端状态
     checkBackendHealth();
    const handleNetworkChange = () => {
      if (!navigator.onLine) {
        toast.warning('网络连接已断开，部分功能可能受限');
      } else {
        toast.success('网络连接已恢复');
        // 尝试重新加载数据
        ApiService.clearCache();
      }
    };

    window.addEventListener('online', handleNetworkChange);
    window.addEventListener('offline', handleNetworkChange);
    
    return () => {
      window.removeEventListener('apiError', handleApiError);
      window.removeEventListener('online', handleNetworkChange);
      window.removeEventListener('offline', handleNetworkChange);
    };
  }, []);

  // 管理员登录
  const adminLogin = () => {
    setIsAdminAuthenticated(true);
    localStorage.setItem('adminAuthenticated', 'true');
    // 确保玩家系统登出
    setIsPlayerAuthenticated(false);
    localStorage.removeItem('playerAuthenticated');
  };

  // 管理员登出
  const adminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('adminAuthenticated');
  };

  // 玩家登录
  const playerLogin = () => {
    setIsPlayerAuthenticated(true);
    localStorage.setItem('playerAuthenticated', 'true');
    // 确保管理员系统登出
    setIsAdminAuthenticated(false);
    localStorage.removeItem('adminAuthenticated');
  };

  // 玩家登出
  const playerLogout = () => {
    setIsPlayerAuthenticated(false);
    localStorage.removeItem('playerAuthenticated');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
        <div className="flex flex-col items-center">
          <i className="fa-solid fa-gamepad text-blue-600 text-4xl animate-pulse"></i>
          <p className="mt-4 text-lg font-medium text-gray-700 dark:text-gray-300">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <PlayerAuthProvider>
       <AdminAuthContext.Provider value={{ isAuthenticated: isAdminAuthenticated, login: adminLogin, logout: adminLogout }}>
        <PlayerAuthContext.Provider value={{ isAuthenticated: isPlayerAuthenticated, login: playerLogin, logout: playerLogout }}>
          <Routes>
            {/* Admin routes */}
            <Route path="/login" element={isAdminAuthenticated ? <Navigate to="/" /> : <AdminLogin />} />
            
            <Route path="/" element={isAdminAuthenticated ? <Layout><Dashboard /></Layout> : <Navigate to="/login" />} />
            <Route path="/users" element={isAdminAuthenticated ? <Layout><Users /></Layout> : <Navigate to="/login" />} />
            <Route path="/game-data" element={isAdminAuthenticated ? <Layout><GameData /></Layout> : <Navigate to="/login" />} />
            <Route path="/game-data/detailed" element={isAdminAuthenticated ? <Layout><GameDataDetailed /></Layout> : <Navigate to="/login" />} />
            <Route path="/game-management" element={isAdminAuthenticated ? <Layout><GameManagement /></Layout> : <Navigate to="/login" />} />
            <Route path="/revenue" element={isAdminAuthenticated ? <Layout><Revenue /></Layout> : <Navigate to="/login" />} />
            <Route path="/servers" element={isAdminAuthenticated ? <Layout><Servers /></Layout> : <Navigate to="/login" />} />
            <Route path="/events" element={isAdminAuthenticated ? <Layout><Events /></Layout> : <Navigate to="/login" />} />
            <Route path="/ad-monitoring" element={isAdminAuthenticated ? <Layout><AdMonitoring /></Layout> : <Navigate to="/login" />} />
            <Route path="/user-registration" element={isAdminAuthenticated ? <Layout><UserRegistration /></Layout> : <Navigate to="/login" />} />
            <Route path="/settings" element={isAdminAuthenticated ? <Layout><Settings /></Layout> : <Navigate to="/login" />} />
            <Route path="/content" element={isAdminAuthenticated ? <Layout><ContentManagement /></Layout> : <Navigate to="/login" />} />
            <Route path="/support" element={isAdminAuthenticated ? <Layout><SupportTickets /></Layout> : <Navigate to="/login" />} />
            <Route path="/logs" element={isAdminAuthenticated ? <Layout><SystemLogs /></Layout> : <Navigate to="/login" />} />
            <Route path="/roles" element={isAdminAuthenticated ? <Layout><Roles /></Layout> : <Navigate to="/login" />} />

            {/* Player routes */}
            <Route path="/player" element={isPlayerAuthenticated ? <PlayerHome /> : <Navigate to="/player/login" />} />
            <Route path="/player/login" element={isPlayerAuthenticated ? <Navigate to="/player" /> : <PlayerLogin />} />
            
            {/* 404 */}
              <Route path="/orders" element={isAdminAuthenticated ? <Layout><Orders /></Layout> : <Navigate to="/login" />} />
              <Route path="/orders/:id" element={isAdminAuthenticated ? <Layout><OrderDetail /></Layout> : <Navigate to="/login" />} />
              <Route path="*" element={<NotFound />} />
          </Routes>
        </PlayerAuthContext.Provider>
      </AdminAuthContext.Provider>
    </PlayerAuthProvider>
   );
 }