import { useState } from 'react';
import { supportTickets } from '@/mocks/dashboardData';
import { toast } from 'sonner';

// 格式化日期时间
const formatDateTime = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleString('zh-CN', { 
    year: 'numeric', 
    month: '2-digit', 
    day: '2-digit', 
    hour: '2-digit', 
    minute: '2-digit' 
  });
};

// 优先级标签
const PriorityTag = ({ priority }: { priority: string }) => {
  const priorities = {
    'low': { label: '低', className: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
    'medium': { label: '中', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300' },
    'high': { label: '高', className: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' }
  };
  
  const priorityInfo = priorities[priority] || { label: priority, className: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' };
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${priorityInfo.className}`}>
      {priorityInfo.label}
    </span>
  );
};

// 状态标签
const StatusTag = ({ status }: { status: string }) => {
  const statuses = {
    'pending': { label: '待处理', className: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' },
    'in_progress': { label: '处理中', className: 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300' },
    'resolved': { label: '已解决', className: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
    'closed': { label: '已关闭', className: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' }
  };
  
  const statusInfo = statuses[status] || { label: status, className: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' };
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusInfo.className}`}>
      {statusInfo.label}
    </span>
  );
};

export default function SupportTickets() {
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTicket, setSelectedTicket] = useState<typeof supportTickets[0] | null>(null);
  const [tickets, setTickets] = useState<typeof supportTickets[0][]>(supportTickets);
  
  // 筛选工单列表
  const filteredTickets = tickets
    .filter(ticket => activeTab === 'all' || ticket.status === activeTab)
    .filter(ticket => 
      ticket.user.toLowerCase().includes(searchTerm.toLowerCase()) || 
      ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.id.toString().includes(searchTerm)
    );
  
  // 处理工单分配
  const handleAssign = (id: number) => {
    setTickets(tickets.map(ticket => 
      ticket.id === id ? { 
        ...ticket, 
        status: 'in_progress', 
        assignedTo: '当前用户',
        updatedAt: new Date().toISOString()
      } : ticket
    ));
    toast.success('工单已分配给您');
  };
  
  // 处理工单解决
  const handleResolve = (id: number) => {
    setTickets(tickets.map(ticket => 
      ticket.id === id ? { 
        ...ticket, 
        status: 'resolved', 
        updatedAt: new Date().toISOString()
      } : ticket
    ));
    toast.success('工单已标记为已解决');
  };
  
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">用户支持工单</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            查看和处理用户提交的支持请求和问题反馈
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center space-x-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <i className="fa-solid fa-search text-gray-400"></i>
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-300"
              placeholder="搜索工单..."
            />
          </div>
          
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
            <i className="fa-solid fa-filter mr-2"></i>
            筛选
          </button>
        </div>
      </div>
      
      {/* 工单状态标签页 */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'all', name: '全部工单' },
            { id: 'pending', name: '待处理' },
            { id: 'in_progress', name: '处理中' },
            { id: 'resolved', name: '已解决' },
            { id: 'closed', name: '已关闭' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              {tab.name}
              <span className="ml-1 inline-flex items-center justify-center w-5 h-5 rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                {tab.id === 'all' ? tickets.length : tickets.filter(ticket => ticket.status === tab.id).length}
              </span>
            </button>
          ))}
        </nav>
      </div>
      
      {/* 工单列表 */}
      <div className="bg-white dark:bg-gray-800 shadow overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  工单ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  用户
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  主题
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  状态
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  优先级
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  创建时间
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  回复数
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredTickets.map((ticket) => (
                <tr key={ticket.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    #{ticket.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {ticket.user}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap max-w-xs truncate">
                    <div className="text-sm text-gray-900 dark:text-white">{ticket.subject}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StatusTag status={ticket.status} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <PriorityTag priority={ticket.priority} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {formatDateTime(ticket.createdAt)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                      {ticket.replies}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button 
                      onClick={() => setSelectedTicket(ticket)}
                      className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4"
                    >
                      <i className="fa-solid fa-eye"></i>
                    </button>
                    
                    {ticket.status === 'pending' && (
                      <button 
                        onClick={() => handleAssign(ticket.id)}
                        className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-4"
                      >
                        <i className="fa-solid fa-user-plus"></i>
                      </button>
                    )}
                    
                    {(ticket.status === 'in_progress' || ticket.assignedTo === '当前用户') && (
                      <button 
                        onClick={() => handleResolve(ticket.id)}
                        className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-4"
                      >
                        <i className="fa-solid fa-check"></i>
                      </button>
                    )}
                    
                    <button 
                      onClick={() => {}}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                    >
                      <i className="fa-solid fa-times"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* 分页 */}
        <div className="bg-white dark:bg-gray-800 px-4 py-3 flex items-center justify-between border-t border-gray-200 dark:border-gray-700 sm:px-6">
          <div className="hidden sm:block">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              显示 <span className="font-medium">1</span> 到 <span className="font-medium">{filteredTickets.length}</span> 条，共 <span className="font-medium">{tickets.length}</span> 条结果
            </p>
          </div>
          <div className="flex-1 flex justify-between sm:justify-end">
            <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600">
              <span className="sr-only">上一页</span>
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600">
              <span className="sr-only">下一页</span>
              <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* 工单详情模态框 */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">工单详情 ##{selectedTicket.id}</h2>
                <button 
                  onClick={() => setSelectedTicket(null)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">{selectedTicket.subject}</h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">用户</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{selectedTicket.user}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">状态</span>
                      <StatusTag status={selectedTicket.status} />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">优先级</span>
                      <PriorityTag priority={selectedTicket.priority} />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">创建时间</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{formatDateTime(selectedTicket.createdAt)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">最后更新</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{formatDateTime(selectedTicket.updatedAt)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">分配给</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        {selectedTicket.assignedTo || '未分配'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">工单内容</h3>
                  <div className="bg-gray-100 dark:bg-gray-700/50 p-4 rounded-lg">
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      这是用户提交的工单内容示例。在实际应用中，这里会显示用户详细描述的问题内容，可能包含错误截图、重现步骤等信息，帮助客服人员更好地理解和解决问题。
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">对话记录</h3>
                
                <div className="space-y-4">
                  {/* 用户消息 */}
                  <div className="flex">
                    <div className="flex-shrink-0 mr-3">
                      <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                        <i className="fa-solid fa-user text-gray-600 dark:text-gray-300"></i>
                      </div>
                    </div>
                    <div>
                      <div className="bg-gray-100 dark:bg-gray-700/50 rounded-lg rounded-tl-none p-3 max-w-md">
                        <p className="text-sm text-gray-900 dark:text-white">
                          我无法登录游戏，总是显示"连接服务器失败"的错误。我已经尝试重启路由器和重新安装游戏，但问题仍然存在。请帮助解决，谢谢！
                        </p>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 ml-2">
                        {formatDateTime(selectedTicket.createdAt)}
                      </p>
                    </div>
                  </div>
                  
                  {/* 客服回复 */}
                  {selectedTicket.status !== 'pending' && (
                    <div className="flex justify-end">
                      <div>
                        <div className="bg-blue-100 dark:bg-blue-900/30 rounded-lg rounded-tr-none p-3 max-w-md">
                          <p className="text-sm text-gray-900 dark:text-white">
                            您好，请尝试修改DNS设置为8.8.8.8和8.8.4.4，然后重启游戏再试。如果问题仍然存在，请提供您的网络运营商和所在地区信息，以便我们进一步排查。
                          </p>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 mr-2 text-right">
                          {formatDateTime(new Date(Date.parse(selectedTicket.createdAt) + 3600000).toISOString())}
                        </p>
                      </div>
                      <div className="flex-shrink-0 ml-3">
                        <div className="w-8 h-8 rounded-full bg-blue-200 dark:bg-blue-800 flex items-center justify-center">
                          <i className="fa-solid fa-user-tie text-blue-600 dark:text-blue-300"></i>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* 回复框 */}
                <div className="mt-6">
                  <label htmlFor="replyContent" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    添加回复
                  </label>
                  <textarea
                    id="replyContent"
                    rows={3}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入回复内容..."
                  ></textarea>
                  
                  <div className="mt-3 flex justify-end">
                    <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
                      <i className="fa-solid fa-paper-plane mr-2"></i>
                      发送回复
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
              {selectedTicket.status === 'pending' && (
                <button
                  onClick={() => handleAssign(selectedTicket.id)}
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 dark:focus:ring-offset-gray-900"
                >
                  <i className="fa-solid fa-user-plus mr-2"></i>
                  分配给我
                </button>
              )}
              
              {(selectedTicket.status === 'in_progress' || selectedTicket.assignedTo === '当前用户') && (
                <button
                  onClick={() => handleResolve(selectedTicket.id)}
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
                >
                  <i className="fa-solid fa-check mr-2"></i>
                  标记为已解决
                </button>
              )}
              
              <button
                onClick={() => setSelectedTicket(null)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
              >
                关闭
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}