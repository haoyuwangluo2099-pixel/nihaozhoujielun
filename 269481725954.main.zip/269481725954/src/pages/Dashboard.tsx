import { useState, useEffect } from 'react';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';
import KpiCard from '@/components/ui/KpiCard';
import UserGrowthChart from '@/components/charts/UserGrowthChart';
import RegionDistributionChart from '@/components/charts/RegionDistributionChart';
import ActivityFeed from '@/components/ui/ActivityFeed';
import ServerStatusTable from '@/components/ui/ServerStatusTable';
import { recentActivities, serverStatus } from '@/mocks/dashboardData';

import { ApiService } from '@/services/api';
import { toast } from 'sonner';

// Formatters for KPI values
const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
};

const formatCurrency = (num: number): string => {
  return '$' + num.toLocaleString();
};

export default function Dashboard() {
  const [dateRange, setDateRange] = useState('7d');
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // 加载仪表盘数据
  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        const data = await ApiService.getDashboardData();
        setDashboardData(data);
        
        // 每5分钟刷新一次数据
        const intervalId = setInterval(async () => {
          try {
            const freshData = await ApiService.getDashboardData();
            setDashboardData(freshData);
          } catch (refreshError) {
            console.error('刷新数据失败:', refreshError);
          }
        }, 5 * 60 * 1000);
        
        return () => clearInterval(intervalId);
       } catch (error) {
         console.error('Error loading dashboard data:', error);
         toast.error('加载仪表盘数据失败，已自动切换到本地缓存数据');
         // 尝试从localStorage加载缓存数据
         const cachedData = localStorage.getItem('cached_dashboard_data');
         if (cachedData) {
           setDashboardData(JSON.parse(cachedData));
           return;
         }
        setLoading(false);
      } finally {
        setLoading(false);
      }
    };
    
    loadDashboardData();
  }, []);
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">游戏运营仪表盘</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            监控和分析您的游戏运营数据和关键指标
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center space-x-3">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="24h">过去24小时</option>
              <option value="7d">过去7天</option>
              <option value="30d">过去30天</option>
              <option value="90d">过去90天</option>
              <option value="1y">过去一年</option>
              <option value="custom">自定义范围</option>
            </select>
          </div>
          
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
            <i className="fa-solid fa-download mr-2"></i>
            导出报告
          </button>
        </div>
      </div>
      
      {/* KPI Cards */}
       {/* KPI Cards */}
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {loading ? (
            // 加载状态占位符
            Array(8).fill(0).map((_, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700 animate-pulse">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
              </div>
            ))
          ) : (
            // 确保无论数据是否加载成功都显示所有KPI卡片框架
            <>
              <KpiCard 
                title="日活跃用户" 
                value={dashboardData?.dau || 0} 
                change={dashboardData ? 12.5 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-users"
                formatValue={formatNumber}
                description="较昨日增长12.5%"
              />
              <KpiCard 
                title="月活跃用户" 
                value={dashboardData?.mau || 0} 
                change={dashboardData ? 8.2 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-user-friends"
                formatValue={formatNumber}
                description="较上月增长8.2%"
              />
              <KpiCard 
                title="新增用户" 
                value={dashboardData?.newUsers || 0} 
                change={dashboardData ? -2.1 : 0} 
                trend={dashboardData ? "down" : "down"} 
                icon="fa-user-plus"
                formatValue={formatNumber}
                description="较昨日下降2.1%"
              />
              <KpiCard 
                title="次日留存率" 
                value={dashboardData?.retention || 0} 
                change={dashboardData ? 3.5 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-recycle"
                formatValue={(value) => value + '%'}
                description="较上周提升3.5%"
              />
              <KpiCard 
                title="7日留存率" 
                value={dashboardData?.retention7d || 28.5} 
                change={dashboardData ? 2.1 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-recycle"
                formatValue={(value) => value + '%'}
                description="较上周提升2.1%"
              />
              <KpiCard 
                title="30日留存率" 
                value={dashboardData?.retention30d || 15.2} 
                change={dashboardData ? 1.8 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-recycle"
                formatValue={(value) => value + '%'}
                description="较上月提升1.8%"
              />
              <KpiCard 
                title="LTV" 
                value={dashboardData?.ltv || 0} 
                change={dashboardData ? 7.8 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-chart-line"
                formatValue={(value) => '$' + value.toFixed(2)}
                description="用户平均生命周期价值"
              />
              <KpiCard 
                title="ARPU" 
                value={dashboardData?.arpu || 0} 
                change={dashboardData ? 5.2 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-user-dollar"
                formatValue={(value) => '$' + value.toFixed(2)}
                description="每用户平均收入"
              />
              <KpiCard 
                title="总收入" 
                value={dashboardData?.revenue || 0} 
                change={dashboardData ? 15.7 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-chart-line"
                formatValue={formatCurrency}
                description="本月累计收入"
              />
              <KpiCard 
                title="付费转化率" 
                value={dashboardData?.conversionRate || 0} 
                change={dashboardData ? 0.8 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-percentage"
                formatValue={(value) => value + '%'}
                description="访问到付费转化比例"
              />
              <KpiCard 
                title="广告点击率" 
                value={dashboardData?.adCtr || 2.8} 
                change={dashboardData ? -0.3 : 0} 
                trend={dashboardData ? "down" : "down"} 
                icon="fa-ad"
                formatValue={(value) => value + '%'}
                description="广告平均点击率"
              />
              <KpiCard 
                title="广告转化率" 
                value={dashboardData?.adConversion || 1.2} 
                change={dashboardData ? 0.2 : 0} 
                trend={dashboardData ? "up" : "up"} 
                icon="fa-exchange-alt"
                formatValue={(value) => value + '%'}
                description="广告点击到安装转化"
              />
            </>
          )}
        </div>
      
       {/* 用户增长趋势图表 */}
       <div className="mt-6">
         <UserGrowthChart />
       </div>
      
        {/* 留存率和LTV趋势图表 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">用户留存率趋势</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={[
                  { day: '1', retention: 100 },
                  { day: '3', retention: 68 },
                  { day: '7', retention: 42.8 },
                  { day: '14', retention: 28.5 },
                  { day: '30', retention: 15.2 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="day" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    formatter={(value) => [`${value}%`, '留存率']}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Line type="monotone" dataKey="retention" name="留存率" stroke="#8b5cf6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">LTV趋势</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={[
                  { month: '1', ltv: 8.5 },
                  { month: '2', ltv: 15.2 },
                  { month: '3', ltv: 21.8 },
                  { month: '4', ltv: 25.6 },
                  { month: '5', ltv: 27.3 },
                  { month: '6', ltv: 28.45 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="month" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    formatter={(value) => [`$${value}`, 'LTV']}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Line type="monotone" dataKey="ltv" name="LTV" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        
        {/* 图表区域 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          {/* 地区分布图表 */}
          <div>
            <RegionDistributionChart />
          </div>
          
          {/* 广告监控图表 */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">广告效果监控</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[
                  { platform: 'Google', impressions: 125000, clicks: 4520, conversions: 285 },
                  { platform: 'Facebook', impressions: 98000, clicks: 3200, conversions: 195 },
                  { platform: 'TikTok', impressions: 75000, clicks: 2850, conversions: 142 },
                  { platform: 'Instagram', impressions: 62000, clicks: 1980, conversions: 98 },
                  { platform: 'Apple', impressions: 45000, clicks: 1250, conversions: 85 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="platform" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                  />
                  <Legend />
                  <Bar dataKey="clicks" name="点击量" fill="#3b82f6" />
                  <Bar dataKey="conversions" name="转化量" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">广告花费</h4>
                <div className="flex items-center">
                  <span className="text-2xl font-bold text-gray-900 dark:text-white">${dashboardData?.adSpend || 42800}</span>
                  <span className="ml-2 text-sm text-green-600 dark:text-green-400">+12.5%</span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">本月总广告支出</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">ROI</h4>
                <div className="flex items-center">
                  <span className="text-2xl font-bold text-gray-900 dark:text-white">4.8x</span>
                  <span className="ml-2 text-sm text-green-600 dark:text-green-400">+0.5x</span>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">广告投资回报率</p>
              </div>
            </div>
          </div>
        </div>
      
       {/* 最新订单列表 */}
       <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden border border-gray-200 dark:border-gray-700">
         <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
           <h3 className="text-lg font-semibold text-gray-900 dark:text-white">最新订单</h3>
         </div>
         <div className="overflow-x-auto">
           <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
             <thead className="bg-gray-50 dark:bg-gray-700/50">
               <tr>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">订单ID</th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">用户</th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">日期</th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">金额</th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">状态</th>
                 <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">操作</th>
               </tr>
             </thead>
             <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
               {[
                 { id: 'ORD-9876', user: 'player123', date: '2025-08-12', amount: '$49.99', status: 'completed' },
                 { id: 'ORD-9875', user: 'gamer456', date: '2025-08-12', amount: '$29.99', status: 'completed' },
                 { id: 'ORD-9874', user: 'proplayer789', date: '2025-08-12', amount: '$79.99', status: 'pending' },
                 { id: 'ORD-9873', user: 'mobilegamer', date: '2025-08-11', amount: '$19.99', status: 'completed' },
                 { id: 'ORD-9872', user: 'casualplayer', date: '2025-08-10', amount: '$39.99', status: 'refunded' }
               ].map((order, index) => (
                 <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                   <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{order.id}</td>
                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{order.user}</td>
                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{order.date}</td>
                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{order.amount}</td>
                   <td className="px-6 py-4 whitespace-nowrap">
                     <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                       order.status === 'completed' 
                         ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' 
                         : order.status === 'pending'
                           ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300'
                           : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300'
                     }`}>
                       {order.status === 'completed' ? '已完成' : order.status === 'pending' ? '待处理' : '已退款'}
                     </span>
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                     <button className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300">
                       <i className="fa-solid fa-eye"></i>
                     </button>
                   </td>
                 </tr>
               ))}
             </tbody>
           </table>
         </div>
       </div>
     </div>
  );
}