import { useState } from 'react';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import KpiCard from '@/components/ui/KpiCard';

// Mock registration data
const registrationMetrics = {
  totalUsers: {
    value: 3245000,
    change: 8.2,
    trend: 'up',
    icon: 'fa-users'
  },
  newToday: {
    value: 2845,
    change: 12.5,
    trend: 'up',
    icon: 'fa-user-plus'
  },
  conversionRate: {
    value: 24.8,
    change: 3.2,
    trend: 'up',
    icon: 'fa-percentage',
    suffix: '%'
  },
  avgRegistrationTime: {
    value: 2.4,
    change: -0.3,
    trend: 'down',
    icon: 'fa-clock',
    suffix: '分钟'
  }
};

// Daily registration trend data
const dailyRegistrationData = [
  { date: '00:00', registrations: 120 },
  { date: '03:00', registrations: 85 },
  { date: '06:00', registrations: 60 },
  { date: '09:00', registrations: 210 },
  { date: '12:00', registrations: 320 },
  { date: '15:00', registrations: 480 },
  { date: '18:00', registrations: 520 },
  { date: '21:00', registrations: 380 },
];

// Registration source data
const registrationSourceData = [
  { name: '官网', value: 35 },
  { name: '广告', value: 28 },
  { name: '推荐', value: 18 },
  { name: '社交媒体', value: 12 },
  { name: '其他', value: 7 },  
];

export default function UserRegistration() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    country: '',
    source: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Simple validation
    if (!formData.username || !formData.email || !formData.password) {
      toast.error('请填写所有必填字段');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('密码不匹配');
      return;
    }
    
    // Submit form
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      try {
        toast.success('用户注册成功');
        setFormData({
          username: '',
          email: '',
          password: '',
          confirmPassword: '',
          country: '',
          source: ''
        });
      } catch (error) {
        toast.error('注册失败，请重试');
      } finally {
        setIsSubmitting(false);
      }
    }, 1500);
  };
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">用户注册</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            管理用户注册和新用户获取渠道
          </p>
        </div>
        
        <button className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
          <i className="fa-solid fa-download mr-2"></i>
          导出数据
        </button>
      </div>
      
      {/* Registration metrics cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(registrationMetrics).map(([key, metric]) => (
          <KpiCard 
            key={key}
            title={key === 'totalUsers' ? '总用户数' : 
                  key === 'newToday' ? '今日新增' : 
                  key === 'conversionRate' ? '注册转化率' : '平均注册时长'} 
            value={metric.value} 
            change={metric.change} 
            trend={metric.trend} 
            icon={metric.icon}
            formatValue={(value) => value + (metric.suffix || '')}
          />
        ))}
      </div>
      
      {/* Charts and form grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Registration form */}
        <div className="lg:col-span-1 bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">新用户注册</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                用户名 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                required
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="输入用户名"
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                邮箱 <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="输入邮箱地址"
              />
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                密码 <span className="text-red-500">*</span>
              </label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                required
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="输入密码"
              />
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                确认密码 <span className="text-red-\500">*</span>
              </label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                required
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                placeholder="确认密码"
              />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  国家/地区
                </label>
                <select
                  id="country"
                  name="country"
                  value={formData.country}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                >
                  <option value="">选择国家/地区</option>
                  <option value="CN">中国</option>
                  <option value="US">美国</option>
                  <option value="JP">日本</option>
                  <option value="KR">韩国</option>
                  <option value="GB">英国</option>
                  <option value="DE">德国</option>
                  <option value="FR">法国</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  注册来源
                </label>
                <select
                  id="source"
                  name="source"
                  value={formData.source}
                  onChange={handleInputChange}
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                >
                  <option value="">选择来源</option>
                  <option value="website">官网</option>
                  <option value="ads">广告</option>
                  <option value="referral">推荐</option>
                  <option value="social">社交媒体</option>
                  <option value="other">其他</option>
                </select>
              </div>
            </div>
            
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-75 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                  处理中...
                </>
              ) : (
                "创建账户"
              )}
            </button>
          </form>
        </div>
        
        {/* Registration analytics */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">今日注册趋势</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={dailyRegistrationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                    }}
                    formatter={(value) => [value, '注册量']}
                  />
                  <Line type="monotone" dataKey="registrations" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">注册来源分布</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={registrationSourceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="name" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                      }}
                      formatter={(value) => [`${value}%`, '占比']}
                    />
                    <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">地区注册分布</h3>
              <div className="space-y-4">
                {[
                  { name: '北美', users: '32%', growth: '+5.2%' },
                  { name: '欧洲', users: '28%', growth: '+3.8%' },
                  { name: '亚洲', users: '24%', growth: '+8.5%' },
                  { name: '南美', users: '12%', growth: '+4.1%' },
                  { name: '其他', users: '4%', growth: '+2.3%' }
                ].map((region, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm text-gray-600 dark:text-gray-300">{region.name}</span>
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-900 dark:text-white mr-2">{region.users}</span>
                        <span className="text-xs text-green-600 dark:text-green-400">{region.growth}</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full dark:bg-blue-500" 
                        style={{ width: region.users }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}