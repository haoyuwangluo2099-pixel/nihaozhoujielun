import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { ApiService } from '@/services/api';
import { toast } from 'sonner';
import { DataService } from '@/services/db';

export default function Users() {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newUserOpen, setNewUserOpen] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'player',
    country: '',
    level: 0
  });
  
  // 加载用户数据
  useEffect(() => {
    const loadUsers = async () => {
      try {
        setLoading(true);
        // 首先尝试从API加载
        const data = await ApiService.getUsers();
        setUsers(data);
        // 同时更新本地缓存
        localStorage.setItem('cached_users_data', JSON.stringify(data));
      } catch (error) {
        console.error('Error loading users:', error);
        toast.error('加载用户数据失败，已自动切换到本地缓存数据');
        // 尝试从localStorage加载缓存数据
        const cachedData = localStorage.getItem('cached_users_data');
        if (cachedData) {
          setUsers(JSON.parse(cachedData));
        } else {
          // 如果没有缓存，使用默认数据
          const defaultUsers = DataService.getMockData('users');
          if (defaultUsers.length === 0) {
            // 如果默认数据也为空，创建一些示例用户
            const sampleUsers = [
              { id: 1, username: 'admin', email: 'admin@game.com', role: 'admin', level: 0, status: 'active', registerDate: '2025-01-15', country: 'CN' },
              { id: 2, username: 'player123', email: 'player@example.com', role: 'player', level: 45, status: 'active', registerDate: '2025-02-20', country: 'US' },
              { id: 3, username: 'gamer456', email: 'gamer456@example.com', role: 'player', level: 67, status: 'active', registerDate: '2025-03-10', country: 'JP' }
            ];
            setUsers(sampleUsers);
            localStorage.setItem('cached_users_data', JSON.stringify(sampleUsers));
          } else {
            setUsers(defaultUsers);
          }
        }
      } finally {
        setLoading(false);
      }
    };
    
    loadUsers();
  }, []);
  
  // 搜索和排序实现
  const filteredUsers = users
    .filter(user => 
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) || 
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.id.toString().includes(searchTerm)
    )
    .sort((a, b) => {
      if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1;
      if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  
  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  // 处理表单输入变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // 处理添加用户
  const handleAddUser = async () => {
    // 表单验证
    if (!formData.username || !formData.email || !formData.password) {
      toast.error('请填写所有必填字段');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('密码不匹配');
      return;
    }
    
    // 密码强度验证
    if (formData.password.length < 6) {
      toast.error('密码长度不能少于6个字符');
      return;
    }
    
    try {
      // 准备用户数据
      const newUser = {
        id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
        username: formData.username,
        email: formData.email,
        password: formData.password,
        role: formData.role,
        level: parseInt(formData.level) || 0,
        country: formData.country || '未设置',
        status: 'active',
        registerDate: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // 调用API创建用户
      await ApiService.createUser(newUser);
      
      // 更新本地状态
      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      localStorage.setItem('cached_users_data', JSON.stringify(updatedUsers));
      
      // 重置表单并关闭模态框
      setFormData({
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        role: 'player',
        country: '',
        level: 0
      });
      setNewUserOpen(false);
      
      toast.success('用户创建成功');
    } catch (error) {
      console.error('Error creating user:', error);
      toast.error('创建用户失败，请重试');
      
      // 即使API失败，也在本地创建用户（开发模式）
      if (import.meta.env.DEV) {
        const newUser = {
          id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
          username: formData.username,
          email: formData.email,
          password: '******',
          role: formData.role,
          level: parseInt(formData.level) || 0,
          country: formData.country || '未设置',
          status: 'active',
          registerDate: new Date().toISOString().split('T')[0],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        
        const updatedUsers = [...users, newUser];
        setUsers(updatedUsers);
        localStorage.setItem('cached_users_data', JSON.stringify(updatedUsers));
        
        setFormData({
          username: '',
          email: '',
          password: '',
          confirmPassword: '',
          role: 'player',
          country: '',
          level: 0
        });
        setNewUserOpen(false);
        
        toast.success('开发模式：用户已本地创建');
      }
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">用户管理</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            查看和管理游戏用户账户信息
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center space-x-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <i className="fa-solid fa-search text-gray-400"></i>
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-300"
              placeholder="搜索用户..."
            />
          </div>
          
          <button 
            onClick={() => setNewUserOpen(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
          >
            <i className="fa-solid fa-plus mr-2"></i>
            添加用户
          </button>
        </div>
      </div>
      
      {/* Users table */}
      <div className="bg-white dark:bg-gray-800 shadow overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('id')}
                >
                  <div className="flex items-center">
                    ID
                    <i className={`fa-solid ml-1 ${sortField === 'id' ? (sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down') : 'fa-sort'}`}></i>
                  </div>
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('username')}
                >
                  <div className="flex items-center">
                    用户名
                    <i className={`fa-solid ml-1 ${sortField === 'username' ? (sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down') : 'fa-sort'}`}></i>
                  </div>
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('email')}
                >
                  邮箱
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('level')}
                >
                  等级
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('country')}
                >
                  地区
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('registerDate')}
                >
                  注册日期
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('status')}
                >
                  状态
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  操作
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
               {loading ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
                      <div className="flex justify-center items-center">
                        <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                        加载中...
                      </div>
                    </td>
                  </tr>
                ) : filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
                      <div className="flex flex-col items-center">
                        <i className="fa-solid fa-users text-4xl text-gray-300 dark:text-gray-600 mb-3"></i>
                        没有找到匹配的用户
                        <button 
                          onClick={() => setNewUserOpen(true)}
                          className="mt-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                          <i className="fa-solid fa-plus mr-2"></i>
                          添加用户
                        </button>
                      </div>
                    </td>
                  </tr>
                ) : filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                     {user.id}
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap">
                     <div className="flex items-center">
                       <div className="flex-shrink-0 h-10 w-10">
                         <img
                           className="h-10 w-10 rounded-full"
                           src={user.avatar || `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=User%20Avatar%20${user.username}`}
                           alt={user.username}
                         />
                       </div>
                       <div className="ml-4">
                         <div className="text-sm font-medium text-gray-900 dark:text-white">{user.username}</div>
                         <div className="text-xs text-gray-500 dark:text-gray-400">{user.role === 'admin' ? '管理员' : '普通用户'}</div>
                       </div>
                     </div>
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                     {user.email}
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap">
                     <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                       {user.level}
                     </span>
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                     {user.country || '未设置'}
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                     {user.registerDate || user.createdAt.split('T')[0]}
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap">
                     <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                       user.status === 'active' 
                         ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                         : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                     }`}>
                       {user.status === 'active' ? '活跃' : '非活跃'}
                     </span>
                   </td>
                   <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                     <button className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-4">
                       <i className="fa-solid fa-edit"></i>
                     </button>
                     <button className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300">
                       <i className="fa-solid fa-trash"></i>
                     </button>
                   </td>
                 </tr>
               ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="bg-white dark:bg-gray-800 px-4 py-3 flex items-center justify-between border-t border-gray-200 dark:border-gray-700 sm:px-6">
          <div className="hidden sm:block">
            <p className="text-sm text-gray-700 dark:text-gray-300">
               显示 <span className="font-medium">{filteredUsers.length > 0 ? 1 : 0}</span> 到 <span className="font-medium">{filteredUsers.length}</span> 条，共 <span className="font-medium">{users.length}</span> 条结果
            </p></div>
          <div className="flex-1 flex justify-between sm:justify-end">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className="fa-solid fa-chevron-left mr-1"></i>
              上一页
            </button>
            <button
              onClick={() => setCurrentPage(prev => prev + 1)}
              disabled={currentPage >= 3}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              下一页
              <i className="fa-solid fa-chevron-right ml-1"></i>
            </button>
          </div>
        </div>
      </div>
      
      {/* 添加用户模态框 */}
      {newUserOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">添加新用户</h2>
                <button 
                  onClick={() => setNewUserOpen(false)}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="username" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    用户名 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="username"
                    name="username"
                    value={formData.username}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入用户名"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    邮箱 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入邮箱地址"
                  />
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    密码 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入密码"
                  />
                </div>
                
                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    确认密码 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="确认密码"
                  />
                </div>
                
                <div>
                  <label htmlFor="role" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    用户角色
                  </label>
                  <select
                    id="role"
                    name="role"
                    value={formData.role}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  >
                    <option value="player">普通玩家</option>
                    <option value="admin">管理员</option>
                    <option value="moderator">版主</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="level" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    初始等级
                  </label>
                  <input
                    type="number"
                    id="level"
                    name="level"
                    value={formData.level}
                    onChange={handleInputChange}
                    min="0"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    placeholder="输入初始等级"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="country" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    国家/地区
                  </label>
                  <select
                    id="country"
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                  >
                    <option value="">选择国家/地区</option>
                    <option value="CN">中国</option>
                    <option value="US">美国</option>
                    <option value="JP">日本</option>
                    <option value="KR">韩国</option>
                    <option value="GB">英国</option>
                    <option value="DE">德国</option>
                    <option value="FR">法国</option>
                    <option value="CA">加拿大</option>
                    <option value="AU">澳大利亚</option>
                    <option value="SG">新加坡</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex justify-end space-x-3 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setNewUserOpen(false)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600"
              >
                取消
              </button>
              <button
                onClick={handleAddUser}className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900"
              >
                创建用户
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}