import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { revenueData as mockRevenueData, regionData } from '@/mocks/dashboardData';
import KpiCard from '@/components/ui/KpiCard';

// Revenue metrics
const revenueMetrics = {
  totalRevenue: {
    value: 485200,
    change: 15.7,
    trend: 'up',
    icon: 'fa-chart-line',
    prefix: '$'
  },
  arpu: {
    value: 3.85,
    change: 5.2,
    trend: 'up',
    icon: 'fa-user-dollar',
    prefix: '$'
  },
  payingUsers: {
    value: 126000,
    change: 8.4,
    trend: 'up',
    icon: 'fa-wallet'
  },
  conversionRate: {
    value: 3.9,
    change: 0.8,
    trend: 'up',
    icon: 'fa-exchange-alt',
    suffix: '%'
  },
  // 新增错误处理逻辑
  errorHandling: {
    fallbackToCache: true,
    showDetailedError: true
  }
};

// Payment methods data
const paymentMethodsData = [
  { name: '信用卡', value: 45 },
  { name: 'PayPal', value: 25 },
  { name: '移动支付', value: 18 },
  { name: '礼品卡', value: 12 },
];

// COLORS for charts
const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#6b7280'];

export default function Revenue() {
  const [dateRange, setDateRange] = useState('30d');
  const [activeMetric, setActiveMetric] = useState('revenue');
  
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">收入分析</h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            监控和分析游戏收入数据和变现指标
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center space-x-3">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            >
              <option value="7d">过去7天</option>
              <option value="30d">过去30天</option>
              <option value="90d">过去90天</option>
              <option value="1y">过去一年</option>
              <option value="custom">自定义范围</option>
            </select>
          </div>
          
          <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900">
            <i className="fa-solid fa-download mr-2"></i>
            导出报告
          </button>
        </div>
      </div>
      
      {/* Revenue metrics cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(revenueMetrics).map(([key, metric]) => (
          <KpiCard 
            key={key}
            title={key === 'totalRevenue' ? '总收入' : 
                  key === 'arpu' ? '每用户平均收入' : 
                  key === 'payingUsers' ? '付费用户数' : '转化率'} 
            value={metric.value} 
            change={metric.change} 
            trend={metric.trend} 
            icon={metric.icon}
            formatValue={(value) => (metric.prefix || '') + value + (metric.suffix || '')}
          />
        ))}
      </div>
      
      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">收入趋势</h3>
            <div className="flex space-x-2">
              {['revenue', 'arpu', 'payingUsers'].map((metric) => (
                <button
                  key={metric}
                  onClick={() => setActiveMetric(metric)}
                  className={`px-3 py-1 text-xs font-medium rounded-full ${
                    activeMetric === metric
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300'
                      : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                  }`}
                >
                  {metric === 'revenue' ? '收入' : 
                   metric === 'arpu' ? 'ARPU' : '付费用户'}
                </button>
              ))}
            </div>
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockRevenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                  formatter={(value, name) => {
                    if (name === 'revenue') return [`$${value}`, '收入'];
                    if (name === 'arpu') return [`$${value}`, 'ARPU'];
                    return [value, '付费用户'];
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey={activeMetric} 
                  name={activeMetric === 'revenue' ? '收入' : 
                       activeMetric === 'arpu' ? 'ARPU' : '付费用户'} 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">收入来源分布</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={regionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  nameKey="name"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {regionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => [`${value}%`, '占比']}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 space-y-2">
            {regionData.map((region, index) => (
              <div key={region.name} className="flex justify-between items-center">
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  ></div>
                  <span className="text-sm text-gray-600 dark:text-gray-300">{region.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{region.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Additional charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">支付方式分布</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={paymentMethodsData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  nameKey="name"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {paymentMethodsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => [`${value}%`, '占比']}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">热门商品</h3>
          <div className="space-y-4">
            {[
              { name: '高级会员', revenue: '125,400', percentage: '32%' },
              { name: '钻石礼包', revenue: '98,700', percentage: '25%' },
              { name: '角色皮肤', revenue: '75,200', percentage: '19%' },
              { name: '游戏道具', revenue: '62,800', percentage: '16%' },
              { name: '其他商品', revenue: '32,900', percentage: '8%' }
            ].map((item, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-gray-600 dark:text-gray-300">{item.name}</span>
                  <div className="flex items-center">
                    <span className="text-sm font-medium text-gray-900 dark:text-white mr-2">${item.revenue}</span>
                    <span className="text-xs text-gray-500 dark:text-gray-400">{item.percentage}</span>
                  </div>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{ width: item.percentage }}
                  ></div>
                </div>
              </div>
            ))}
         </div>
         
         {/* 订单管理部分 */}
         <div className="mt-8">
           <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">订单管理</h3>
           <div className="overflow-x-auto">
             <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
               <thead className="bg-gray-50 dark:bg-gray-700/50">
                 <tr>
                   <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                     订单ID
                   </th>
                   <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                     用户
                   </th>
                   <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                     金额
                   </th>
                   <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                     日期
                   </th>
                   <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                     状态
                   </th>
                 </tr>
               </thead>
               <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                 {[
                   { id: 'ORD-9876', user: 'player123', amount: '¥49.99', date: '2025-08-12', status: 'completed' },
                   { id: 'ORD-9875', user: 'gamer456', amount: '¥29.99', date: '2025-08-12', status: 'completed' },
                   { id: 'ORD-9874', user: 'proplayer789', amount: '¥79.99', date: '2025-08-12', status: 'pending' },
                   { id: 'ORD-9873', user: 'mobilegamer', amount: '¥19.99', date: '2025-08-11', status: 'completed' },
                   { id: 'ORD-9872', user: 'casualplayer', amount: '¥39.99', date: '2025-08-10', status: 'refunded' }
                 ].map((order, index) => (
                   <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                     <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                       {order.id}
                     </td>
                     <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                       {order.user}
                     </td>
                     <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                       {order.amount}
                     </td>
                     <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                       {order.date}
                     </td>
                     <td className="px-6 py-4 whitespace-nowrap">
                       <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                         order.status === 'completed' 
                           ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                           : order.status === 'pending'
                             ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                             : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                       }`}>
                         {order.status === 'completed' ? '已完成' : order.status === 'pending' ? '待处理' : '已退款'}
                       </span>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
         </div>
       </div>
      </div>
    </div>
  );
}